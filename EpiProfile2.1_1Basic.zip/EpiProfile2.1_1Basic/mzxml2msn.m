function success = mzxml2msn(mzxml_file,ms1_path,ms2_path)
%% mzxml2msn

success = 0;

% check the MAT file
[datapath,dataname] = fileparts(mzxml_file);%#ok
MS1_scanfile = fullfile(ms1_path,[dataname,'_MS1scans.mat']);
MS1_peakfile = fullfile(ms1_path,[dataname,'_MS1peaks.mat']);
MS2_scanfile = fullfile(ms2_path,[dataname,'_MS2scans.mat']);
MS2_peakfile = fullfile(ms2_path,[dataname,'_MS2peaks.mat']);
if 0~=exist(MS1_scanfile,'file') && 0~=exist(MS1_peakfile,'file') && 0~=exist(MS2_scanfile,'file') && 0~=exist(MS2_peakfile,'file')
    success = 1;
    return;
end

% check the mzXML file
if 0==exist(mzxml_file,'file')
    disp([mzxml_file,': does not exist!']);
    return;
end

% read the mzXML file
out = mzxmlread(mzxml_file);
ntotalscans = length(out.scan);

%% MS1
% initialize the MS1 info
maxMS1num = 1.5e5;% initial MS1 scan number
totalpeaknum = 4e7;% the init total peak number on MS1 scans
MS1_index = zeros([maxMS1num,4]);% MS1 scan, MS1 rt, MS1 peak num, baseline
MS1_peaks = zeros([totalpeaknum,2]);% m/z and intensity on MS1
fno = 0;% real MS1 scan number
pkno = 0;% real total peak number

sim_no = 0;
sim_scans = [];
sim_mzs = [];

% get the MS1 info
% for progress
ct_prt = 0;
fprintf(1,'MS1 scans: ');

% start to process
for ino=1:ntotalscans
    cur_scan = out.scan(ino);
    if cur_scan.msLevel>1
        continue;
    end
    
    % progress
    fno = fno + 1;
    fprintf(repmat('\b',[1,ct_prt]));
    ct_prt = fprintf('%i',fno);
    
    % 1.get the MS1 info
    % MS1 scan
    scan_no = cur_scan.num;
    
    % RT
    rt_no = str2double(cur_scan.retentionTime(3:end-1))/60;% min
    
    % InstrumentType
    if 1==fno
        MS1Type = cur_scan.filterLine(1:4);%#ok
    end
    
    % 2.read the MS1 data
    mz = cur_scan.peaks.mz(1:2:end);
    inten = cur_scan.peaks.mz(2:2:end);
    IX = find(inten>0);% first read, then filter
    mz = mz(IX);
    inten = inten(IX);
    
    % 4.save the MS1 info and peaks
    if 1==isempty(mz)
        fno = fno - 1;
        continue;
    end
    if length(inten)>200
        baseline = GetBaseline(inten)/2;
        IX = find(inten>=min([baseline 500]));
        mz = mz(IX);
        inten = inten(IX);
    else
        baseline = 0;
    end
    npk = length(mz);
    
    MS1_index(fno,1:4) = [scan_no rt_no npk baseline];
    MS1_peaks(pkno+1:pkno+npk,1) = mz;
    MS1_peaks(pkno+1:pkno+npk,2) = inten;
    pkno = pkno + npk;
    
    if mz(end)-mz(1)<10
        sim_no = sim_no + 1;
        sim_scans(sim_no) = scan_no;%#ok
        sim_mzs(sim_no) = mz(1);%#ok
    end
end
fprintf(repmat('\b',[1,ct_prt]));
fprintf('%i',fno);
fprintf(1,'\n');

% save the MS1 info
% filter the empty values
if fno<maxMS1num
    IX = 1:fno;
    MS1_index = MS1_index(IX,:);
end
MS1_index0 = MS1_index;%+
tmp = MS1_index(1:fno,3);
MS1_index(1:fno,3) = cumsum(tmp) + 1;

if pkno<totalpeaknum
    IX = 1:pkno;
    MS1_peaks = MS1_peaks(IX,:);
end

% check SIM
[MS1_index,MS1_peaks] = check_sim(MS1_index0,fno,sim_scans,sim_mzs,MS1_index,MS1_peaks);%#ok

% save the results
save(MS1_scanfile,'MS1_index','MS1Type');
save(MS1_peakfile,'MS1_peaks');

%% MS2
% initialize the MS2 info
pmass = 1.007276;
maxMS2num = 1.5e5;% initial MS2 scan number
totalpeaknum = 4e7;% the init total peak number on MS2 scans
MS2_index = zeros([maxMS2num,9]);% MS1 scan,MS1 rt,MS2 scan,m/z,z,Fragtype,MS2 peak num,baseline,mz digital no
MS2_peaks = zeros([totalpeaknum,2]);% m/z and intensity on MS2
fno = 0;% real MS2 scan number
pkno = 0;% real total peak number

num_MS1 = size(MS1_index,1);

% get the MS2 info
% for progress
ct_prt = 0;
fprintf(1,'MS2 scans: ');

% start to process
for ino=1:ntotalscans
    cur_scan = out.scan(ino);
    if cur_scan.msLevel<=1
        continue;
    end
    
    % progress
    fno = fno + 1;
    fprintf(repmat('\b',[1,ct_prt]));
    ct_prt = fprintf('%i',fno);
    
    % 1.get the MS2 info
    tmp_datam = zeros(1,10);
    
    % MS2 scan MS2 scan m/z
    scan_no = cur_scan.num;
    pre_mz = cur_scan.precursorMz.value;
    tmp_datam(1:3) = [scan_no scan_no pre_mz];
    
    % RetTime
    tmp_datam(6) = str2double(cur_scan.retentionTime(3:end-1))/60;% min
    
    % MS1 scan
    p = find(MS1_index(1:num_MS1,1)<=tmp_datam(2));
    if 0==isempty(p)
        tmp_datam(1) = MS1_index(p(end),1);
        tmp_datam(6) = MS1_index(p(end),2);
    end
    
    % ActivationType
    tmp_str = cur_scan.precursorMz.activationMethod;
    if 1==strcmp( tmp_str,'CID' )
        tmp_datam(9) = 1;
    elseif 1==strcmp( tmp_str,'ETD' )
        tmp_datam(9) = 2;
    elseif 1==strcmp( tmp_str,'HCD' )
        tmp_datam(9) = 3;
    end
    
    % InstrumentType
    tmp_str = cur_scan.filterLine(1:4);
    if 1==strcmp( tmp_str,'ITMS' )
        tmp_datam(10) = 1;
    elseif 1==strcmp( tmp_str,'FTMS' )
        tmp_datam(10) = 2;
    end
    
    % Fragtype
    tmp_datam(7) = (tmp_datam(9)-1)*2 + tmp_datam(10);% MS2dirs = {'CIDIT','CIDFT','ETDIT','ETDFT','HCDIT','HCDFT'};
    
    mz_digitalno = 4;
    premz_str = num2str(pre_mz,'%.4f');
    if 1==strcmp(premz_str(end-1:end),'00')
        mz_digitalno = 2;
    end
    
    % z; MH
    tmp_datam(4) = 2;
    pre_ch = cur_scan.precursorMz.precursorCharge;
    if 0==isempty(pre_ch)
        tmp_datam(4) = pre_ch;
    end
    tmp_datam(5) = tmp_datam(3)*tmp_datam(4)-(tmp_datam(4)-1)*pmass;
    
    % 2.read the MS2 data
    mz = cur_scan.peaks.mz(1:2:end);
    inten = cur_scan.peaks.mz(2:2:end);
    IX = find(inten>0);% first read, then filter
    mz = mz(IX);
    inten = inten(IX);
    
    % 4.save the MS2 info and peaks
    if 1==isempty(mz)
        fno = fno - 1;
        continue;
    end
    if length(inten)>200
        baseline = GetBaseline(inten);
        IX = find(inten>=min([baseline 500]));
        mz = mz(IX);
        inten = inten(IX);
    else
        baseline = 0;
    end
    npk = length(mz);
    
    x = [1 6 2 3 4 7];
    new_datam = tmp_datam(x);
    MS2_index(fno,1:9) = [new_datam npk baseline mz_digitalno];
    MS2_peaks(pkno+1:pkno+npk,1) = mz;
    MS2_peaks(pkno+1:pkno+npk,2) = inten;
    pkno = pkno + npk;
end
fprintf(repmat('\b',[1,ct_prt]));
fprintf('%i',fno);
fprintf(1,'\n');

% save the MS2 info
% filter the empty values
if fno<maxMS2num
    IX = 1:fno;
    MS2_index = MS2_index(IX,:);
end
tmp = MS2_index(1:fno,7);
MS2_index(1:fno,7) = cumsum(tmp) + 1;%#ok

if pkno<totalpeaknum
    IX = 1:pkno;
    MS2_peaks = MS2_peaks(IX,:);%#ok
end

% save the results
save(MS2_scanfile,'MS2_index');
save(MS2_peakfile,'MS2_peaks');

success = 1;

function baseline = GetBaseline(inten)
%% GetBaseline

loginten = log10(inten);
t = min(loginten):0.08:max(loginten);
[n,xout] = hist(loginten,t);

[tmp,idx] = max(n);%#ok
baseline = 10^xout(idx);

function [MS1_index,MS1_peaks] = check_sim(MS1_index0,fno,sim_scans,sim_mzs,MS1_index,MS1_peaks)
%%

% check sim
nsim = 0;
nlim = 200;
if length(sim_mzs)>nlim
    delta_mz = max(sim_mzs)-min(sim_mzs);
    if delta_mz<2
        nsim = 1;
    else
        t = min(sim_mzs):2:max(sim_mzs);
        [n,xout] = hist(sim_mzs,t);%#ok
        if max(n)>nlim% sim
            nsim = 1;
        end
    end
end
if 0==nsim
    return;
end

% MS1_peaks01, MS1_peaks02
nMS1Peaklen = max(MS1_index0(1:fno,3));
MS1_peaks01 = zeros([fno,nMS1Peaklen]);
MS1_peaks02 = zeros([fno,nMS1Peaklen]);
index = [1;MS1_index(1:fno,3)];
for ino=1:fno
    X = index(ino):index(ino+1)-1;
    mz = MS1_peaks(X,1);
    inten = MS1_peaks(X,2);
    npkno = MS1_index0(ino,3);
    MS1_peaks01(ino,1:npkno) = mz';
    MS1_peaks02(ino,1:npkno) = inten';
end

% IX
flags = ones(fno,1);
for ino=1:fno
    if 1==ismember(MS1_index0(ino,1),sim_scans)
        flags(ino) = 0;
    end
end
IX = find(flags==1);

% MS1_index
nMS1 = length(IX);
MS1_index = MS1_index0(IX,:);
tmp = MS1_index(1:nMS1,3);
MS1_index(1:nMS1,3) = cumsum(tmp) + 1;
index = [1;MS1_index(1:nMS1,3)];

% MS1_peaks
MS1_peaks11 = MS1_peaks01(IX,:);
MS1_peaks12 = MS1_peaks02(IX,:);
nlens = MS1_index0(IX,3);
nPeaklen = sum(nlens);
MS1_peaks = zeros([nPeaklen,2]);
for ino=1:nMS1
    X = index(ino):index(ino+1)-1;
    mz = MS1_peaks11(ino,1:nlens(ino));
    inten = MS1_peaks12(ino,1:nlens(ino));
    MS1_peaks(X,1) = mz';
    MS1_peaks(X,2) = inten';
end