function Extract_D3_1(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special)%#ok
%%

%----------------------------
% H3K9ac|K14ac
His.out_filename = 'H3_0206_9_17';
His.pep_seq = 'KSTGGKAPR';
His.mod_short = {'K9ac|K14ac_H3';
    'K9ac|K14ac_D3'};
His.mod_type = {'0,pr;1,pr;6,ac;';
    '0,pr;1,pr;6,acD3;'};
His.pep_ch = repmat([1 2 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H3K9me1K14ac
His.out_filename = 'H3_0207_9_17';
His.pep_seq = 'KSTGGKAPR';
His.mod_short = {'K9me1K14ac_H3';
    'K9me1K14ac_D3'};
His.mod_type = {'0,pr;1,me1;6,ac;';
    '0,pr;1,me1;6,acD3;'};
His.pep_ch = repmat([1 2 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H3K9me2K14ac
His.out_filename = 'H3_0208_9_17';
His.pep_seq = 'KSTGGKAPR';
His.mod_short = {'K9me2K14ac_H3';
    'K9me2K14ac_D3'};
His.mod_type = {'0,pr;1,me2;6,ac;';
    '0,pr;1,me2;6,acD3;'};
His.pep_ch = repmat([1 2 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H3K9me3K14ac
His.out_filename = 'H3_0209_9_17';
His.pep_seq = 'KSTGGKAPR';
His.mod_short = {'K9me3K14ac_H3';
    'K9me3K14ac_D3'};
His.mod_type = {'0,pr;1,me3;6,ac;';
    '0,pr;1,me3;6,acD3;'};
His.pep_ch = repmat([1 2 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H3K9acK14ac
His.out_filename = 'H3_0210_9_17';
His.pep_seq = 'KSTGGKAPR';
His.mod_short = {'K9acK14ac_(H3)2';
    'K9acK14ac_(D3)1';
    'K9acK14ac_(D3)2'};
His.mod_type = {'0,pr;1,ac;6,ac;';
    '0,pr;1,ac;6,acD3;';
    '0,pr;1,acD3;6,acD3;';};
His.pep_ch = repmat([1 2 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H3K18ac|K23ac
His.out_filename = 'H3_0306_18_26';
His.pep_seq = 'KQLATKAAR';
His.mod_short = {'K18ac|K23ac_H3';
    'K18ac|K23ac_D3'};
His.mod_type = {'0,pr;1,pr;6,ac;';
    '0,pr;1,pr;6,acD3;'};
His.pep_ch = repmat([1 2 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H3K18acK23ac
His.out_filename = 'H3_0307_18_26';
His.pep_seq = 'KQLATKAAR';
His.mod_short = {'K18acK23ac_(H3)2';
    'K18acK23ac_(D3)1';
    'K18acK23ac_(D3)2'};
His.mod_type = {'0,pr;1,ac;6,ac;';
    '0,pr;1,ac;6,acD3;';
    '0,pr;1,acD3;6,acD3;'};
His.pep_ch = repmat([1 2 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H3K27ac
His.out_filename = 'H3_0415_27_40';
His.pep_seq = 'KSAPATGGVKKPHR';
His.mod_short = {'K27ac_H3';
    'K27ac_D3'};
His.mod_type = {'0,pr;1,ac;10,pr;11,pr;';
    '0,pr;1,acD3;10,pr;11,pr;'};
His.pep_ch = repmat([2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 1;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H33K27ac
His.out_filename = 'H3_04v315_27_40';
His.pep_seq = 'KSAPSTGGVKKPHR';
His.mod_short = {'K27ac_H3';
    'K27ac_D3'};
His.mod_type = {'0,pr;1,ac;10,pr;11,pr;';
    '0,pr;1,acD3;10,pr;11,pr;'};
His.pep_ch = repmat([2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 1;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H4K5K8K12K16-1ac
His.out_filename = 'H4_0105_4_17';
His.pep_seq = 'GKGGKGLGKGGAKR';
His.mod_short = {'K5K8K12K16-1ac_H3';
    'K5K8K12K16-1ac_D3'};
His.mod_type = {'0,pr;2,pr;5,pr;9,pr;13,ac;';
    '0,pr;2,pr;5,pr;9,pr;13,acD3;'};
His.pep_ch = repmat([1 2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H4K5K8K12K16-2ac
His.out_filename = 'H4_0111_4_17';
His.pep_seq = 'GKGGKGLGKGGAKR';
His.mod_short = {'K5K8K12K16-2ac_(H3)2';
    'K5K8K12K16-2ac_(D3)1';
    'K5K8K12K16-2ac_(D3)2'};
His.mod_type = {'0,pr;2,pr;5,pr;9,ac;13,ac;';
    '0,pr;2,pr;5,pr;9,ac;13,acD3;';
    '0,pr;2,pr;5,pr;9,acD3;13,acD3;'};
His.pep_ch = repmat([1 2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H4K5K8K12K16-3ac
His.out_filename = 'H4_0115_4_17';
His.pep_seq = 'GKGGKGLGKGGAKR';
His.mod_short = {'K5K8K12K16-3ac_(H3)3';
    'K5K8K12K16-3ac_(D3)1';
    'K5K8K12K16-3ac_(D3)2';
    'K5K8K12K16-3ac_(D3)3'};
His.mod_type = {'0,pr;2,pr;5,ac;9,ac;13,ac;';
    '0,pr;2,pr;5,ac;9,ac;13,acD3;';
    '0,pr;2,pr;5,ac;9,acD3;13,acD3;';
    '0,pr;2,pr;5,acD3;9,acD3;13,acD3;'};
His.pep_ch = repmat([1 2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H4K5K8K12K16-4ac
His.out_filename = 'H4_0116_4_17';
His.pep_seq = 'GKGGKGLGKGGAKR';
His.mod_short = {'K5K8K12K16-4ac_(H3)4';
    'K5K8K12K16-4ac_(D3)1';
    'K5K8K12K16-4ac_(D3)2';
    'K5K8K12K16-4ac_(D3)3';
    'K5K8K12K16-4ac_(D3)4'};
His.mod_type = {'0,pr;2,ac;5,ac;9,ac;13,ac;';
    '0,pr;2,ac;5,ac;9,ac;13,acD3;';
    '0,pr;2,ac;5,ac;9,acD3;13,acD3;';
    '0,pr;2,ac;5,acD3;9,acD3;13,acD3;';
    '0,pr;2,acD3;5,acD3;9,acD3;13,acD3;'};
His.pep_ch = repmat([1 2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H2AK5ac|K9ac
His.out_filename = 'HH2A_02m103_4_11';
His.pep_seq = 'GKQGGKAR';
His.mod_short = {'K5ac|K9ac_H3';
    'K5ac|K9ac_D3'};
His.mod_type = {'0,pr;2,pr;6,ac;';
    '0,pr;2,pr;6,acD3;'};
His.pep_ch = repmat([1 2],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H2AK5acK9ac
His.out_filename = 'HH2A_02m104_4_11';
His.pep_seq = 'GKQGGKAR';
His.mod_short = {'K5acK9ac_(H3)2';
    'K5acK9ac_(D3)1';
    'K5acK9ac_(D3)2'};
His.mod_type = {'0,pr;2,ac;6,ac;';
    '0,pr;2,ac;6,acD3;';
    '0,pr;2,acD3;6,acD3;'};
His.pep_ch = repmat([1 2],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H2AVK4K7K11K15-1ac
His.out_filename = 'HH2A_03oV05_1_19';
His.pep_seq = 'AGGKAGKDSGKAKAKAVSR';
His.mod_short = {'K4K7K11K15-1ac_H3';
    'K4K7K11K15-1ac_D3'};
His.mod_type = {'0,pr;4,pr;7,pr;11,pr;13,pr;15,ac;';
    '0,pr;4,pr;7,pr;11,pr;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H2AVK4K7K11K15-2ac
His.out_filename = 'HH2A_03oV11_1_19';
His.pep_seq = 'AGGKAGKDSGKAKAKAVSR';
His.mod_short = {'K4K7K11K15-2ac_(H3)2';
    'K4K7K11K15-2ac_(D3)1';
    'K4K7K11K15-2ac_(D3)2'};
His.mod_type = {'0,pr;4,pr;7,pr;11,ac;13,pr;15,ac;';
    '0,pr;4,pr;7,pr;11,ac;13,pr;15,acD3;';
    '0,pr;4,pr;7,pr;11,acD3;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H2AVK4K7K11K15-3ac
His.out_filename = 'HH2A_03oV12_1_19';
His.pep_seq = 'AGGKAGKDSGKAKAKAVSR';
His.mod_short = {'K4K7K11K15-3ac_(H3)3';
    'K4K7K11K15-3ac_(D3)1';
    'K4K7K11K15-3ac_(D3)2';
    'K4K7K11K15-3ac_(D3)3'};
His.mod_type = {'0,pr;4,pr;7,ac;11,ac;13,pr;15,ac;';
    '0,pr;4,pr;7,ac;11,ac;13,pr;15,acD3;';
    '0,pr;4,pr;7,ac;11,acD3;13,pr;15,acD3;';
    '0,pr;4,pr;7,acD3;11,acD3;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H2AVK4K7K11K15-4ac
His.out_filename = 'HH2A_03oV16_1_19';
His.pep_seq = 'AGGKAGKDSGKAKAKAVSR';
His.mod_short = {'K4K7K11K15-4ac_(H3)4';
    'K4K7K11K15-4ac_(D3)1';
    'K4K7K11K15-4ac_(D3)2';
    'K4K7K11K15-4ac_(D3)3';
    'K4K7K11K15-4ac_(D3)4'};
His.mod_type = {'0,pr;4,ac;7,ac;11,ac;13,pr;15,ac;';
    '0,pr;4,ac;7,ac;11,ac;13,pr;15,acD3;';
    '0,pr;4,ac;7,ac;11,acD3;13,pr;15,acD3;';
    '0,pr;4,ac;7,acD3;11,acD3;13,pr;15,acD3;';
    '0,pr;4,acD3;7,acD3;11,acD3;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H2AZK4K7K11K15-1ac
His.out_filename = 'HH2A_03oZ05_1_19';
His.pep_seq = 'AGGKAGKDSGKAKTKAVSR';
His.mod_short = {'K4K7K11K15-1ac_H3';
    'K4K7K11K15-1ac_D3'};
His.mod_type = {'0,pr;4,pr;7,pr;11,pr;13,pr;15,ac;';
    '0,pr;4,pr;7,pr;11,pr;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H2AZK4K7K11K15-2ac
His.out_filename = 'HH2A_03oZ11_1_19';
His.pep_seq = 'AGGKAGKDSGKAKTKAVSR';
His.mod_short = {'K4K7K11K15-2ac_(H3)2';
    'K4K7K11K15-2ac_(D3)1';
    'K4K7K11K15-2ac_(D3)2'};
His.mod_type = {'0,pr;4,pr;7,pr;11,ac;13,pr;15,ac;';
    '0,pr;4,pr;7,pr;11,ac;13,pr;15,acD3;';
    '0,pr;4,pr;7,pr;11,acD3;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H2AZK4K7K11K15-3ac
His.out_filename = 'HH2A_03oZ12_1_19';
His.pep_seq = 'AGGKAGKDSGKAKTKAVSR';
His.mod_short = {'K4K7K11K15-3ac_(H3)3';
    'K4K7K11K15-3ac_(D3)1';
    'K4K7K11K15-3ac_(D3)2';
    'K4K7K11K15-3ac_(D3)3'};
His.mod_type = {'0,pr;4,pr;7,ac;11,ac;13,pr;15,ac;';
    '0,pr;4,pr;7,ac;11,ac;13,pr;15,acD3;';
    '0,pr;4,pr;7,ac;11,acD3;13,pr;15,acD3;';
    '0,pr;4,pr;7,acD3;11,acD3;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

% H2AZK4K7K11K15-4ac
His.out_filename = 'HH2A_03oZ16_1_19';
His.pep_seq = 'AGGKAGKDSGKAKTKAVSR';
His.mod_short = {'K4K7K11K15-4ac_(H3)4';
    'K4K7K11K15-4ac_(D3)1';
    'K4K7K11K15-4ac_(D3)2';
    'K4K7K11K15-4ac_(D3)3';
    'K4K7K11K15-4ac_(D3)4'};
His.mod_type = {'0,pr;4,ac;7,ac;11,ac;13,pr;15,ac;';
    '0,pr;4,ac;7,ac;11,ac;13,pr;15,acD3;';
    '0,pr;4,ac;7,ac;11,acD3;13,pr;15,acD3;';
    '0,pr;4,ac;7,acD3;11,acD3;13,pr;15,acD3;';
    '0,pr;4,acD3;7,acD3;11,acD3;13,pr;15,acD3;'};
His.pep_ch = repmat([2 3 4 5],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

%----------------------------
% H2AK13ac|K15ac
His.out_filename = 'HH2A_04m103_12_17';
His.pep_seq = 'AKAKTR';
His.mod_short = {'K13ac|K15ac_H3';
    'K13ac|K15ac_D3'};
His.mod_type = {'0,pr;2,pr;4,ac;';
    '0,pr;2,pr;4,acD3;'};
His.pep_ch = repmat([1 2],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.display = ones(length(His.mod_type),1);
main_ch_idx = 2;
get_C13_info(MS1_index,MS1_peaks,special,His,main_ch_idx);

fprintf(1,'\n');