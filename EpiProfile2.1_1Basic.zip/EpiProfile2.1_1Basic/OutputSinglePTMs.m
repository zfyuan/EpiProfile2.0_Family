function OutputSinglePTMs(layout_path,raw_names,extends,nSTD)
%%

% npeps
npeps = 0;
i = 1;
cur_rawname = raw_names{i};
if i<10
    prefix = ['0',num2str(i)];
else
    prefix = num2str(i);
end
cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail',extends);
out_file1 = fullfile(cur_outpath,'*.mat');
matfiles = dir(out_file1);
for j=1:length(matfiles)
    matfile1 = fullfile(cur_outpath,matfiles(j).name);
    load(matfile1);%#ok
    cnp = size(His.pep_mz,1);
    pepname = matfiles(j).name(1:end-4);
    if 1==strcmp(pepname(1:2),'HH')
        pepname = pepname(2:end);
    end
    if 1==strcmp(pepname(1:2),'H3')
        npeps = npeps + cnp;
    elseif 1==strcmp(pepname(1:2),'H4')
        npeps = npeps + cnp;
    end
end

% peptides
m = 0;
peptides = repmat({''},[npeps,1]);
out_file1 = fullfile(cur_outpath,'*.mat');
matfiles = dir(out_file1);
for j=1:length(matfiles)
    matfile1 = fullfile(cur_outpath,matfiles(j).name);
    load(matfile1);%#ok
    pepname = matfiles(j).name(1:end-4);
    if 1==strcmp(pepname(1:2),'HH')
        pepname = pepname(2:end);
    end
    p = strfind(pepname,'_');
    version = pepname(p(1)+1:p(2)-1);
    
    bvar = 0;
    if length(version)>=4
        if 1==strcmp(pepname(1:7),'H3_04v3')
            version = version(4);
        else
            version = version(4:end);
        end
        histone_pos = [pepname(1:p(1)-1),version,'_',pepname(p(2)+1:p(3)-1),'_',pepname(p(3)+1:end)];
    elseif length(version)==3 && version(3)=='v'
        bvar = 1;
        histone_pos = ['_',pepname(p(2)+1:p(3)-1),'_',pepname(p(3)+1:end)];
    else
        histone_pos = [pepname(1:p(1)-1),'_',pepname(p(2)+1:p(3)-1),'_',pepname(p(3)+1:end)];
    end
    
    nlen = size(His.pep_mz,1);
    for ino = m+1:m+nlen
        if 1==bvar
            x = strfind(His.mod_short{ino-m},'.');
            if 1==strcmp(pepname(1:3),'H2B')
                peptides{ino,1} = ['H2B',His.mod_short{ino-m}(1:x(1)-1),histone_pos];
            else
                peptides{ino,1} = [His.mod_short{ino-m}(1:x(1)-1),histone_pos];
            end
        else
            peptides{ino,1} = [histone_pos,' ',His.mod_short{ino-m}];
        end
    end
    m = m+nlen;
    if m==npeps
        break;
    end
end

% info
info = zeros([npeps,length(raw_names)*3]);
for i=1:length(raw_names)
    cur_rawname = raw_names{i};
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail',extends);
    m = 0;
    for j = 1:length(matfiles)
        matfile1 = fullfile(cur_outpath,matfiles(j).name);
        load(matfile1);%#ok
        nlen = size(His.pep_mz,1);
        info(m+1:m+nlen,(i-1)*3+1:(i-1)*3+3) = auc;
        m = m+nlen;
        if m==npeps
            break;
        end
    end
end

% collect RT, Area, Ratio, respectively
info0 = zeros([npeps,length(raw_names)*3]);
for jno=1:length(raw_names)
    info0(:,jno) = info(:,(jno-1)*3+1);
end
for jno=1:length(raw_names)
    info0(:,length(raw_names)+jno) = info(:,(jno-1)*3+2);
end
for jno=1:length(raw_names)
    info0(:,2*length(raw_names)+jno) = info(:,(jno-1)*3+3);
end
info = info0;
info_ratio = info(1:npeps,2*length(raw_names)+1:3*length(raw_names));

%% single_PTMs
% targets
targets = {'H3K4me1';
    'H3K4me2';
    'H3K4me3';
    'H3K4ac';
    'H3K9me1';
    'H3K9me2';
    'H3K9me3';
    'H3K9ac';
    'H3S10ph';
    'H3K14ac';
    'H3K18me1';
    'H3K18ac';
    'H3K23me1';
    'H3K23ac';
    'H31K27me1';
    'H31K27me2';
    'H31K27me3';
    'H31K27ac';
    'H31K36me1';
    'H31K36me2';
    'H31K36me3';
    'H33K27me1';
    'H33K27me2';
    'H33K27me3';
    'H33K27ac';
    'H33K36me1';
    'H33K36me2';
    'H33K36me3';
    'H3K56me1';
    'H3K56me2';
    'H3K56me3';
    'H3K56ac';
    'H3K79me1';
    'H3K79me2';
    'H3K79me3';
    'H3K79ac';
    'H3K122ac';
    'H4K5ac';
    'H4K8ac';
    'H4K12ac';
    'H4K16ac';
    'H4K20me1';
    'H4K20me2';
    'H4K20me3';
    'H4K20ac'};

sratios = zeros([length(targets),length(raw_names)]);
for t=1:length(targets)
    c_pep = targets{t};
    if 1==strcmp(c_pep(1:3),'H31')
        X1 = [];
        no = 0;
        for p=1:npeps
            if 0==isempty(strfind(peptides{p},'H3_27_40'))
                no = no + 1;
                X1(no) = p;%#ok
            end
        end
        c_mod = c_pep(4:end);
    elseif 1==strcmp(c_pep(1:3),'H33')
        X1 = [];
        no = 0;
        for p=1:npeps
            if 0==isempty(strfind(peptides{p},'H33_27_40'))
                no = no + 1;
                X1(no) = p;%#ok
            end
        end
        c_mod = c_pep(4:end);
    else
        X1 = 1:npeps;
        c_mod = c_pep(3:end);
    end
    
    X2 = [];
    no = 0;
    for x=1:length(X1)
        if 0==isempty(strfind(peptides{X1(x)},c_mod))
            no = no + 1;
            X2(no) = X1(x);%#ok
        end
    end
    
    if 0==no
        continue;
    end
    for x=1:length(X2)
        sratios(t,:) = sratios(t,:) + info_ratio(X2(x),:);
    end
end

mat_file = fullfile(layout_path,'histone_ratios_single_PTMs.mat');
save(mat_file,'targets','sratios');

inten_file = fullfile(layout_path,'histone_ratios_single_PTMs.xls');
fp = fopen(inten_file,'w');
if -1==fp
    disp(['can not open: ',inten_file]);
    return;
end

for i=1:length(raw_names)
    fprintf(fp,'\t%d,%s',i,raw_names{i});
end
fprintf(fp,'\r\n');

for t=1:length(targets)
    fprintf(fp,'%s',targets{t});
    for jno=1:length(raw_names)
        fprintf(fp,'\t%f',sratios(t,jno));
    end
    fprintf(fp,'\r\n');
end

fclose(fp);

%% single_PTMs_STD
if 0==nSTD
    return;
end

% get clusters of RAW files
clusters = zeros(1,length(raw_names));
comprefix = {};
cno = 0;
for i=1:length(raw_names)-1
    for j=i+1:length(raw_names)
        tmpstr = get_prefix(raw_names{i},raw_names{j});
        if 0==isempty(tmpstr)
            cno = cno + 1;
            comprefix{cno,1} = tmpstr;%#ok
        end
    end
end
if cno>0
    comprefix_u = unique(comprefix);
    if length(comprefix_u)>1
        flags = ones(1,length(comprefix_u));
        for i=1:length(comprefix_u)-1
            for j=i+1:length(comprefix_u)
                tmpstr = get_prefix(comprefix_u{i},comprefix_u{j});
                if 1==strcmp(tmpstr,comprefix_u{i})
                    flags(i) = 0;
                elseif 1==strcmp(tmpstr,comprefix_u{j})
                    flags(j) = 0;
                end
            end
        end
        ix = find(flags==1);
        comprefix_u = comprefix_u(ix);%#ok
    end
    for i=1:length(raw_names)
        for j=1:length(comprefix_u)
            pos = strfind(raw_names{i},comprefix_u{j});
            if 0==isempty(pos) && 1==pos(1)
                clusters(i) = j;
                break;
            end
        end
        if 0==clusters(i)
            clusters(i) = length(comprefix_u)+1;
        end
    end
else
    clusters = ones(1,length(raw_names));
end

clusters_u = unique(clusters);
matrix = zeros(length(clusters_u),length(raw_names));
clusters_name = repmat({''},[length(clusters_u),1]);
for i=1:length(clusters_u)
    ix = find(clusters==clusters_u(i));
    matrix(i,1:length(ix)) = ix;
    %+
    if 1==length(ix)
        clusters_name{i,1} = raw_names{ix};
    else
        tmpstr = get_prefix(raw_names{ix(1)},raw_names{ix(2)});
        if 0==isempty(tmpstr)
            clusters_name{i,1} = tmpstr;
        else
            clusters_name{i,1} = 'others(';
            for j=1:length(ix)
                if 1==j
                    clusters_name{i,1} = [clusters_name{i,1},raw_names{ix(j)}];
                else
                    clusters_name{i,1} = [clusters_name{i,1},'; ',raw_names{ix(j)}];
                end
            end
            clusters_name{i,1} = [clusters_name{i,1},')'];
        end
    end
    %+
end

% calculate std for each cluster
sratios_avg = zeros([length(targets),length(clusters_u)]);
sratios_std_incorrect = zeros([length(targets),length(clusters_u)]);
sratios_std = zeros([length(targets),length(clusters_u)]);
for t=1:length(targets)
    c_pep = targets{t};
    if 1==strcmp(c_pep(1:3),'H31')
        X1 = [];
        no = 0;
        for p=1:npeps
            if 0==isempty(strfind(peptides{p},'H3_27_40'))
                no = no + 1;
                X1(no) = p;%#ok
            end
        end
        c_mod = c_pep(4:end);
    elseif 1==strcmp(c_pep(1:3),'H33')
        X1 = [];
        no = 0;
        for p=1:npeps
            if 0==isempty(strfind(peptides{p},'H33_27_40'))
                no = no + 1;
                X1(no) = p;%#ok
            end
        end
        c_mod = c_pep(4:end);
    else
        X1 = 1:npeps;
        c_mod = c_pep(3:end);
    end
    
    X2 = [];
    no = 0;
    for x=1:length(X1)
        if 0==isempty(strfind(peptides{X1(x)},c_mod))
            no = no + 1;
            X2(no) = X1(x);%#ok
        end
    end
    
    if 0==no
        continue;
    end
    for i=1:length(clusters_u)
        c_matrix = matrix(i,:);
        ix = find(c_matrix>0);
        Y = c_matrix(ix);%#ok
        c_info_ratio = info_ratio(X2,Y);
        rowsum = sum(c_info_ratio,1);
        sratios_avg(t,i) = mean(rowsum);
        sratios_std_incorrect(t,i) = std(rowsum);
        c_std = 0;
        for x=1:length(X2)
            c_std = c_std + std(c_info_ratio(x,:))^2;
        end
        sratios_std(t,i) = sqrt(c_std);
    end
end

% single_PTMs_STD
mat_file = fullfile(layout_path,'histone_ratios_single_PTMs_STD.mat');
save(mat_file,'targets','clusters_name','sratios_avg','sratios_std_incorrect','sratios_std');

inten_file = fullfile(layout_path,'histone_ratios_single_PTMs_STD.xls');
fp = fopen(inten_file,'w');
if -1==fp
    disp(['can not open: ',inten_file]);
    return;
end

for i=1:length(clusters_name)
    fprintf(fp,'\t%d,%s',i,clusters_name{i});
end
fprintf(fp,'\r\n');

fprintf(fp,'AVG\r\n');
for t=1:length(targets)
    fprintf(fp,'%s',targets{t});
    for jno=1:length(clusters_name)
        fprintf(fp,'\t%f',sratios_avg(t,jno));
    end
    fprintf(fp,'\r\n');
end

fprintf(fp,'\r\nSTD\r\n');
for t=1:length(targets)
    fprintf(fp,'%s',targets{t});
    for jno=1:length(clusters_name)
        fprintf(fp,'\t%f',sratios_std(t,jno));
    end
    fprintf(fp,'\r\n');
end

fprintf(fp,'\r\nSTD_incorrect(based on sum of peptides)\r\n');
for t=1:length(targets)
    fprintf(fp,'%s',targets{t});
    for jno=1:length(clusters_name)
        fprintf(fp,'\t%f',sratios_std_incorrect(t,jno));
    end
    fprintf(fp,'\r\n');
end

fclose(fp);

function comprefix = get_prefix(str1,str2)
%%

comprefix = '';
nlen = min([length(str1) length(str2)]);
for i=1:nlen
    if str1(i)~=str2(i)
        break;
    end
end
if i==1
    if str1(i)==str2(i)
        comprefix = str1(1:i);
    end
else
    if str1(i)==str2(i)
        comprefix = str1(1:i);
    else
        comprefix = str1(1:i-1);
    end
end