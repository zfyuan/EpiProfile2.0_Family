function draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special)
%%

cur_outpath = special.outpath;
out_filename = special.outfile;

npep = size(His.pep_mz,1);
ix = find(pep_rts(1:npep,1)>3 & His.display==1);
if 1==isempty(ix)
    return;
end

% localmax_rt, localmax_inten, terminus
nplot = length(ix);
localmax_rt = zeros([nplot,1]);
localmax_inten = zeros([nplot,1]);
terminus = zeros([nplot,2]);
for ino=1:nplot
    cno = ix(ino);
    p = find(isorts<=pep_rts(cno,1));
    c_ms1pos = p(end);
    c_mono_isointens = mono_isointens(:,cno);
    localmax_rt(ino) = pep_rts(cno,1);
    if pep_intens(cno,1)>0 && sum(c_mono_isointens)>0
        [nt,nb,top1_idx,inten_sum,nb1,nb2] = GetTopBottom11(c_mono_isointens);%#ok
        terminus(ino,1:2) = [nb1(top1_idx) nb2(top1_idx)];
        localmax_inten(ino) = max(c_mono_isointens(nb1(top1_idx):nb2(top1_idx)));
    else
        terminus(ino,1:2) = [c_ms1pos c_ms1pos];
    end
end

maxinten = max(localmax_inten);%#ok
st = max([isorts(min(terminus(1:nplot,1)))-1 1]);
tm = isorts(max(terminus(1:nplot,2)))+8;

out_file1 = fullfile(fileparts(cur_outpath),out_filename);

if 1==special.nformat
    sformat = '-dpdf';
elseif 2==special.nformat
    sformat = '-dpng';
else
    sformat = '-dtiff';
end

warning off all;
set(gcf,'visible','off');
% set(gcf,'position',[0 0 1000 1000]);
if 1==strcmp(out_filename(1:2),'HH')
    out_filename = out_filename(2:end);
end
p = strfind(out_filename,'_');
cur_title = [out_filename(1:p(1)-1),' ',out_filename(p(2)+1:p(3)-1),'-',out_filename(p(3)+1:end),' ',His.pep_seq,repmat(' ',1,90)];

for ino=1:nplot
    cno = ix(ino);
    
    subplot(nplot,1,ino);
    plot(isorts,mono_isointens(:,cno),'color','b','linewidth',1);
    set(gca,'xtick',[],'ytick',[]);
    hold on;
    xlim([st tm]);
    if localmax_inten(ino)>0
        ylim([0 1.05*localmax_inten(ino)]);
    end
    
    % localmax
    % cut '+' and '0' after 'e'
    str_inten = num2str(localmax_inten(ino),'%.1e');
    if 1==strcmp(str_inten(end-1),'0')
        str_tail = str_inten(end);
    else
        str_tail = str_inten(end-1:end);
    end
    str_inten = [str_inten(1:4),str_tail];
    %
    cur_txt = [His.mod_short{cno},',+',num2str(His.pep_ch(cno,1)),', ',num2str(localmax_rt(ino),'%.1f'),', ',str_inten];
    if 1==nplot
        text(localmax_rt(ino),1.05*localmax_inten(ino),cur_txt,'color','r','fontsize',9);
    elseif 2==nplot
        text(localmax_rt(ino),1.15*localmax_inten(ino),cur_txt,'color','r','fontsize',9);
    else
        text(localmax_rt(ino),1.25*localmax_inten(ino),cur_txt,'color','r','fontsize',9);
    end
    
    % boundary
    plot([isorts(terminus(ino,1)) isorts(terminus(ino,2))],[0 0],'color','m','linewidth',1);
    if 1==ino
        title(cur_title);
    end
end
set(gca,'xtickMode', 'auto');
xlabel('Time (min)','FontWeight','bold');
ylabel('Abundance','FontWeight','bold');
print(sformat,'-r300',out_file1);
close();