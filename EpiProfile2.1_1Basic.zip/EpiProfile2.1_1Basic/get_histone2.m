function [cur_rts,cur_intens,cur_mono_isointens] = get_histone2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno)
%%

npart = 2;
[npep,ncharge] = size(His.pep_mz);%#ok
cur_rts = zeros([npart,ncharge]);
cur_intens = zeros([npart,ncharge]);
num_MS1 = size(MS1_index,1);
cur_mono_isointens = zeros([num_MS1,npart]);

[h_rts,h_intens,h_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if 0==h_intens(1)
    return;
end

[s_rts,ratio,cur_mono_isointens] = get_ratio_2iso(MS1_index,MS2_index,MS2_peaks,special,His,hno,h_rts,h_mono_isointens);
cur_rts(1,1:ncharge) = repmat(s_rts(1),[1,ncharge]);
cur_rts(2,1:ncharge) = repmat(s_rts(2),[1,ncharge]);
cur_intens(1,1:ncharge) = h_intens*ratio(1);
cur_intens(2,1:ncharge) = h_intens*ratio(2);

function [s_rts,ratio,cur_mono_isointens] = get_ratio_2iso(MS1_index,MS2_index,MS2_peaks,special,His,hno,h_rts,h_mono_isointens)
%%

npart = 2;
num_MS1 = size(MS1_index,1);
nDAmode = special.nDAmodes(special.c_rno);
c_isorts = MS1_index(1:num_MS1,2);
c_mono_isointens = h_mono_isointens;

% fCali
M = His.pep_mz(hno,1)*His.pep_ch(hno,1)-His.pep_ch(hno,1)*1.007276;
tIPV = special.IPV(floor(M),1:5);
fCali = sum(tIPV);

delta = 0.5;
rt1 = His.rt_ref(hno)-delta;
rt2 = His.rt_ref(hno)+delta;
[ms2pos,ms2rts,ms2intens1,ms2intens2] = MatchMS2_2(MS2_index,MS2_peaks,special,His,hno,rt1,rt2);%#ok
if 1==isempty(ms2pos)
    s_rts = repmat(h_rts(1),[1,npart]);
    ratio = repmat(1/npart,[1,npart]);
    cur_mono_isointens = [c_mono_isointens c_mono_isointens].*ratio;
    return;
end

% IX on MS1
if 1==nDAmode
    [nt,nb,top1_idx,inten_sum,nb1,nb2] = GetTopBottom11(c_mono_isointens);%#ok
    IX = nb1(1):nb2(end);
    if length(ms2pos)>=length(IX)/2
        IX = zeros([length(ms2pos),1]);
        for i=1:length(ms2pos)
            pp = find(MS1_index(:,1)<=MS2_index(ms2pos(i),1));
            IX(i) = pp(end);
        end
    end
    IX = unique(IX);
    tIX = IX(1):IX(end);
    IX = tIX;
else
    IX = zeros([length(ms2pos),1]);
    for i=1:length(ms2pos)
        pp = find(MS1_index(:,1)<=MS2_index(ms2pos(i),1));
        IX(i) = pp(end);
    end
end

% ratios for profile
nlen = length(IX);
if 1==nDAmode && length(ms2pos)<=ceil(nlen/2)
    area1 = sum(sum(ms2intens1,1));
    area2 = sum(sum(ms2intens2,1));
    ratiox1 = area1/(eps+area1+area2);
    ratio = [ratiox1 1-ratiox1];
    s_rts = repmat(h_rts(1),[1,npart]);
    cur_mono_isointens = [c_mono_isointens c_mono_isointens].*ratio;
    
    n_rt = c_isorts(IX);
    n_inten1 = c_mono_isointens(IX);
    n_inten2 = n_inten1.*ratio(1);
    n_inten3 = n_inten1.*ratio(2);
else
    ms1scans = MS2_index(ms2pos,1);
    ratio1 = zeros([nlen,1]);
    fintens1 = zeros([nlen,1]);
    fintens2 = zeros([nlen,1]);
    for i=1:nlen
        c_scan = MS1_index(IX(i),1);
        [tf,loc] = ismember(c_scan,ms1scans);
        if 1==tf
            intens1 = ms2intens1(ms2pos(loc),:);
            intens2 = ms2intens2(ms2pos(loc),:);
            ratio1(i) = sum(intens1)/(eps+sum(intens1)+sum(intens2));
            fintens1(i) = sum(intens1);
            fintens2(i) = sum(intens2);
        end
    end
    %+
    if His.rt_ref(hno)<=His.rt_ref(hno+1)
        [tmp,x1] = max(ratio1);
        nX1 = x1:nlen;
        x2 = find(ratio1(nX1)<0.1);
        if tmp>0.1 && 0==isempty(x2)
            nX2 = nX1(x2(1)):nlen;
            ratio1(nX2) = 0.001;
            fintens1(nX2) = 0;
        end
    else
        [tmp,x1] = max(ratio1);
        nX1 = 1:x1;
        x2 = find(ratio1(nX1)<0.1);
        if tmp>0.1 && 0==isempty(x2)
            nX2 = 1:nX1(x2(end));
            ratio1(nX2) = 0.001;
            fintens1(nX2) = 0;
        end
    end
    ratiox2 = sum(fintens1)/(eps+sum(fintens1)+sum(fintens2));
    ratio0 = [ratiox2 1-ratiox2];%#ok
    %+
    % ratio1 = smooth(ratio1,3);
    ratio2 = 1-ratio1;
    
    n_rt = c_isorts(IX);
    n_inten1 = c_mono_isointens(IX);
    n_inten2 = n_inten1.*ratio1;
    n_inten3 = n_inten1.*ratio2;
    
    [tmp,x1] = max(n_inten2);%#ok
    [tmp,x2] = max(n_inten3);%#ok
    s_rts = [n_rt(x1) n_rt(x2)];
    
    area1 = get_auc(n_rt,n_inten2,fCali);
    area2 = get_auc(n_rt,n_inten3,fCali);
    ratiox3 = area1/(eps+area1+area2);
    ratio = [ratiox3 1-ratiox3];
    
    if 1==nDAmode
        cur_mono_isointens(:,1) = [zeros([IX(1)-1,1]);n_inten2;zeros([num_MS1-IX(end),1])];
        cur_mono_isointens(:,2) = [zeros([IX(1)-1,1]);n_inten3;zeros([num_MS1-IX(end),1])];
    else
        xx = c_isorts(IX(1):IX(end));
        yy = spline(n_rt,n_inten2,xx);
        cur_mono_isointens(:,1) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
        yy = spline(n_rt,n_inten3,xx);
        cur_mono_isointens(:,2) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
    end
end

if '1'==special.sfigure(2)
    if 1==special.nformat
        sformat = '-dpdf';
    elseif 2==special.nformat
        sformat = '-dpng';
    else
        sformat = '-dtiff';
    end
    
    set(gcf,'visible','off');
    out_file1 = fullfile(special.outpath,['Iso_',special.outfile,'_',His.mod_short{hno},'_',His.mod_short{hno+1}]);
    plot(n_rt,n_inten1,'linestyle','-','linewidth',2,'color','k');
    hold on;
    plot(n_rt,n_inten2,'linestyle','--','linewidth',2,'color','r');
    plot(n_rt,n_inten3,'linestyle','-.','linewidth',2,'color','b');
    xlabel('Time (min)','FontWeight','bold');
    ylabel('Abundance','FontWeight','bold');
    legend('experiment',His.mod_short{hno},His.mod_short{hno+1});
    if ratio(1)<0.03
        r1 = floor(1000*ratio(1))*0.1;
    else
        r1 = floor(100*ratio(1));
    end
    r2 = 100-r1;
    title([His.mod_short{hno},'/',His.mod_short{hno+1},':',num2str(r1),'%:',num2str(r2),'%']);
    print(sformat,out_file1);
    close();
end