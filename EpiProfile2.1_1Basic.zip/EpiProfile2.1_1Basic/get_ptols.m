function [bOK,ptols] = get_ptols(raw_path,raw_names,def_ptol)
%%

def_ptol1 = 50;% FT1
def_ptol2 = 1000;% IT1
def_ptol3 = def_ptol;% FT2, if no 445.12, set as 10 ppm
def_ptol4 = 0.4;% IT2, if no 445.12, set as 0.4 Da

bOK = 1;
ptols = repmat(def_ptol1,[1,length(raw_names)]);
FTs = ones([1,length(raw_names)]);

% ptols
ms1_path = fullfile(raw_path,'MS1');
ptol_file = fullfile(ms1_path,'MS1tol.mat');
if 0~=exist(ptol_file,'file')% MAT file exists
    load(ptol_file);%#ok
    if length(find(FTs==1))==length(raw_names)
        u_ptol = unique(ptols);
        fprintf(1,'MS1 tol:');
        for i=1:length(u_ptol)
            iix = find(ptols==u_ptol(i));
            fprintf(1,' %d ppm:',u_ptol(i));
            for j=1:length(iix)
                fprintf(1,' %d,',iix(j));
            end
        end
    elseif length(find(FTs==0))==length(raw_names)
        fprintf(1,'MS1 tol (Da):');
        for i=1:length(raw_names)
            fprintf(1,' %d: %.1f,',i,ptols(i));
        end
    else
        fprintf(1,'MS1 tol:');
        for i=1:length(raw_names)
            if 1==FTs(i)
                fprintf(1,' %d: %d ppm,',i,ptols(i));
            else
                fprintf(1,' %d: %.1f Da,',i,ptols(i));
            end
        end
    end
    fprintf(1,'\n');
    return;
end

for i=1:length(raw_names)
    load( fullfile(ms1_path,[raw_names{i},'_MS1scans.mat']) );%#ok
    if 1==strcmp(MS1Type,'ITMS')
        ptols(i) = def_ptol2;
        FTs(i) = 0;
    end
end

% ptols
ref_ptols = 10:5:50;
b445_12 = ones([1,length(raw_names)]);
unitdiff = 1.0032;
t_mz = 445.12;
t_ch = 1;
for i=1:length(raw_names)
    load( fullfile(ms1_path,[raw_names{i},'_MS1scans.mat']) );%#ok
    load( fullfile(ms1_path,[raw_names{i},'_MS1peaks.mat']) );%#ok
    num_MS1 = size(MS1_index,1);
    index = [1;MS1_index(1:num_MS1,3)];
    
    % c_isomzs
    c_ref_isomzs = [t_mz-unitdiff/t_ch t_mz t_mz+unitdiff/t_ch];
    nmz = length(c_ref_isomzs);
    c_isomzs = zeros([num_MS1,nmz]);
    for ino = 1:num_MS1
        IX = index(ino):index(ino+1)-1;
        mz = MS1_peaks(IX,1);
        inten = MS1_peaks(IX,2);
        
        tmp_mzs = zeros([1,nmz]);
        for jno=1:nmz
            c_mz = c_ref_isomzs(jno);
            if 1==FTs(i)
                c_ptol = def_ptol1*c_mz*1e-6;
            else
                c_ptol = 0.8;
            end
            left = c_mz - c_ptol;
            right = c_mz + c_ptol;
            pos = find( mz>=left & mz<=right );
            if 0==isempty(pos)
                [tmp,x] = max(inten(pos));%#ok
                tmp_mzs(jno) = mz(pos(x));
            end
        end
        if 0==tmp_mzs(1) && length(find(tmp_mzs(2:end)>0))==nmz-1
            c_isomzs(ino,1:nmz) = tmp_mzs;
        end
    end
    
    % ptols
    c_monomzs = c_isomzs(1:num_MS1,2);
    ix = find(c_monomzs>0);
    if 1==FTs(i)
        if length(ix)<num_MS1/2
            ptols(i) = def_ptol3;
            b445_12(i) = 0;
            continue;
        end
        f_monomzs = c_monomzs(ix);
        c_ptols = repmat(def_ptol3,[1,length(f_monomzs)]);
        for ino=1:length(f_monomzs)
            c_ptols(ino) = (f_monomzs(ino)-t_mz)/t_mz*1e6;
        end
        x = find(c_ptols>mean(c_ptols)-10 & c_ptols<mean(c_ptols)+10);% filter outlier
        c_ptols = c_ptols(x);%#ok
        p_mean = mean(c_ptols);
        p_std = std(c_ptols);
        t_ptol = max([p_mean+8*p_std abs(p_mean-8*p_std)]);
        [tmp,idx] = min(abs(ref_ptols-t_ptol));%#ok
        ptols(i) = ref_ptols(idx);
    else
        if length(ix)<num_MS1/2
            ptols(i) = def_ptol4;
            b445_12(i) = 0;
            continue;
        end
        f_monomzs = c_monomzs(ix);
        c_ptols = repmat(def_ptol4,[1,length(f_monomzs)]);
        for ino=1:length(f_monomzs)
            c_ptols(ino) = f_monomzs(ino)-t_mz;
        end
        p_mean = mean(c_ptols);
        p_std = std(c_ptols);
        ptols(i) = max([p_mean+4*p_std abs(p_mean-4*p_std)]);
    end
end
save(ptol_file,'ptols','FTs','b445_12');

if length(find(FTs==1))==length(raw_names)
    u_ptol = unique(ptols);
    fprintf(1,'MS1 tol:');
    for i=1:length(u_ptol)
        iix = find(ptols==u_ptol(i));
        fprintf(1,' %d ppm:',u_ptol(i));
        for j=1:length(iix)
            fprintf(1,' %d,',iix(j));
        end
    end
elseif length(find(FTs==0))==length(raw_names)
    fprintf(1,'MS1 tol (Da):');
    for i=1:length(raw_names)
        fprintf(1,' %d: %.1f,',i,ptols(i));
    end
else
    fprintf(1,'MS1 tol:');
    for i=1:length(raw_names)
        if 1==FTs(i)
            fprintf(1,' %d: %d ppm,',i,ptols(i));
        else
            fprintf(1,' %d: %.1f Da,',i,ptols(i));
        end
    end
end
fprintf(1,'\n');