function OutputTogetherRT(layout_path,raw_names,extends,ndebug)
%%

% npeps
npeps = 0;
i = 1;
cur_rawname = raw_names{i};
if i<10
    prefix = ['0',num2str(i)];
else
    prefix = num2str(i);
end
cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail',extends);
out_file1 = fullfile(cur_outpath,'*.mat');
matfiles = dir(out_file1);
for j=1:length(matfiles)
    matfile1 = fullfile(cur_outpath,matfiles(j).name);
    load(matfile1);%#ok
    npeps = npeps + size(His.pep_mz,1);
end

% info
info = zeros([npeps,length(raw_names)*3]);
for i=1:length(raw_names)
    cur_rawname = raw_names{i};
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail',extends);
    m = 0;
    for j = 1:length(matfiles)
        matfile1 = fullfile(cur_outpath,matfiles(j).name);
        load(matfile1);%#ok
        nlen = size(His.pep_mz,1);
        info(m+1:m+nlen,(i-1)*3+1:(i-1)*3+3) = auc;
        m = m+nlen;
    end
end

%% histone_ratios
rt_file = fullfile(layout_path,'histone_rts.xls');
fp = fopen(rt_file,'w');
if -1==fp
    disp(['can not open: ',rt_file]);
    return;
end

% raw_names
for i=1:length(raw_names)
    fprintf(fp,'\t%d,%s',i,raw_names{i});
end
fprintf(fp,'\t');
for i=1:length(raw_names)
    fprintf(fp,'\t%d,%s',i,raw_names{i});
end

fprintf(fp,'\t\tmedian\t');
for i=1:length(raw_names)
    fprintf(fp,'\t%d,%s',i,raw_names{i});
end
fprintf(fp,'\r\n');

% title
fprintf(fp,'Peptide');
for i=1:length(raw_names)
    fprintf(fp,'\tRT(min)');
end
fprintf(fp,'\t');
for i=1:length(raw_names)
    fprintf(fp,'\tRT(min)');
end

fprintf(fp,'\t\tRT(min)\t');
for i=1:length(raw_names)
    fprintf(fp,'\tRT(min)');
end
fprintf(fp,'\r\n');

% Ratio (n), Area (n), RT (n)
i = 1;
cur_rawname = raw_names{i};
if i<10
    prefix = ['0',num2str(i)];
else
    prefix = num2str(i);
end
cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail',extends);

rt_tol = 1;

m = 0;
for j=1:length(matfiles)
    matfile1 = fullfile(cur_outpath,matfiles(j).name);
    load(matfile1);%#ok
    pepname = matfiles(j).name(1:end-4);
    fprintf(fp,'%s(%s)\r\n',His.pep_seq,pepname);
    
    nlen = size(His.pep_mz,1);
    
    for ino = m+1:m+nlen
        fprintf(fp,'%s %s',pepname,His.mod_short{ino-m});
        c_rts = zeros(1,length(raw_names));
        for jno=1:length(raw_names)
            c_rts(jno) = info(ino,(jno-1)*3+1);
            fprintf(fp,'\t%.2f',c_rts(jno));
        end
        
        newii = find(c_rts>0);
        if 0==isempty(newii)
            new_rts = c_rts(newii);
            if 0==mod(length(new_rts),2)
                median_rt = median([new_rts,new_rts(end)]);
            else
                median_rt = median(new_rts);
            end
        else
            median_rt = 0;
        end
        
        fprintf(fp,'\t');
        if 0==ndebug
            for jno=1:length(raw_names)
                if abs(c_rts(jno)-median_rt)>rt_tol
                    fprintf(fp,'\t%.2f',median_rt);
                else
                    fprintf(fp,'\t%.2f',c_rts(jno));
                end
            end
        else
            for jno=1:length(raw_names)
                fprintf(fp,'\t%.2f',c_rts(jno));
            end
        end
        
        fprintf(fp,'\t\t%.2f\t',median_rt);
        for jno=1:length(raw_names)
            if abs(c_rts(jno)-median_rt)>rt_tol
                fprintf(fp,'\t%.2f',median_rt);
            else
                fprintf(fp,'\t');
            end
        end
        fprintf(fp,'\r\n');
    end
    m = m+nlen;
end
fclose(fp);