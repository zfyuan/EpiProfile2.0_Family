function [K1,K2,Tag1,Tag2] = get_key_ions1(His,pno,qno,Mods,ActiveType,nhmass,nall)
%%

c_seq = His.pep_seq;
c_mod1 = His.mod_type{pno};
c_mod2 = His.mod_type{qno};

% get_mod_postype
[modpos1,modtype1] = get_mod_postype(c_seq,c_mod1,Mods);
[modpos2,modtype2] = get_mod_postype(c_seq,c_mod2,Mods);

newtype1 = modpos1*10000+modtype1;
newtype2 = modpos2*10000+modtype2;
comtype = intersect(newtype1,newtype2);
uniontype = union(newtype1,newtype2);
lefttype = setdiff(uniontype,comtype );
t1 = floor(min(lefttype)/10000);
if 0==t1
    t1 = 1;
end
t2 = floor(max(lefttype)/10000);
nlen = 2*(t2-t1)*2;
K1 = zeros([1,nlen]);
K2 = zeros([1,nlen]);

Tag1 = repmat({''},[1,nlen]);
Tag2 = repmat({''},[1,nlen]);
if 1==strcmp(ActiveType,'CID')
    strn = 'b';
    strc = 'y';
else
    strn = 'c';
    strc = 'z';
end

peplen = length(c_seq);
posn = t1:t2-1;
posc = (peplen-t2+1):(peplen-t1);

% get_theo_mz
if His.pep_ch(pno,1)>=3
    c_chg = 2;
else
    c_chg = 1;
end
[theo_mz1,theo_tp1] = get_theo_mz(c_seq,c_mod1,c_chg,Mods,ActiveType,nhmass);
[theo_mz2,theo_tp2] = get_theo_mz(c_seq,c_mod2,c_chg,Mods,ActiveType,nhmass);

n1 = find(theo_tp1<2000);
tpn1 = floor( (theo_tp1(n1)-1000)/10 );
c1 = find(theo_tp1>2000);
tpc1 = floor( (theo_tp1(c1)-2000)/10 );

n2 = find(theo_tp2<2000);
tpn2 = floor( (theo_tp2(n2)-1000)/10 );
c2 = find(theo_tp2>2000);
tpc2 = floor( (theo_tp2(c2)-2000)/10 );

if 1==nall
    for ino=1:length(posn)
        loc1 = find(tpn1==posn(ino));
        loc2 = find(tpn2==posn(ino));
        if 1==length(loc1) && 1==length(loc2)
            K1(2*(ino-1)+1) = theo_mz1(n1(loc1));
            K2(2*(ino-1)+1) = theo_mz2(n2(loc2));
            Tag1{1,2*(ino-1)+1} = [strn,num2str(posn(ino)),'+'];
            Tag2{1,2*(ino-1)+1} = [strn,num2str(posn(ino)),'+'];
        elseif 2==length(loc1) && 2==length(loc2)
            K1(2*(ino-1)+1) = theo_mz1(n1(loc1(1)));
            K1(2*(ino-1)+2) = theo_mz1(n1(loc1(2)));
            K2(2*(ino-1)+1) = theo_mz2(n2(loc2(1)));
            K2(2*(ino-1)+2) = theo_mz2(n2(loc2(2)));
            Tag1{1,2*(ino-1)+1} = [strn,num2str(posn(ino)),'+'];
            Tag1{1,2*(ino-1)+2} = [strn,num2str(posn(ino)),'++'];
            Tag2{1,2*(ino-1)+1} = [strn,num2str(posn(ino)),'+'];
            Tag2{1,2*(ino-1)+2} = [strn,num2str(posn(ino)),'++'];
        end
    end
end

for ino=1:length(posc)
    loc1 = find(tpc1==posc(ino));
    loc2 = find(tpc2==posc(ino));
    if 1==length(loc1) && 1==length(loc2)
        K1(2*(length(posn)+ino-1)+1) = theo_mz1(c1(loc1));
        K2(2*(length(posn)+ino-1)+1) = theo_mz2(c2(loc2));
        Tag1{1,2*(length(posn)+ino-1)+1} = [strc,num2str(posc(ino)),'+'];
        Tag2{1,2*(length(posn)+ino-1)+1} = [strc,num2str(posc(ino)),'+'];
    elseif 2==length(loc1) && 2==length(loc2)
        K1(2*(length(posn)+ino-1)+1) = theo_mz1(c1(loc1(1)));
        K1(2*(length(posn)+ino-1)+2) = theo_mz1(c1(loc1(2)));
        K2(2*(length(posn)+ino-1)+1) = theo_mz2(c2(loc2(1)));
        K2(2*(length(posn)+ino-1)+2) = theo_mz2(c2(loc2(2)));
        Tag1{1,2*(length(posn)+ino-1)+1} = [strc,num2str(posc(ino)),'+'];
        Tag1{1,2*(length(posn)+ino-1)+2} = [strc,num2str(posc(ino)),'++'];
        Tag2{1,2*(length(posn)+ino-1)+1} = [strc,num2str(posc(ino)),'+'];
        Tag2{1,2*(length(posn)+ino-1)+2} = [strc,num2str(posc(ino)),'++'];
    end
end

x = find(K1>0 & K1<2000);
K1 = K1(x);
Tag1 = Tag1(x);
x = find(K2>0 & K2<2000);
K2 = K2(x);
Tag2 = Tag2(x);