function H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special)
%%

% check
out_filename = 'H3_04v3_27_40';
special.outfile = out_filename;
special = check_rt(special,2);
out_file0 = fullfile(special.outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end

% init
His = init_histone(special);

% calculate
[pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);

% output
output_histone(His,pep_rts,pep_intens,special);

% draw layout
isorts = MS1_index(1:size(MS1_index,1),2);
if '1'==special.sfigure(1)
    draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special);
end

% Get PSM
if '1'==special.sfigure(2)
    draw_PSM(His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special);
end

function His = init_histone(special)
%%

His.pep_seq = 'KSAPSTGGVKKPHR';
His.mod_short = {'unmod';
    'K36me1';
    'K27me1';
    'K27me2';
    'K36me2';
    'K27me3';
    'K36me3';
    'K27me2K36me1';
    'K27me1K36me2';
    'K27me1K36me1';
    'K27me3K36me1';
    'K27me1K36me3';
    'K27me2K36me2';
    'K27me3K36me2';
    'K27me2K36me3';
    'K27me3K36me3';
    'K27ac'};
His.mod_type = {'0,pr;1,pr;10,pr;11,pr;';
    '0,pr;1,pr;10,me1;11,pr;';
    '0,pr;1,me1;10,pr;11,pr;';
    '0,pr;1,me2;10,pr;11,pr;';
    '0,pr;1,pr;10,me2;11,pr;';
    '0,pr;1,me3;10,pr;11,pr;';
    '0,pr;1,pr;10,me3;11,pr;';
    '0,pr;1,me2;10,me1;11,pr;';
    '0,pr;1,me1;10,me2;11,pr;';
    '0,pr;1,me1;10,me1;11,pr;';
    '0,pr;1,me3;10,me1;11,pr;';
    '0,pr;1,me1;10,me3;11,pr;';
    '0,pr;1,me2;10,me2;11,pr;';
    '0,pr;1,me3;10,me2;11,pr;';
    '0,pr;1,me2;10,me3;11,pr;';
    '0,pr;1,me3;10,me3;11,pr;';
    '0,pr;1,ac;10,pr;11,pr;'};

His.pep_ch = repmat([2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.rt_ref = [26.08
    27.81
    27.94
    21.40
    22.68
    21.40
    22.66
    22.64
    24.44
    29.15
    22.64
    24.44
    18.29
    18.20
    18.34
    18.20
    24.99];
if 1==special.rt_reset
    His.rt_ref(1:14) = special.rt_ref(1:14);
    His.rt_ref(15:16) = special.rt_ref(14);
    His.rt_ref(17) = special.rt_ref(15);
end
His.display = ones(length(His.mod_type),1);
His.display([15 16]) = 0;

% main ch
main_ch = His.pep_ch(1,2);
if main_ch~=His.pep_ch(1,1)
    [npep,ncharge] = size(His.pep_mz);%#ok
    new_ch = [main_ch,setdiff(His.pep_ch(1,:),main_ch)];
    x = zeros([1,ncharge]);
    for ino=1:ncharge
        x(ino) = find(His.pep_ch(1,:)==new_ch(ino));
    end
    tune = [4 5 6 7 8 9 11 12 13 14 15 16];%1:npep;
    His.pep_mz(tune,:) = His.pep_mz(tune,x);
    His.pep_ch(tune,:) = His.pep_ch(tune,x);
end

function [pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

[npep,ncharge] = size(His.pep_mz);
num_MS1 = size(MS1_index,1);
pep_rts = zeros([npep,ncharge]);
pep_intens = zeros([npep,ncharge]);
mono_isointens = zeros([num_MS1,npep]);

% raw_path = special.raw_path;
% pre_nums = special.pre_nums;
ndebug = special.ndebug;

% unmod
hno = 1;
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,1);
else
    [t1,t2] = check_ref1(MS1_index,special);
    top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,1,t1,t2);
    if 0==isempty(top1_rt)
        His.rt_ref(1) = top1_rt;
    else
        return;
    end
end
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);

% calibrate the rt_ref
if cur_rts(1)>0
    His.rt_ref(1) = cur_rts(1);
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,2);
else
    His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);
end

% K36me1/K27me1
if His.rt_ref(3)-His.rt_ref(2)>0.4
    for hno=2:3
        [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
        if cur_rts(1)>0
            pep_rts(hno,1:ncharge) = cur_rts;
            pep_intens(hno,1:ncharge) = cur_intens;
            mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
        end
    end
else
    hno = 2;
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno);
    if cur_rts(1,1)>0
        pep_rts(hno:hno+1,1:ncharge) = cur_rts(1:2,:);
        pep_intens(hno:hno+1,1:ncharge) = cur_intens(1:2,:);
        mono_isointens(1:num_MS1,hno:hno+1) = cur_mono_isointens(:,1:2);
    end
end

% K27me2
% K36me2
% K27me3
for hno=4:6
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

% K36me3/K27me2K36me1
hno = 7;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno);
if cur_rts(1,1)>0
    pep_rts(hno:hno+1,1:ncharge) = cur_rts(1:2,:);
    pep_intens(hno:hno+1,1:ncharge) = cur_intens(1:2,:);
    mono_isointens(1:num_MS1,hno:hno+1) = cur_mono_isointens(:,1:2);
end

% K27me1K36me2
% K27me1K36me1
% K27me3K36me1
% K27me1K36me3
% K27me2K36me2
for hno=9:13
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

% K27me3K36me2/K27me2K36me3
%
hno = 14;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if cur_rts(1)>0
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end
%}
%{
hno = 14;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno);
if cur_rts(1,1)>0
    pep_rts(hno:hno+1,1:ncharge) = cur_rts(1:2,:);
    pep_intens(hno:hno+1,1:ncharge) = cur_intens(1:2,:);
    mono_isointens(1:num_MS1,hno:hno+1) = cur_mono_isointens(:,1:2);
end
%}

% K27me3K36me3
%{
hno = 16;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if cur_rts(1)>0
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end;
%}

% K27ac
hno = 17;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if cur_rts(1)>0
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end

function His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.5;
nsplit = 1;

ref_rts = get_KSAPATGGVKKPHR_rt(special);
if 1==isempty(ref_rts)
    return;
end
nshift = ref_rts(1)-His.rt_ref(1);

for hno = [2 3 4 5 6 7 8 9 10 11 12 13 14 17]
    t1 = ref_rts(hno)-nshift-delta;
    t2 = ref_rts(hno)-nshift+delta;
    top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);
    
    if 1==isempty(top1_rt)
        His.rt_ref(hno) = 0;
    else
        His.rt_ref(hno) = top1_rt;
    end
end

function [t1,t2] = check_ref1(MS1_index,special)
%%

num_MS1 = size(MS1_index,1);
rt_MS1 = MS1_index(num_MS1,2);

ref_rts = get_KSAPATGGVKKPHR_rt(special);
if 0==isempty(ref_rts)
    t1 = ref_rts(1)-3;
    t2 = ref_rts(1)-0.1;
else
    t1 = 0;
    t2 = rt_MS1;
end

function ref_rts = get_KSAPATGGVKKPHR_rt(special)
%%

ref_rts = [];
out_file0 = fullfile(special.outpath,'H3_04_27_40.xls');
if 0~=exist(out_file0,'file')
    fp = fopen(out_file0,'r');
    str = fgetl(fp);
    while 0==feof(fp) && 0==strcmp(str,'[rt]')
        str = fgetl(fp);
    end
    str = fgetl(fp);%#ok peptide
    no = 0;
    
    while 0==feof(fp)
        str = fgetl(fp);
        p = strfind(str,'	');
        c_rt = str2num( str(p(1)+1:p(2)-1) );%#ok
        no = no + 1;
        ref_rts(no) = c_rt;%#ok
    end
    fclose(fp);
end