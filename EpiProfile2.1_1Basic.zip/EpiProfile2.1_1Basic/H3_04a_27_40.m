function H3_04a_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special)
%%

% check
out_filename = 'H3_04a_27_40';
special.outfile = out_filename;
special = check_rt(special,2);
out_file0 = fullfile(special.outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end

% init
His = init_histone(special);

% calculate
[pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);

% output
output_histone(His,pep_rts,pep_intens,special);

% draw layout
isorts = MS1_index(1:size(MS1_index,1),2);
if '1'==special.sfigure(1)
    draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special);
end

% Get PSM
if '1'==special.sfigure(2)
    draw_PSM(His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special);
end

function His = init_histone(special)
%%

His.pep_seq = 'KSAPATGGVKKPHR';
His.mod_short = {'S28ph';
    'K27me1S28ph';
    'K27me2S28ph';
    'K27me3S28ph'};
His.mod_type = {'0,pr;1,pr;2,ph;10,pr;11,pr;';
    '0,pr;1,me1;2,ph;10,pr;11,pr;';
    '0,pr;1,me2;2,ph;10,pr;11,pr;';
    '0,pr;1,me3;2,ph;10,pr;11,pr;'};

His.pep_ch = repmat([2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.rt_ref = [31.35
    33.20
    27.34
    27.31];
if 1==special.rt_reset
    His.rt_ref = special.rt_ref;
end
His.display = ones(length(His.mod_type),1);

% main ch
main_ch = His.pep_ch(1,2);
if main_ch~=His.pep_ch(1,1)
    [npep,ncharge] = size(His.pep_mz);
    new_ch = [main_ch,setdiff(His.pep_ch(1,:),main_ch)];
    x = zeros([1,ncharge]);
    for ino=1:ncharge
        x(ino) = find(His.pep_ch(1,:)==new_ch(ino));
    end
    tune = 1:npep;
    His.pep_mz(tune,:) = His.pep_mz(tune,x);
    His.pep_ch(tune,:) = His.pep_ch(tune,x);
end

function [pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

[npep,ncharge] = size(His.pep_mz);
num_MS1 = size(MS1_index,1);
pep_rts = zeros([npep,ncharge]);
pep_intens = zeros([npep,ncharge]);
mono_isointens = zeros([num_MS1,npep]);

% raw_path = special.raw_path;
% pre_nums = special.pre_nums;
ndebug = special.ndebug;

if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,1);
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,2);
else
    His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);
end

% S28ph
% K27me1S28ph
% K27me2S28ph
% K27me3S28ph
for hno=1:length(His.mod_type)
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

function His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.3;
nsplit = 1;

ref_rts = get_KSAPATGGVKKPHR_rt(special);
if 1==isempty(ref_rts)
    return;
end

% S28ph
hno = 1;
t1 = ref_rts(1)+delta;
t2 = ref_rts(1)+special.dis_ph(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me1S28ph
hno = 2;
if His.rt_ref(1)>0
    t1 = His.rt_ref(1)+delta;
    t2 = His.rt_ref(1)+special.dis_me1(special.rtlen);
elseif ref_rts(3)>0
    t1 = ref_rts(3)+delta;
    t2 = ref_rts(3)+special.dis_ph(special.rtlen);
else
    t1 = ref_rts(1)+delta;
    t2 = ref_rts(1)+(special.dis_me1(special.rtlen)-special.delta)/2+special.dis_ph(special.rtlen);
end
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me2S28ph
hno = 3;
if 0==ref_rts(4)
    t1 = max([3,ref_rts(1)-special.dis_me2(special.rtlen)]);
else
    t1 = ref_rts(4)+delta;
end
if 0==ref_rts(9)
    t2 = ref_rts(1)-delta;
else
    t2 = ref_rts(9)-delta;
end
[top1_rt3,top1_inten_sum3,rts3,inten_sum3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K27me3S28ph
hno = 4;
if 0==ref_rts(4)
    t1 = max([3,ref_rts(1)-special.dis_me2(special.rtlen)]);
else
    t1 = ref_rts(4)+delta;
end
if 0==ref_rts(9)
    t2 = ref_rts(1)-delta;
else
    t2 = ref_rts(9)-delta;
end
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

[His.rt_ref(3),His.rt_ref(4)] = find_pair(top1_rt3,top1_inten_sum3,rts3,inten_sum3,top1_rt4,top1_inten_sum4,rts4,inten_sum4);

function ref_rts = get_KSAPATGGVKKPHR_rt(special)
%%

ref_rts = [];
out_file0 = fullfile(special.outpath,'H3_04_27_40.xls');
if 0~=exist(out_file0,'file')
    fp = fopen(out_file0,'r');
    str = fgetl(fp);
    while 0==feof(fp) && 0==strcmp(str,'[rt]')
        str = fgetl(fp);
    end
    str = fgetl(fp);%#ok peptide
    no = 0;
    
    while 0==feof(fp)
        str = fgetl(fp);
        p = strfind(str,'	');
        c_rt = str2num( str(p(1)+1:p(2)-1) );%#ok
        no = no + 1;
        ref_rts(no) = c_rt;%#ok
    end
    fclose(fp);
end