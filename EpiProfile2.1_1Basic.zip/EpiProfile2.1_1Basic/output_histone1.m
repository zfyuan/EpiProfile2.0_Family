function output_histone1(special)
%%

cur_outpath = special.outpath;
out_filename = special.outfile;

out_file = fullfile(cur_outpath,'combine',[out_filename,'.mat']);

[path1,name1] = fileparts(cur_outpath);
[path2,name2] = fileparts(path1);
[path3,name3] = fileparts(path2);
out_file1 = fullfile(fullfile(path3,[name3,'_light'],name2,name1),[out_filename,'.mat']);
if 0==exist(out_file1,'file')
    fprintf(1,'%s: not exist.\n',out_file1);
    return;
end
load(out_file1);%#ok
His1 = His;%#ok
auc1 = auc;%#ok

out_file2 = fullfile(cur_outpath,[out_filename,'.mat']);
if 0==exist(out_file2,'file')
    fprintf(1,'%s: not exist.\n',out_file2);
    return;
end
load(out_file2);%#ok
His2 = His;
auc2 = auc;

[npep1,ncharge1] = size(His1.pep_mz);
[npep2,ncharge2] = size(His2.pep_mz);

His0.pep_seq = His1.pep_seq;
for ino=1:npep1
    His0.mod_short{ino,1} = His1.mod_short{ino,1};
    His0.mod_type{ino,1} = His1.mod_type{ino,1};
    His0.pep_mz(ino,1:ncharge1) = His1.pep_mz(ino,1:ncharge1);
    His0.pep_ch(ino,1:ncharge1) = His1.pep_ch(ino,1:ncharge1);
    His0.rt_ref(ino,1) = His1.rt_ref(ino,1);
end
for ino=1:npep2
    His0.mod_short{npep1+ino,1} = His2.mod_short{ino,1};
    His0.mod_type{npep1+ino,1} = His2.mod_type{ino,1};
    His0.pep_mz(npep1+ino,1:ncharge2) = His2.pep_mz(ino,1:ncharge2);
    His0.pep_ch(npep1+ino,1:ncharge2) = His2.pep_ch(ino,1:ncharge2);
    His0.rt_ref(npep1+ino,1) = His2.rt_ref(ino,1);
end

auc0 = auc1;
auc0(npep1+1:npep1+npep2,1:3) = auc2;

His = His0;%#ok
auc = auc0;

total_intens = sum(auc(1:npep1+npep2,2));
for ino=1:npep1+npep2
    auc(ino,3) = auc(ino,2)/(eps+total_intens);
end

save(out_file,'auc','His');