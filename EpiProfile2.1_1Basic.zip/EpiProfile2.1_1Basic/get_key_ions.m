function [K1,Tag1] = get_key_ions(His,pno,Mods,ActiveType,nhmass,nall)
%%

c_seq = His.pep_seq;
if 1==strcmp(c_seq,'unmod')
    c_seq = His.mod_short{pno};
    p = strfind(c_seq,'.');
    if 0==isempty(p)
        c_seq = c_seq(p(end)+1:end);
    end
end
c_mod1 = His.mod_type{pno};

% get_mod_postype
peplen = length(c_seq);
if 1==nall
    t1 = 1;
    t2 = peplen;
else
    modpos1 = get_mod_postype(c_seq,c_mod1,Mods);
    ix = find(modpos1>0);
    if 1==isempty(ix) || modpos1(ix(end))-modpos1(ix(1))<=3
        t1 = 1;
        t2 = peplen;
    else
        t1 = min( modpos1(ix) );
        t2 = max( modpos1(ix) );
    end
end
nlen = 2*(t2-t1)*2;
K1 = zeros([1,nlen]);

Tag1 = repmat({''},[1,nlen]);
if 1==strcmp(ActiveType,'CID')
    strn = 'b';
    strc = 'y';
else
    strn = 'c';
    strc = 'z';
end

posn = t1:t2-1;
posc = (peplen-t2+1):(peplen-t1);

% get_theo_mz
if His.pep_ch(pno,1)>=3
    c_chg = 2;
else
    c_chg = 1;
end
[theo_mz1,theo_tp1] = get_theo_mz(c_seq,c_mod1,c_chg,Mods,ActiveType,nhmass);

n1 = find(theo_tp1<2000);
tpn1 = floor( (theo_tp1(n1)-1000)/10 );
c1 = find(theo_tp1>2000);
tpc1 = floor( (theo_tp1(c1)-2000)/10 );

for ino=1:length(posn)
    loc1 = find(tpn1==posn(ino));
    if 1==length(loc1)
        K1(2*(ino-1)+1) = theo_mz1(n1(loc1));
        Tag1{1,2*(ino-1)+1} = [strn,num2str(posn(ino)),'+'];
    elseif 2==length(loc1)
        K1(2*(ino-1)+1) = theo_mz1(n1(loc1(1)));
        K1(2*(ino-1)+2) = theo_mz1(n1(loc1(2)));
        Tag1{1,2*(ino-1)+1} = [strn,num2str(posn(ino)),'+'];
        Tag1{1,2*(ino-1)+2} = [strn,num2str(posn(ino)),'++'];
    end
end

for ino=1:length(posc)
    loc1 = find(tpc1==posc(ino));
    if 1==length(loc1)
        K1(2*(length(posn)+ino-1)+1) = theo_mz1(c1(loc1));
        Tag1{1,2*(length(posn)+ino-1)+1} = [strc,num2str(posc(ino)),'+'];
    elseif 2==length(loc1)
        K1(2*(length(posn)+ino-1)+1) = theo_mz1(c1(loc1(1)));
        K1(2*(length(posn)+ino-1)+2) = theo_mz1(c1(loc1(2)));
        Tag1{1,2*(length(posn)+ino-1)+1} = [strc,num2str(posc(ino)),'+'];
        Tag1{1,2*(length(posn)+ino-1)+2} = [strc,num2str(posc(ino)),'++'];
    end
end

x = find(K1>0 & K1<2000);
K1 = K1(x);
Tag1 = Tag1(x);