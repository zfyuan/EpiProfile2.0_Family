function [cur_rts,cur_intens,cur_mono_isointens] = get_histone1_C13(MS1_index,MS1_peaks,special,His,hno)
%%

[npep,ncharge] = size(His.pep_mz);%#ok
cur_rts = zeros([1,ncharge]);
cur_intens = zeros([1,ncharge]);
cur_mono_isointens = zeros([size(MS1_index,1),1]);

ptol = special.ptols(special.c_rno);
unitdiff = special.unitdiff;
IPV = special.IPV;
nshift = special.nshift;
nhac = length(strfind(His.mod_type{hno},special.hmod));

delta = 0.2;
p = find( MS1_index(:,2)>=His.rt_ref(hno)-delta );
pp = find( MS1_index(:,2)<=His.rt_ref(hno)+delta );
if 1==isempty(p) || 1==isempty(pp)
    return;
end
rt_i1 = p(1);
rt_i2 = pp(end);

for jno=1:ncharge
    % get MS1 profile
    c_mz = His.pep_mz(hno,jno);
    c_ch = His.pep_ch(hno,jno);
    c_ref_isomzs = 0;
    for xno=1:nhac+1
        c_ref_isomzs(xno) = c_mz-nshift*(nhac+1-xno)*unitdiff/c_ch;%#ok
    end
    [c_isorts,c_ref_isointens] = GetProfiles(MS1_index,MS1_peaks,c_ref_isomzs,c_ch,ptol,IPV,1,rt_i1:rt_i2);%0->1
    c_mono_isointens = c_ref_isointens(:,nhac+1);
    
    % get rt and area
    [nt,nb,top1_idx,inten_sum,nb1,nb2] = GetTopBottom11(c_mono_isointens);%#ok
    if 0==isempty(nt)
        xnb2 = [nb1(top1_idx) nb2(top1_idx)];
        cur_pos = nt(top1_idx);
        cur_rts(jno) = c_isorts(cur_pos);
        [cur_intens(jno),c_mono_isointens] = get_area_C13(c_isorts,c_ref_isointens,xnb2,c_mz,c_ch,IPV,nshift);
    else
        cur_rts(jno) = His.rt_ref(hno);
        cur_intens(jno) = 0;
    end
    if 1==jno
        cur_mono_isointens = c_mono_isointens;
    end
end