function pep_group = calculate_pepgroup(His)
%%

pep_mz = His.pep_mz(:,1);
pep_group = zeros([length(pep_mz),1]);

gno = 0;
for ino=1:length(pep_mz)
    idx = find(abs(pep_mz-pep_mz(ino))<1e-5);
    if 0==pep_group(ino) && length(idx)>1
        gno = gno + 1;
        pep_group(idx) = gno;
    end
end