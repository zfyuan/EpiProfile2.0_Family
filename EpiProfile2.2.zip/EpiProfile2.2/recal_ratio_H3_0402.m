function recal_ratio_H3_0402(cur_outpath)
%%

% H3_04
out_filename = 'H3_04_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s1 = sum(auc(:,2));%#ok

out_filename = 'H3_04a_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s2 = sum(auc(:,2));

s = s1+s2;

out_filename = 'H3_04_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;
save(mat_file,'His','auc');

out_filename = 'H3_04a_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;
save(mat_file,'His','auc');

% H3_04v3
out_filename = 'H3_04v3_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s1 = sum(auc(:,2));

out_filename = 'H3_04v3a_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s2 = sum(auc(:,2));

s = s1+s2;

out_filename = 'H3_04v3_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;
save(mat_file,'His','auc');

out_filename = 'H3_04v3a_27_40';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;%#ok
save(mat_file,'His','auc');