function xt = find_triple_new(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.1;
nsplit = 1;

% xt = zeros([3,3]);
% xt=[6.7 7.1 7.1;6.7 7.1 7.7;0.0 7.1 7.7];
% His.rt_ref(1) = 8.2;

t1 = max([1,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-delta;

% K27me2
hno = 4;
tmp11 = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

width_un_K27me2 = His.rt_ref(1) - tmp11;
% width_K27me2K36me1_K27me3 = 0.4/1.5*width_un_K27me2;
% width_K27me1K36me2_K27me3 = 1.0/1.5*width_un_K27me2;
% width_K27me1K36me2_K27me2K36me1 = 0.6/1.5*width_un_K27me2;
d21 = 0.4/1.5*width_un_K27me2;
d31 = 1.0/1.5*width_un_K27me2;
d32 = 0.6/1.5*width_un_K27me2;
x21 = tmp11;
x22 = tmp11 + d21;
x23 = tmp11 + d31;
xt=[x21 x22 x22;x21 x22 x23;0.0 x22 x23];

% K36me2
hno = 5;
tmp = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(1,2)-d21/2,xt(1,2)+d32/2);
if isempty(tmp)==0
    xt(1,2) = tmp;
end

% K27me3
hno = 6;
tmp = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(2,1)-d21/2,xt(2,1)+d21/2);
if isempty(tmp)==0
    xt(2,1) = tmp;
end

% K36me3
hno = 7;
tmp = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(1,3)-d32/2,t2);
if isempty(tmp)==0
    xt(1,3) = tmp;
end

% K27me2K36me1
hno = 8;
tmp = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(2,2)-d21/2,xt(2,2)+d32/2);
if isempty(tmp)==0
    xt(2,2) = tmp;
end

% K27me1K36me2
hno = 9;
tmp = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(2,3)-d32/2,t2);
if isempty(tmp)==0
    xt(2,3) = tmp;
end

% K27me3K36me1
hno = 11;
tmp = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(3,2)-d21/2,xt(3,2)+d32/2);
if isempty(tmp)==0
    xt(3,2) = tmp;
end

% K27me1K36me3
hno = 12;
tmp = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(3,3)-d32/2,t2);
if isempty(tmp)==0
    xt(3,3) = tmp;
end

x21 = mean([xt(1,1),xt(2,1)]);
x22 = median([xt(1,2),xt(1,3),xt(2,2),xt(3,2)]);
x23 = mean([xt(2,3),xt(3,3)]);
xt=[x21 x22 x22;x21 x22 x23;0.0 x22 x23];