function xt = find_triple_new(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.1;
nsplit = 1;

xt = zeros([3,3]);

t1 = max([1,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-delta;

% K27me2
hno = 4;
xt(1,1) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K36me2
hno = 5;
xt(1,2) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(1,1)+2*delta,t2);

% K27me3
hno = 6;
xt(2,1) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(1,1)-2*delta,xt(1,1)+2*delta);

% K36me3
hno = 7;
xt(1,3) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(1,1)+2*delta,t2);

% K27me2K36me1
hno = 8;
xt(2,2) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(1,1)+2*delta,t2);

% K27me1K36me2
hno = 9;
xt(2,3) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(2,2)+2*delta,t2);

% K27me3K36me1
hno = 11;
xt(3,2) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(1,1)+2*delta,t2);

% K27me1K36me3
hno = 12;
xt(3,3) = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,xt(2,2)+2*delta,t2);