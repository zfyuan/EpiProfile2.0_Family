function [top1_rt,top1_inten_sum,rts,inten_sum] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2)
%%

num_MS1 = size(MS1_index,1);
if t1>MS1_index(num_MS1,2) || t2<0 || t2<=t1
    top1_rt = [];
    top1_inten_sum = [];
    rts = [];
    inten_sum = [];
    return;
end

ptol = special.ptols(special.c_rno);
nDAmode = special.nDAmodes(special.c_rno);
unitdiff = special.unitdiff;
IPV = special.IPV;

% get MS1
p = find( MS1_index(:,2)>=t1 );
pp = find( MS1_index(:,2)<=t2 );
if 1==isempty(p) || 1==isempty(pp)
    top1_rt = [];
    top1_inten_sum = [];
    rts = [];
    inten_sum = [];
    return;
end
rt_i1 = p(1);
rt_i2 = pp(end);

c_mz = His.pep_mz(hno,1);
c_ch = His.pep_ch(hno,1);

c_ref_isomzs = [c_mz-unitdiff/c_ch c_mz c_mz+unitdiff/c_ch c_mz+2*unitdiff/c_ch];
if ptol<1 && c_ch>=3
    nC13 = 1;
else
    nC13 = 0;
end
[c_isorts,c_ref_isointens] = GetProfiles(MS1_index,MS1_peaks,c_ref_isomzs,c_ch,ptol,IPV,nC13,rt_i1:rt_i2);
c_mono_isointens = c_ref_isointens(:,2);

if length(find(c_mono_isointens>0))<1
    top1_rt = [];
    top1_inten_sum = [];
    rts = [];
    inten_sum = [];
    return;
end

if 1==nsplit
    [nt,nb,top1_idx,inten_sum,nb1,nb2] = GetTopBottom(c_mono_isointens);%#ok
else
    [nt,nb,top1_idx,inten_sum,nb1,nb2] = GetTopBottom11(c_mono_isointens);%#ok
end
rts = c_isorts(nt);

% get MS2
w = c_mono_isointens;
w(find(w<0.01*max(w))) = 0;%#ok
p_intens_sums = zeros([length(nt),1]);
f_intens_sums = zeros([length(nt),1]);
fragnum = zeros([length(nt),1]);
for ino=1:length(nt)
    i1 = nb1(ino);
    i2 = nb2(ino);
    if 1==nDAmode% extend MS1 if MS2 on the boundary of MS1 XIC in DDA
        [i1,i2] = extend_boundary(i1,i2,num_MS1);
    end
    rt1 = c_isorts(i1);
    rt2 = c_isorts(i2);
    
    % p_intens_sums
    p_intens = c_mono_isointens(i1:i2);
    p_intens_sums(ino) = sum(p_intens);
    
    % f_intens_sums
    % [ms2pos,ms2rts,ms2intens,K1,Tag1] = MatchMS2(MS2_index,MS2_peaks,special,His,hno,rt1,rt2,0);%#ok
    [ms2pos,ms2rts,ms2intens,K1,Tag1] = MatchMS2(MS2_index,MS2_peaks,special,His,hno,rt1,rt2,1);%#ok
    if 1==isempty(ms2pos)
        continue;
    end
    
    % set 0.8*p_intens as f_intens' up limit ++
    p_rts = c_isorts(i1:i2);
    p2_rts = ms2rts(ms2pos);
    p2_intens = zeros(length(ms2pos),1);
    for jno=1:length(ms2pos)
        idx=find(p_rts<=p2_rts(jno));
        p2_intens(jno) = 0.8*p_intens(idx(end));
    end

    for kno=1:length(K1)
        f_intens = min([ms2intens(ms2pos,kno),p2_intens],[],2); % ++
        f_intens_sums(ino) = f_intens_sums(ino)+sum(f_intens);
    end
    
    % fragnum
    cx = find(ms2rts>=rt1 & ms2rts<=rt2);
    cfrag = sum(ms2intens(cx,:),1);%#ok
    fragnum(ino) = length(find(cfrag>0));
end

%{
%output
fprintf('\n');
fprintf('pep: %s,\ttheo_fragnum: %d,\t',His.mod_short{hno},length(K1));
fprintf('fragnum: ');
for xno=1:length(fragnum)
    fprintf('%d\t',fragnum(xno));
end
fprintf('\n');

ratio1 = fragnum./length(K1);
[b,ix0]=sort(ratio1,'descend');
[b,ix1]=sort(ix0);
fprintf('ratio1: ');
for xno=1:length(ratio1)
    fprintf('%.3f (%d)\t',ratio1(xno),ix1(xno));
end
fprintf('\n');

[b,ix0]=sort(f_intens_sums,'descend');
[b,ix1]=sort(ix0);
fprintf('f_intens_sums: ');
for xno=1:length(f_intens_sums)
    fprintf('%.2e (%d)\t',f_intens_sums(xno),ix1(xno));
end
fprintf('\n');

[b,ix0]=sort(p_intens_sums,'descend');
[b,ix1]=sort(ix0);
fprintf('p_intens_sums: ');
for xno=1:length(p_intens_sums)
    fprintf('%.2e (%d)\t',p_intens_sums(xno),ix1(xno));
end
fprintf('\n');

fprintf('rt: ');
for xno=1:length(nt)
    fprintf('%.2f\t',c_isorts(nt(xno)));
end
fprintf('\n');

plot(c_isorts,c_ref_isointens(:,2));
for xno=1:length(nt)
    text(c_isorts(nt(xno)),c_ref_isointens(nt(xno),2),num2str(c_isorts(nt(xno)),'%.2f'));
end
%output
%}

f_inten_cutoff = 0;
% f_inten_cutoff = 1e3;
[tmp,new_top1_idx] = max(f_intens_sums);
if tmp>f_inten_cutoff
    top1_rt = c_isorts(nt(new_top1_idx));
    top1_inten_sum = inten_sum(new_top1_idx);
else
    [tmp,new_top1_idx] = max(p_intens_sums);
    if tmp>f_inten_cutoff
        top1_rt = c_isorts(nt(new_top1_idx));
        top1_inten_sum = inten_sum(new_top1_idx);
    else
        top1_rt = 0;
    end
end

%{
%output
fprintf('top1_rt: %.2f\n',top1_rt);
close();
%output
%}

if top1_rt<1
    top1_rt = [];
    top1_inten_sum = [];
    rts = [];
    inten_sum = [];
    return;
end

function [i1,i2] = extend_boundary(i1,i2,num_MS1)
%%

if i1-2>=1
    i1 = i1-2;
elseif i1-1>=1
    i1 = i1-1;
end
if i2+2<=num_MS1
    i2 = i2+2;
elseif i2+1<=num_MS1
    i2 = i2+1;
end