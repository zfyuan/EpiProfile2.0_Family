function special = check_rt(special,n1st)
%%

pre_nums = special.pre_nums;
if 1==n1st
    nfiles = length(special.raw_names);
    special.pep_code = [];
    special.rt_ref1 = [];
    special.rt_ref2 = [];
    
    rt_file = fullfile(special.raw_path,'histone_layouts','histone_rts.xls');
    if 0~=exist(rt_file,'file')
       sets = read_stringfile(rt_file);
       pnum = 0;
       for ino=1:length(sets)
           c_str = sets{ino};
           p1 = strfind(c_str,' ');% Space
           p2 = strfind(c_str,'	');% Tab
           if 0==isempty(p1) && 0==isempty(p2) && p1(1)<p2(1)
               pnum = pnum + 1;
               out_filename = c_str(1:p1(1)-1);
               special.pep_code(pnum,1) = sum((out_filename-'0'+49).*log(pre_nums(1:length(out_filename))));
               
               cur_rts = sscanf(c_str(p2(1)+1:end),'%f');
               if length(cur_rts)>=2*nfiles
                   special.rt_ref1(pnum,1:nfiles) = cur_rts(1:nfiles);
                   special.rt_ref2(pnum,1:nfiles) = cur_rts(nfiles+1:2*nfiles);
               else
                   special.rt_ref1(pnum,1:nfiles) = zeros(1,nfiles);
                   special.rt_ref2(pnum,1:nfiles) = zeros(1,nfiles);
               end
           end
       end
    end
else
    special.rt_reset = 0;
    special.rt_ref = [];
    out_filename = special.outfile;
    c_pep_code = sum((out_filename-'0'+49).*log(pre_nums(1:length(out_filename))));
    if 1==special.ndebug && 0==isempty(special.pep_code)
        IX = find(special.pep_code==c_pep_code);
        if 0==isempty(IX)
            rt_delta = special.rt_ref1(IX,special.c_rno)-special.rt_ref2(IX,special.c_rno);
            if 0==isempty( find(any(rt_delta~=0)==1) )%#ok
                special.rt_reset = 1;
                special.rt_ref = special.rt_ref2(IX,special.c_rno);
                
                delete_myfiles(fileparts(special.outpath),out_filename);
                delete_myfiles(special.outpath,out_filename);
                delete_myfiles(fullfile(special.outpath,'psm'),out_filename);
            end
        end
    end
end

function [sets,str_head] = read_stringfile(file)
%%

sets = {};
i = 0;

fp = fopen(file,'r');

str_head = fgetl(fp);% head
while 1
    str = fgetl(fp);
    if 1==isempty(str)
        continue;
    end
    i = i+1;
    sets{i} = str;%#ok
    
    if 1==feof(fp)
        break;
    end
end

fclose(fp);

function delete_myfiles(cur_path,cur_prefix)
%%

if 0~=exist(cur_path,'dir')
    dir1 = dir(fullfile(cur_path,['*',cur_prefix,'*']));
    if 0==isempty(dir1)
        for ino=1:length(dir1)
            delete(fullfile( cur_path,dir1(ino).name ));
        end
    end
end