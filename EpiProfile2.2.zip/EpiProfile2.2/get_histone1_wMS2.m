function [cur_rts,cur_intens,cur_mono_isointens] = get_histone1_wMS2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno)
%%

[npep,ncharge] = size(His.pep_mz);%#ok
cur_rts = zeros([1,ncharge]);
cur_intens = zeros([1,ncharge]);
cur_mono_isointens = zeros([size(MS1_index,1),1]);

ptol = special.ptols(special.c_rno);
unitdiff = special.unitdiff;
IPV = special.IPV;

delta = 0.2;
p = find( MS1_index(:,2)>=His.rt_ref(hno)-delta );
pp = find( MS1_index(:,2)<=His.rt_ref(hno)+delta );
if 1==isempty(p) || 1==isempty(pp)
    return;
end
rt_i1 = p(1);
rt_i2 = pp(end);

for jno=1:ncharge
    % get MS1 profile
    c_mz = His.pep_mz(hno,jno);
    c_ch = His.pep_ch(hno,jno);
    c_ref_isomzs = [c_mz-unitdiff/c_ch c_mz c_mz+unitdiff/c_ch c_mz+2*unitdiff/c_ch];
    if ptol<1 && c_ch>=3
        nC13 = 1;
    else
        nC13 = 0;
    end
    [c_isorts,c_ref_isointens] = GetProfiles(MS1_index,MS1_peaks,c_ref_isomzs,c_ch,ptol,IPV,nC13,rt_i1:rt_i2);
    c_mono_isointens = c_ref_isointens(:,2);
    if 1==jno
        cur_mono_isointens = c_mono_isointens;
    end
    
    % get rt and area
    [nt,nb,top1_idx,inten_sum,nb1,nb2] = GetTopBottom(c_mono_isointens);%#ok
    if 0==isempty(nt)
        top1_idx = get_top1_idx_by_MS2(MS1_index,MS2_index,MS2_peaks,special,His,hno,c_isorts,c_mono_isointens,nt,nb1,nb2);
        xnb2 = [nb1(top1_idx) nb2(top1_idx)];
        cur_pos = nt(top1_idx);
        cur_rts(jno) = c_isorts(cur_pos);
        cur_intens(jno) = get_area(c_isorts,c_mono_isointens,xnb2,c_mz,c_ch,IPV);
    else
        cur_rts(jno) = His.rt_ref(hno);
        cur_intens(jno) = 0;
    end
end

function top1_idx = get_top1_idx_by_MS2(MS1_index,MS2_index,MS2_peaks,special,His,hno,c_isorts,c_mono_isointens,nt,nb1,nb2)
%%

num_MS1 = size(MS1_index,1);
nDAmode = special.nDAmodes(special.c_rno);

% get MS2
w = c_mono_isointens;
w(find(w<0.01*max(w))) = 0;%#ok
p_intens_sums = zeros([length(nt),1]);
f_intens_sums = zeros([length(nt),1]);
fragnum = zeros([length(nt),1]);
for ino=1:length(nt)
    i1 = nb1(ino);
    i2 = nb2(ino);
    if 1==nDAmode% extend MS1 if MS2 on the boundary of MS1 XIC in DDA
        [i1,i2] = extend_boundary(i1,i2,num_MS1);
    end
    rt1 = c_isorts(i1);
    rt2 = c_isorts(i2);
    
    % p_intens_sums
    p_intens = c_mono_isointens(i1:i2);
    p_intens_sums(ino) = sum(p_intens);
    
    % f_intens_sums
    % [ms2pos,ms2rts,ms2intens,K1,Tag1] = MatchMS2(MS2_index,MS2_peaks,special,His,hno,rt1,rt2,0);%#ok
    [ms2pos,ms2rts,ms2intens,K1,Tag1] = MatchMS2(MS2_index,MS2_peaks,special,His,hno,rt1,rt2,1);%#ok
    if 1==isempty(ms2pos)
        continue;
    end
    
    % set 0.8*p_intens as f_intens' up limit ++
    p_rts = c_isorts(i1:i2);
    p2_rts = ms2rts(ms2pos);
    p2_intens = zeros(length(ms2pos),1);
    for jno=1:length(ms2pos)
        idx=find(p_rts<=p2_rts(jno));
        p2_intens(jno) = 0.8*p_intens(idx(end));
    end

    for kno=1:length(K1)
        f_intens = min([ms2intens(ms2pos,kno),p2_intens],[],2); % ++
        f_intens_sums(ino) = f_intens_sums(ino)+sum(f_intens);
    end
    
    % fragnum
    cx = find(ms2rts>=rt1 & ms2rts<=rt2);
    cfrag = sum(ms2intens(cx,:),1);%#ok
    fragnum(ino) = length(find(cfrag>0));
end

f_inten_cutoff = 0;
if max(f_intens_sums)>f_inten_cutoff
    [tmp,top1_idx] = max(f_intens_sums);%#ok
else
    [tmp,top1_idx] = max(p_intens_sums);%#ok
end

function [i1,i2] = extend_boundary(i1,i2,num_MS1)
%%

if i1-2>=1
    i1 = i1-2;
elseif i1-1>=1
    i1 = i1-1;
end
if i2+2<=num_MS1
    i2 = i2+2;
elseif i2+1<=num_MS1
    i2 = i2+1;
end