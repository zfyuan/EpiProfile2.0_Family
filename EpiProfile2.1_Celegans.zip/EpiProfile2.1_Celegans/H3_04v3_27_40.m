function H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special)
%%

% check
out_filename = 'H3_04v3_27_40';
special.outfile = out_filename;
special = check_rt(special,2);
out_file0 = fullfile(special.outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end

% init
His = init_histone(special);

% calculate
[pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);

% output
output_histone(His,pep_rts,pep_intens,special);

% draw layout
isorts = MS1_index(1:size(MS1_index,1),2);
if '1'==special.sfigure(1)
    draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special);
end

% Get PSM
if '1'==special.sfigure(2)
    draw_PSM(His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special);
end

function His = init_histone(special)
%%

His.pep_seq = 'KSAPTTGGVKKPHR';
His.mod_short = {'unmod';
    'K27me1';
    'K27me2';
    'K27me3';
    'K27ac';
    'K36me1';
    'K27me1K36me1';
    'K27me2K36me1';
    'K27me3K36me1';
    'K27acK36me1';
    'K36me2';
    'K27me1K36me2';
    'K27me2K36me2';
    'K27me3K36me2';
    'K27acK36me2';
    'K36me3';
    'K27me1K36me3';
    'K27me2K36me3';
    'K27me3K36me3';
    'K27acK36me3';
    'K36ac';
    'K27me1K36ac';
    'K27me2K36ac';
    'K27me3K36ac';
    'K27acK36ac'};
His.mod_type = {'0,pr;1,pr;10,pr;11,pr;';
    '0,pr;1,me1;10,pr;11,pr;';
    '0,pr;1,me2;10,pr;11,pr;';
    '0,pr;1,me3;10,pr;11,pr;';
    '0,pr;1,ac;10,pr;11,pr;';
    '0,pr;1,pr;10,me1;11,pr;';
    '0,pr;1,me1;10,me1;11,pr;';
    '0,pr;1,me2;10,me1;11,pr;';
    '0,pr;1,me3;10,me1;11,pr;';
    '0,pr;1,ac;10,me1;11,pr;';
    '0,pr;1,pr;10,me2;11,pr;';
    '0,pr;1,me1;10,me2;11,pr;';
    '0,pr;1,me2;10,me2;11,pr;';
    '0,pr;1,me3;10,me2;11,pr;';
    '0,pr;1,ac;10,me2;11,pr;';
    '0,pr;1,pr;10,me3;11,pr;';
    '0,pr;1,me1;10,me3;11,pr;';
    '0,pr;1,me2;10,me3;11,pr;';
    '0,pr;1,me3;10,me3;11,pr;';
    '0,pr;1,ac;10,me3;11,pr;';
    '0,pr;1,pr;10,ac;11,pr;';
    '0,pr;1,me1;10,ac;11,pr;';
    '0,pr;1,me2;10,ac;11,pr;';
    '0,pr;1,me3;10,ac;11,pr;';
    '0,pr;1,ac;10,ac;11,pr;'};

His.pep_ch = repmat([2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.rt_ref = [26.08
    27.94
    21.40
    21.40
    24.99
    26.08
    27.94
    21.40
    21.40
    24.99
    26.08
    27.94
    21.40
    21.40
    24.99
    26.08
    27.94
    21.40
    21.40
    24.99
    26.08
    27.94
    21.40
    21.40
    24.99];
if 1==special.rt_reset
    His.rt_ref = special.rt_ref;
end
His.display = ones(length(His.mod_type),1);

% main ch
main_ch = His.pep_ch(1,2);
if main_ch~=His.pep_ch(1,1)
    [npep,ncharge] = size(His.pep_mz);
    new_ch = [main_ch,setdiff(His.pep_ch(1,:),main_ch)];
    x = zeros([1,ncharge]);
    for ino=1:ncharge
        x(ino) = find(His.pep_ch(1,:)==new_ch(ino));
    end
    tune = 1:npep;
    His.pep_mz(tune,:) = His.pep_mz(tune,x);
    His.pep_ch(tune,:) = His.pep_ch(tune,x);
end

function [pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

[npep,ncharge] = size(His.pep_mz);
num_MS1 = size(MS1_index,1);
pep_rts = zeros([npep,ncharge]);
pep_intens = zeros([npep,ncharge]);
mono_isointens = zeros([num_MS1,npep]);

raw_path = special.raw_path;
pre_nums = special.pre_nums;
ndebug = special.ndebug;

% unmod
hno = 1;
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,1);
else
    [t1,t2] = check_ref(raw_path,[His.pep_seq,His.mod_type{1}],pre_nums,ndebug,MS1_index(num_MS1,2));
    top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,1,t1,t2);
    if 0==isempty(top1_rt)
        His.rt_ref(1) = top1_rt;
    else
        return;
    end
end
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);

% calibrate the rt_ref
if cur_rts(1)>0
    His.rt_ref(1) = cur_rts(1);
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,2);
else
    His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);
end

% K27me1
for hno=2:25
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

function His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.1;
nsplit = 1;

%------------------------------------------------------------------------------------------
% K27me1
hno = 2;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(1)+special.dis_me1(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me2
hno = 3;
t1 = max([6,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-3;
[top1_rt3,top1_inten_sum3,rts3,inten_sum3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K27me3
hno = 4;
t1 = max([6,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-3;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

[His.rt_ref(3),His.rt_ref(4)] = find_pair(top1_rt3,top1_inten_sum3,rts3,inten_sum3,top1_rt4,top1_inten_sum4,rts4,inten_sum4);

% K27ac
hno = 5;
t1 = max([(His.rt_ref(1)+His.rt_ref(3))/2,His.rt_ref(1)-special.dis_ac(special.rtlen)]);
t2 = His.rt_ref(1)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

%------------------------------------------------------------------------------------------
% K36me1
hno = 6;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(2)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = His.rt_ref(2);
else
    His.rt_ref(hno) = top1_rt;
end

% K27me1
hno = 7;
t1 = His.rt_ref(6)+delta;
t2 = His.rt_ref(6)+special.dis_me1(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me2
hno = 8;
t1 = max([6,His.rt_ref(6)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(6)-3;
[top1_rt3,top1_inten_sum3,rts3,inten_sum3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K27me3
hno = 9;
t1 = max([6,His.rt_ref(6)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(6)-3;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

[His.rt_ref(8),His.rt_ref(9)] = find_pair(top1_rt3,top1_inten_sum3,rts3,inten_sum3,top1_rt4,top1_inten_sum4,rts4,inten_sum4);

% K27ac
hno = 10;
t1 = max([(His.rt_ref(6)+His.rt_ref(8))/2,His.rt_ref(6)-special.dis_ac(special.rtlen)]);
t2 = His.rt_ref(6)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

%------------------------------------------------------------------------------------------
% K36me2
hno = 11;
t1 = His.rt_ref(3)+delta;
t2 = His.rt_ref(1)-3;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = His.rt_ref(3);
else
    His.rt_ref(hno) = top1_rt;
end

% K27me1
hno = 12;
t1 = His.rt_ref(11)+delta;
t2 = His.rt_ref(11)+special.dis_me1(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me2
hno = 13;
t1 = max([6,His.rt_ref(11)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(11)-3;
[top1_rt3,top1_inten_sum3,rts3,inten_sum3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K27me3
hno = 14;
t1 = max([6,His.rt_ref(11)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(11)-3;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

[His.rt_ref(13),His.rt_ref(14)] = find_pair(top1_rt3,top1_inten_sum3,rts3,inten_sum3,top1_rt4,top1_inten_sum4,rts4,inten_sum4);

% K27ac
hno = 15;
t1 = max([(His.rt_ref(11)+His.rt_ref(13))/2,His.rt_ref(11)-special.dis_ac(special.rtlen)]);
t2 = His.rt_ref(11)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

%------------------------------------------------------------------------------------------
% K36me3
hno = 16;
t1 = His.rt_ref(3)+delta;
t2 = His.rt_ref(1)-3;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = His.rt_ref(3);
else
    His.rt_ref(hno) = top1_rt;
end

% K27me1
hno = 17;
t1 = His.rt_ref(16)+delta;
t2 = His.rt_ref(16)+special.dis_me1(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me2
hno = 18;
t1 = max([6,His.rt_ref(16)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(16)-3;
[top1_rt3,top1_inten_sum3,rts3,inten_sum3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K27me3
hno = 19;
t1 = max([6,His.rt_ref(16)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(16)-3;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

[His.rt_ref(18),His.rt_ref(19)] = find_pair(top1_rt3,top1_inten_sum3,rts3,inten_sum3,top1_rt4,top1_inten_sum4,rts4,inten_sum4);

% K27ac
hno = 20;
t1 = max([(His.rt_ref(16)+His.rt_ref(18))/2,His.rt_ref(16)-special.dis_ac(special.rtlen)]);
t2 = His.rt_ref(16)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

%------------------------------------------------------------------------------------------
% K36ac
hno = 21;
t1 = His.rt_ref(5)-3;
t2 = His.rt_ref(1)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = His.rt_ref(5);
else
    His.rt_ref(hno) = top1_rt;
end

% K27me1
hno = 22;
t1 = His.rt_ref(21)+delta;
t2 = His.rt_ref(21)+special.dis_me1(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me2
hno = 23;
t1 = max([6,His.rt_ref(21)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(21)-3;
[top1_rt3,top1_inten_sum3,rts3,inten_sum3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K27me3
hno = 24;
t1 = max([6,His.rt_ref(21)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(21)-3;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

[His.rt_ref(23),His.rt_ref(24)] = find_pair(top1_rt3,top1_inten_sum3,rts3,inten_sum3,top1_rt4,top1_inten_sum4,rts4,inten_sum4);

% K27ac
hno = 25;
t1 = max([(His.rt_ref(21)+His.rt_ref(23))/2,His.rt_ref(21)-special.dis_ac(special.rtlen)]);
t2 = His.rt_ref(21)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end