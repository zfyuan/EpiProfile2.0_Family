function [cur_rts,cur_intens,cur_mono_isointens] = get_histone6(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno)
%%

npart = 6;
[npep,ncharge] = size(His.pep_mz);%#ok
cur_rts = zeros([npart,ncharge]);
cur_intens = zeros([npart,ncharge]);
num_MS1 = size(MS1_index,1);
cur_mono_isointens = zeros([num_MS1,npart]);

[h_rts,h_intens,h_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if 0==h_intens(1)
    return;
end

[s_rts,ratio,cur_mono_isointens] = get_ratio_6iso(MS1_index,MS2_index,MS2_peaks,special,His,hno,h_rts,h_mono_isointens);
cur_rts(1,1:ncharge) = repmat(s_rts(1),[1,ncharge]);
cur_rts(2,1:ncharge) = repmat(s_rts(2),[1,ncharge]);
cur_rts(3,1:ncharge) = repmat(s_rts(3),[1,ncharge]);
cur_rts(4,1:ncharge) = repmat(s_rts(4),[1,ncharge]);
cur_rts(5,1:ncharge) = repmat(s_rts(5),[1,ncharge]);
cur_rts(6,1:ncharge) = repmat(s_rts(6),[1,ncharge]);
cur_intens(1,1:ncharge) = h_intens*ratio(1);
cur_intens(2,1:ncharge) = h_intens*ratio(2);
cur_intens(3,1:ncharge) = h_intens*ratio(3);
cur_intens(4,1:ncharge) = h_intens*ratio(4);
cur_intens(5,1:ncharge) = h_intens*ratio(5);
cur_intens(6,1:ncharge) = h_intens*ratio(6);

function [s_rts,ratio,cur_mono_isointens] = get_ratio_6iso(MS1_index,MS2_index,MS2_peaks,special,His,hno,h_rts,h_mono_isointens)
%%

npart = 6;
num_MS1 = size(MS1_index,1);
nDAmode = special.nDAmodes(special.c_rno);
c_isorts = MS1_index(1:num_MS1,2);
c_mono_isointens = h_mono_isointens;

delta = 0.5;
rt1 = His.rt_ref(hno)-delta;
rt2 = His.rt_ref(hno)+delta;
[ms2pos,ms2rts,ms2intens1,ms2intens2] = MatchMS2_6(MS2_index,MS2_peaks,special,His,hno,rt1,rt2);%#ok
if 1==isempty(ms2pos)
    s_rts = repmat(h_rts(1),[1,npart]);
    ratio = repmat(1/npart,[1,npart]);
    cur_mono_isointens = [c_mono_isointens c_mono_isointens c_mono_isointens c_mono_isointens c_mono_isointens c_mono_isointens].*ratio;
    return;
end

% IX on MS1
if 1==nDAmode
    [nt,nb,top1_idx,inten_sum,nb1,nb2] = GetTopBottom11(c_mono_isointens);%#ok
    IX = nb1(1):nb2(end);
    if length(ms2pos)>=length(IX)/2
        IX = zeros([length(ms2pos),1]);
        for i=1:length(ms2pos)
            pp = find(MS1_index(:,1)<=MS2_index(ms2pos(i),1));
            IX(i) = pp(end);
        end
    end
    IX = unique(IX);
    tIX = IX(1):IX(end);
    IX = tIX;
else
    IX = zeros([length(ms2pos),1]);
    for i=1:length(ms2pos)
        pp = find(MS1_index(:,1)<=MS2_index(ms2pos(i),1));
        IX(i) = pp(end);
    end
end

% ratios for profile
nlen = length(IX);
if 1==nDAmode && length(ms2pos)<=ceil(nlen/2)
    area1 = sum(sum(ms2intens1(:,:,1),1));
    area2 = sum(sum(ms2intens2(:,:,1),1));
    r1 = area1/(eps+area1+area2);
    area1 = sum(sum(ms2intens1(:,:,2),1));
    area2 = sum(sum(ms2intens2(:,:,2),1));
    r2 = area1/(eps+area1+area2);
    area1 = sum(sum(ms2intens1(:,:,3),1));
    area2 = sum(sum(ms2intens2(:,:,3),1));
    r3 = area1/(eps+area1+area2);
    area1 = sum(sum(ms2intens1(:,:,4),1));
    area2 = sum(sum(ms2intens2(:,:,4),1));
    r4 = area1/(eps+area1+area2);
    area1 = sum(sum(ms2intens1(:,:,5),1));
    area2 = sum(sum(ms2intens2(:,:,5),1));
    r5 = area1/(eps+area1+area2);
    ratio = resove_linear(r1,r2,r3,r4,1.1*r5);
    s_rts = repmat(h_rts(1),[1,npart]);
    cur_mono_isointens = [c_mono_isointens c_mono_isointens c_mono_isointens c_mono_isointens c_mono_isointens c_mono_isointens].*ratio;
    
    n_rt = c_isorts(IX);
    n_inten1 = c_mono_isointens(IX);
    n_inten2 = n_inten1.*ratio(1);
    n_inten3 = n_inten1.*ratio(2);
    n_inten4 = n_inten1.*ratio(3);
    n_inten5 = n_inten1.*ratio(4);
    n_inten6 = n_inten1.*ratio(5);
    n_inten7 = n_inten1.*ratio(6);
else
    ms1scans = MS2_index(ms2pos,1);
    ratio1 = zeros([nlen,npart]);
    for i=1:nlen
        c_scan = MS1_index(IX(i),1);
        [tf,loc] = ismember(c_scan,ms1scans);
        if 1==tf
            for j=1:npart-1
                intens1 = ms2intens1(ms2pos(loc),:,j);
                intens2 = ms2intens2(ms2pos(loc),:,j);
                ratio1(i,j) = sum(intens1)/(eps+sum(intens1)+sum(intens2));
            end
            ratio1(i,:) = resove_linear(ratio1(i,1),ratio1(i,2),ratio1(i,3),ratio1(i,4),1.1*ratio1(i,5));
        end
    end
    ratio1(:,1) = smooth(ratio1(:,1),3);
    ratio1(:,2) = smooth(ratio1(:,2),3);
    ratio1(:,3) = smooth(ratio1(:,3),3);
    ratio1(:,4) = smooth(ratio1(:,4),3);
    ratio1(:,5) = smooth(ratio1(:,5),3);
    ratio1(:,6) = smooth(ratio1(:,6),3);
    sumrow = sum(ratio1,2);
    ratio1(:,1) = ratio1(:,1)./(eps+sumrow);
    ratio1(:,2) = ratio1(:,2)./(eps+sumrow);
    ratio1(:,3) = ratio1(:,3)./(eps+sumrow);
    ratio1(:,4) = ratio1(:,4)./(eps+sumrow);
    ratio1(:,5) = ratio1(:,5)./(eps+sumrow);
    ratio1(:,6) = ratio1(:,6)./(eps+sumrow);
    
    n_rt = c_isorts(IX);
    n_inten1 = c_mono_isointens(IX);
    n_inten2 = n_inten1.*ratio1(:,1);
    n_inten3 = n_inten1.*ratio1(:,2);
    n_inten4 = n_inten1.*ratio1(:,3);
    n_inten5 = n_inten1.*ratio1(:,4);
    n_inten6 = n_inten1.*ratio1(:,5);
    n_inten7 = n_inten1.*ratio1(:,6);
    
    [tmp,x1] = max(n_inten2);%#ok
    [tmp,x2] = max(n_inten3);%#ok
    [tmp,x3] = max(n_inten4);%#ok
    [tmp,x4] = max(n_inten5);%#ok
    [tmp,x5] = max(n_inten6);%#ok
    [tmp,x6] = max(n_inten7);%#ok
    s_rts(1:npart) = [n_rt(x1) n_rt(x2) n_rt(x3) n_rt(x4) n_rt(x5) n_rt(x6)];
    
    xx = n_rt(1):0.005:n_rt(end);
    yy = spline(n_rt,n_inten2,xx);
    area1 = sum(abs(yy));
    
    xx = n_rt(1):0.005:n_rt(end);
    yy = spline(n_rt,n_inten3,xx);
    area2 = sum(abs(yy));
    
    xx = n_rt(1):0.005:n_rt(end);
    yy = spline(n_rt,n_inten4,xx);
    area3 = sum(abs(yy));
    
    xx = n_rt(1):0.005:n_rt(end);
    yy = spline(n_rt,n_inten5,xx);
    area4 = sum(abs(yy));
    
    xx = n_rt(1):0.005:n_rt(end);
    yy = spline(n_rt,n_inten6,xx);
    area5 = sum(abs(yy));
    
    xx = n_rt(1):0.005:n_rt(end);
    yy = spline(n_rt,n_inten7,xx);
    area6 = sum(abs(yy));
    sumarea = eps+area1+area2+area3+area4+area5+area6;
    ratio(1:npart) = [area1/sumarea area2/sumarea area3/sumarea area4/sumarea area5/sumarea area6/sumarea];
    
    if 1==nDAmode
        cur_mono_isointens(:,1) = [zeros([IX(1)-1,1]);n_inten2;zeros([num_MS1-IX(end),1])];
        cur_mono_isointens(:,2) = [zeros([IX(1)-1,1]);n_inten3;zeros([num_MS1-IX(end),1])];
        cur_mono_isointens(:,3) = [zeros([IX(1)-1,1]);n_inten4;zeros([num_MS1-IX(end),1])];
        cur_mono_isointens(:,4) = [zeros([IX(1)-1,1]);n_inten5;zeros([num_MS1-IX(end),1])];
        cur_mono_isointens(:,5) = [zeros([IX(1)-1,1]);n_inten6;zeros([num_MS1-IX(end),1])];
        cur_mono_isointens(:,6) = [zeros([IX(1)-1,1]);n_inten7;zeros([num_MS1-IX(end),1])];
    else
        xx = c_isorts(IX(1):IX(end));
        yy = spline(n_rt,n_inten2,xx);
        cur_mono_isointens(:,1) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
        yy = spline(n_rt,n_inten3,xx);
        cur_mono_isointens(:,2) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
        yy = spline(n_rt,n_inten4,xx);
        cur_mono_isointens(:,3) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
        yy = spline(n_rt,n_inten5,xx);
        cur_mono_isointens(:,4) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
        yy = spline(n_rt,n_inten6,xx);
        cur_mono_isointens(:,5) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
        yy = spline(n_rt,n_inten7,xx);
        cur_mono_isointens(:,6) = [zeros([IX(1)-1,1]);yy;zeros([num_MS1-IX(end),1])];
    end
end

if '1'==special.sfigure(2)
    if 1==special.nformat
        sformat = '-dpdf';
    elseif 2==special.nformat
        sformat = '-dpng';
    else
        sformat = '-dtiff';
    end
    
    set(gcf,'visible','off');
    xx = strfind(His.mod_short{hno},'ac');
    out_file1 = fullfile(special.outpath,['Iso_',special.outfile,'_',num2str(length(xx)),'ac','_',His.mod_short{hno}]);
    plot(n_rt,n_inten1,'linestyle','-','linewidth',2,'color','k');
    hold on;
    plot(n_rt,n_inten2,'linestyle','--','linewidth',2,'color','r');
    plot(n_rt,n_inten3,'linestyle','-.','linewidth',2,'color','b');
    plot(n_rt,n_inten4,'linestyle','--','linewidth',2,'color','g');
    plot(n_rt,n_inten5,'linestyle','-.','linewidth',2,'color','m');
    plot(n_rt,n_inten6,'linestyle','--','linewidth',2,'color','c');
    plot(n_rt,n_inten7,'linestyle','-.','linewidth',2,'color','y');
    xlabel('Time (min)','FontWeight','bold');
    ylabel('Abundance','FontWeight','bold');
    legend('experiment',His.mod_short{hno},His.mod_short{hno+1},His.mod_short{hno+2},His.mod_short{hno+3},His.mod_short{hno+4},His.mod_short{hno+5});
    r1 = floor(100*ratio(1));
    r2 = floor(100*ratio(2));
    r3 = floor(100*ratio(3));
    r4 = floor(100*ratio(4));
    r5 = floor(100*ratio(5));
    r6 = 100-r1-r2-r3-r4-r5;
    title([His.mod_short{hno},'/',His.mod_short{hno+1},'/',His.mod_short{hno+2},'/',His.mod_short{hno+3},'/',His.mod_short{hno+4},'/',His.mod_short{hno+5},':',num2str(r1),'%:',num2str(r2),'%:',num2str(r3),'%:',num2str(r4),'%:',num2str(r5),'%:',num2str(r6),'%']);
    print(sformat,out_file1);
    close();
end

function X = resove_linear(r1,r2,r3,r4,r5)
%%

if r2==0
    % r2=0
    a=0;
    b=0;
    d=0;
    c=r3;
    if r3>=r4
        e=0;
        f=1-r3;
    else
        e=r4-r3;
        f=1-r4;
    end
    X = [a,b,c,d,e,f];
elseif r3==0
    % r3=0
    a=0;
    b=0;
    c=0;
    d=r2;
    if r2>=r4
        e=0;
        f=1-r2;
    else
        e=r4-r2;
        f=1-r4;
    end
    X = [a,b,c,d,e,f];
elseif r4==0
    % r4=0
    a=r2;
    b=0;
    c=0;
    d=0;
    e=0;
    f=1-r2;
    X = [a,b,c,d,e,f];
elseif r1==0
    % r1=0
    a=0;
    if r3>=r4
        d=0;
        e=0;
        b=r2;
        if r2>=r3
            c=0;
        else
            c=r3-r2;
        end
        f=1-b-c;
    elseif r2>=r4
        c=0;
        e=0;
        b=r3;
        if r3>=r2
            d=0;
        else
            d=r2-r3;
        end
        f=1-b-d;
    else
        if r2>r3
            c=0;
            b=r3;
            d=r2-r3;
            e=r4-r2;
        else
            d=0;
            b=r2;
            c=r3-r2;
            e=r4-r3;
        end
        f=1-r4;
    end
    X = [a,b,c,d,e,f];
elseif r5==0
    % r5=0
    a=r1;
    f=0;
    if r1>=r2
        b=0;
        d=0;
        if r1>=r3
            c=0;
            e=1-r1;
        else
            c=r3-r1;
            e=1-r3;
        end
    elseif r1>=r3
        b=0;
        c=0;
        d=r2-r1;
        e=1-r2;
    else
        % similar to r1=0
        r2=r2-r1;
        r3=r3-r1;
        r4=1-r1;
        if r3>=r4
            d=0;
            e=0;
            b=r2;
            if a+b>=1
                b=1-a;
                c=0;
            else
                c=1-a-b;
            end
        elseif r2>=r4
            c=0;
            e=0;
            b=r3;
            if a+b>=1
                b=1-a;
                d=0;
            else
                d=1-a-b;
            end
        else
            if r2>r3
                c=0;
                b=r3;
                d=r2-r3;
                e=r4-r2;
            else
                d=0;
                b=r2;
                c=r3-r2;
                e=r4-r3;
            end
            a=1-r4;
        end
    end
    X = [a,b,c,d,e,f];
else
    % all above 0
    a=r4/(r4+1/r1-1);
    f=1-r4/(r1*r4+1-r1);
    if a+f>=1
        b=0;
        c=0;
        d=0;
        e=0;
        f=1-a;
    elseif a>=r2
        b=0;
        d=0;
        if a>=r3
            c=0;
            e=1-a-f;
        else
            c=r3-a;
            if a+f+c>=1
                c=1-a-f;
                e=0;
            else
                e=1-a-f-c;
            end
        end
    elseif a>=r3
        b=0;
        c=0;
        d=r2-a;
        if a+f+d>=1
            d=1-a-f;
            e=0;
        else
            e=1-a-f-d;
        end
    else
        % similar to r1=0
        r2=r2-a;
        r3=r3-a;
        r4=1-a-f;
        if r3>=r4
            d=0;
            e=0;
            b=r2;
            if a+f+b>=1
                b=1-a-f;
                c=0;
            else
                c=1-a-f-b;
            end
        elseif r2>=r4
            c=0;
            e=0;
            b=r3;
            if a+f+b>=1
                b=1-a-f;
                d=0;
            else
                d=1-a-f-b;
            end
        else
            if r2>r3
                c=0;
                b=r3;
                d=r2-r3;
                e=r4-r2;
            else
                d=0;
                b=r2;
                c=r3-r2;
                e=r4-r3;
            end
        end
    end
    X = [a,b,c,d,e,f];
end

pp = find(X<0);
if 0==isempty(pp)
    X(pp) = 0;
    tmpsum = eps+sum(X);
    X = X/tmpsum;
end

if 1==X(end)
    X = [0 0 0 0 0.01 0.99];
end