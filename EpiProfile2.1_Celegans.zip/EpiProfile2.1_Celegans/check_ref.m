function [t1,t2] = check_ref(raw_path,new_seq,pre_nums,ndebug,rt_MS1)

mat_file = fullfile(raw_path,'histone_layouts','0_ref_info.mat');
if 0==ndebug && 0~=exist(mat_file,'file')
    load(mat_file);%#ok
    new_godel = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));
    ix = find(AllUnHis.seq_godel==new_godel);
    if 0==isempty(ix)
        rt_ref = AllUnHis.rt_ref(ix(1));
        delta = 5;
        t1 = rt_ref-delta;
        t2 = rt_ref+delta;
    else
        t1 = 0;
        t2 = rt_MS1;
    end
else
    t1 = 0;
    t2 = rt_MS1;
end