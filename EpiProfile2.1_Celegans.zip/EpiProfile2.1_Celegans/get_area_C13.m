function [pep_area,c_mono_isointens] = get_area_C13(c_isorts,c_ref_isointens,nb,cur_mz,cur_ch,IPV,nshift)
%%

% init
pep_area = 0;
ncol = size(c_ref_isointens,2);
c_mono_isointens = c_ref_isointens(:,ncol);

% Sum the isotopic clusters
M = cur_mz*cur_ch-cur_ch*1.007276;
tIPV = IPV(floor(M),1:5);
fCali = sum(tIPV);

nw = c_mono_isointens;
% nw = smooth(nw,3);
nw(find(nw<0.015*max(nw))) = 0;%#ok

for ino=1:length(nb)-1
    i1 = nb(ino);
    i2 = nb(ino+1);
    while i1<=length(nw) && 0==nw(i1)
        i1 = i1+1;
    end
    if i1>nb(ino) && nw(i1-1)>0
        i1 = i1-1;
    end
    while i2>=1 && 0==nw(i2)
        i2 = i2-1;
    end
    if i2<nb(ino+1) && nw(i2+1)>0
        i2 = i2+1;
    end
    IX = i1:i2;
end
if 1==isempty(IX)
    return;
elseif length(IX)<=2
    pep_area = sum( c_mono_isointens(IX) )*fCali;
    return;
end

if ncol>1
    for i=i1:i2
        tmp_areas = c_ref_isointens(i,1:ncol);
        c_area = tmp_areas(1);
        for j=2:ncol
            c_area = max([0 tmp_areas(jno)-c_area*tIPV(nshift+1)]);
        end
        c_mono_isointens(i) = c_area;
    end
end

% n_rt, n_inten
n_rt = c_isorts(IX);
n_inten = c_mono_isointens(IX);
n_inten = smooth(n_inten,3);

% area
xx = n_rt(1):0.005:n_rt(end);
yy = spline(n_rt,n_inten,xx);
pep_area = sum(abs(yy));

pep_area = pep_area*fCali;