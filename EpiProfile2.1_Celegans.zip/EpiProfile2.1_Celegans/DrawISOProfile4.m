function DrawISOProfile4(special)
%%

raw_path = special.raw_path;
raw_names = special.raw_names;

layout_path = fullfile(raw_path,'histone_layouts','N15');
if 0==exist(layout_path,'dir') && 0==mkdir(layout_path)
    fprintf(1,'can not create: %s\n',layout_path);
    return;
end

for i=1:length(raw_names)
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',raw_names{i}]);
    if 0==exist(cur_outpath,'dir') && 0==mkdir(cur_outpath)
        fprintf(1,'can not create: %s\n',cur_outpath);
        return;
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',raw_names{i}],'detail');
    if 0==exist(cur_outpath,'dir') && 0==mkdir(cur_outpath)
        fprintf(1,'can not create: %s\n',cur_outpath);
        return;
    end
end

for i=1:length(raw_names)
    fprintf(1,'\n%s\n',raw_names{i});
    cur_rawname = raw_names{i};
    MS1_scanfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1scans.mat']);
    MS1_peakfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1peaks.mat']);
    MS2_scanfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2scans.mat']);
    MS2_peakfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2peaks.mat']);
    load(MS1_scanfile);%#ok MS1_index
    load(MS1_peakfile);%#ok MS1_peaks
    load(MS2_scanfile);%#ok MS2_index
    load(MS2_peakfile);%#ok MS2_peaks
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail');
    special.outpath = cur_outpath;
    special.c_rno = i;
    H3H_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    H3H_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    H3H_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    H3H_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    H3H_07_73_83(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    H4H_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    H4H_02_20_23(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    HH2AH_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    HH2AH_04m3_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    fprintf(1,'\n');
end

OutputTogether(layout_path,raw_names,'');