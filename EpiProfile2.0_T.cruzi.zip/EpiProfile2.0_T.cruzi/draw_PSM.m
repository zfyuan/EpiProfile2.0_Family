function draw_PSM(His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special)
%%

% cur_outpath, out_filename
cur_outpath = special.outpath;
out_filename = special.outfile;

% npep, ix
npep = size(His.pep_mz,1);
ix = find(pep_rts(1:npep,1)>3);
if 1==isempty(ix)
    return;
end

% nplot, localmax_rt, localmax_inten, terminus
nplot = length(ix);
localmax_rt = zeros([nplot,1]);
localmax_inten = zeros([nplot,1]);
terminus = zeros([nplot,2]);
for ino=1:nplot
    cno = ix(ino);
    p = find(isorts<=pep_rts(cno,1));
    c_ms1pos = p(end);
    c_mono_isointens = mono_isointens(:,cno);
    localmax_rt(ino) = pep_rts(cno,1);
    if pep_intens(cno,1)>0 && sum(c_mono_isointens)>0
        [nt,nb,top1_idx] = GetTopBottom11(c_mono_isointens);
        terminus(ino,1:2) = [nb(1) nb(end)];
        localmax_inten(ino) = c_mono_isointens(nt(top1_idx));
    else
        terminus(ino,1:2) = [c_ms1pos c_ms1pos];
    end
end

% psm_outpath, nDAmode, sformat
psm_outpath = fullfile(cur_outpath,'psm');
if 0==exist(psm_outpath,'dir') && 0==mkdir(psm_outpath)
    fprintf(1,'can not create: %s\n',psm_outpath);
    return;
end
nDAmode = special.nDAmodes(special.c_rno);
if 1==special.nformat
    sformat = '-dpdf';
elseif 2==special.nformat
    sformat = '-dpng';
else
    sformat = '-dtiff';
end

% out_filename_new, xp, cur_title
out_filename_new = out_filename;
if 1==strcmp(out_filename(1:2),'HH')
    out_filename_new = out_filename(2:end);
end
xp = strfind(out_filename_new,'_');
cur_title = [out_filename_new(1:xp(1)-1),' ',out_filename_new(xp(2)+1:xp(3)-1),'-',out_filename_new(xp(3)+1:end),' ',His.pep_seq,repmat(' ',1,90)];

% colors, widths
colors = {'k','r','g','b','c','m'};
cw = ones(1,6)*0.5;
widths = [];
for i=1:50
    widths(1,(i-1)*6+1:(i-1)*6+6) = cw+(i-1)*0.1;
end

% mat_file
mat_file = fullfile(psm_outpath,[out_filename,'.mat']);

% His0
[layoutpath,cur_raw] = fileparts(fileparts(cur_outpath));%#ok
p0 = strfind(cur_raw,'_');
His0.raw = cur_raw(p0(1)+1:end);
p0 = strfind(out_filename_new,'_');
His0.prot = out_filename_new(1:p0(1)-1);
His0.seq = repmat({''},[npep,1]);
His0.short = repmat({''},[npep,1]);
for ino=1:size(His.mod_type,1)
    if 1==strcmp(His.pep_seq,'unmod')
        c_seq = His.mod_short{ino};
        p0 = strfind(c_seq,'.');
        if 0==isempty(p0)
            c_seq = c_seq(p0(end)+1:end);
        end
        His0.seq{ino} = c_seq;
        His0.short{ino} = 'unmod';
    else
        His0.seq{ino} = His.pep_seq;
        His0.short{ino} = His.mod_short{ino};
    end
end

% psm
psm.fname = {};
psm.emz = [];
psm.tmz = [];
psm.chg = [];
psm.ppm = [];
psm.seq = {};
psm.mod1 = {};
psm.mod2 = {};
psm.prot = {};
psm.rt = [];
fno = 0;

% get precursors
for ino=1:nplot
    cno = ix(ino);
    if terminus(ino,1)==terminus(ino,2)
        continue;
    end
    rt1 = isorts(terminus(ino,1));
    rt2 = isorts(terminus(ino,2));
    [ms2pos,ms2rts,ms2intens,K1,Tag1] = MatchMS2(MS2_index,MS2_peaks,special,His,cno,rt1,rt2,1);
    if 1==isempty(ms2pos)
        continue;
    end
    
    % get the info
    if 1==nDAmode% DDA
        for mno=1:length(ms2pos)
            if 0==sum(ms2intens(ms2pos(mno),:))
                continue;
            end
            warning off all;
            set(gcf,'visible','off');
            % set(gcf,'position',[0 0 1000 1000]);
            ms2scan = MS2_index(ms2pos(mno),3);
            out_file1 = fullfile(psm_outpath,[out_filename,'_',num2str(cno),'_',His.mod_short{cno},'_',num2str(ms2scan)]);
            hold on;
            for kno=1:length(K1)
                c_mzs = K1(kno);
                c_intens = ms2intens(ms2pos(mno),kno);
                c_tag = Tag1{kno};
                if 1==strcmp(c_tag(1),'b') || 1==strcmp(c_tag(1),'c')
                    c_color = 'b';
                else
                    c_color = 'r';
                end
                stem(c_mzs,c_intens,'marker','none','color',c_color);
                text(c_mzs,c_intens,c_tag,'color',c_color,'fontsize',9);
            end
            title([out_filename_new(1:xp(1)-1),' ',out_filename_new(xp(2)+1:xp(3)-1),'-',out_filename_new(xp(3)+1:end),' ',His.pep_seq,' ',His.mod_short{cno},' ',num2str(ms2scan),' +',num2str(His.pep_ch(cno,1))]);
            xlabel('m/z (Th)','FontWeight','bold');
            ylabel('Abundance','FontWeight','bold');
            print(sformat,out_file1);
            close();
            
            out_file2 = fullfile(psm_outpath,[out_filename,'_',num2str(cno),'_',His.mod_short{cno},'_',num2str(ms2scan),'.dta']);
            fp = fopen(out_file2,'w');
            if -1==fp
                fprintf('can not open: %s\n',out_file2);
                return;
            end
            fprintf(fp,'seq_mod=%s\r\npepmz=%.4f\r\npepch=%d\r\nrt=%.2f\r\n',[His.pep_seq,'_',His.mod_short{cno}],His.pep_mz(cno,1),His.pep_ch(cno,1),localmax_rt(ino));
            for kno=1:length(K1)
                fprintf(fp,'%.4f\t%.1f\t%s\r\n',K1(kno),ms2intens(ms2pos(mno),kno), Tag1{kno});
            end
            fclose(fp);
            
            % psm
            fno = fno + 1;
            psm.fname{fno,1} = [His0.raw,'.',num2str(ms2scan),'.',num2str(ms2scan),'.',num2str(His.pep_ch(cno,1))];
            psm.emz(fno,1) = MS2_index(ms2pos(mno),4);
            psm.tmz(fno,1) = His.pep_mz(cno,1);
            psm.chg(fno,1) = His.pep_ch(cno,1);
            psm.ppm(fno,1) = 1e6*(psm.emz(fno,1)-psm.tmz(fno,1))/psm.tmz(fno,1);
            psm.seq{fno,1} = His0.seq{cno};
            psm.mod1{fno,1} = His0.short{cno};
            psm.mod2{fno,1} = His.mod_type{cno};
            psm.prot{fno,1} = His0.prot;
            psm.rt(fno,1) = localmax_rt(ino);
        end
        
        if 0==sum(sum(ms2intens(ms2pos,:),1))
            continue;
        end
        out_file3 = fullfile(psm_outpath,[out_filename,'_',num2str(cno),'_',His.mod_short{cno},'.dta']);
        fp = fopen(out_file3,'w');
        if -1==fp
            fprintf('can not open: %s\n',out_file3);
            return;
        end
        fprintf(fp,'seq_mod=%s\r\npepmz=%.4f\r\npepch=%d\r\nrt=%.2f\r\n',[His.pep_seq,'_',His.mod_short{cno}],His.pep_mz(cno,1),His.pep_ch(cno,1),localmax_rt(ino));
        for kno=1:length(K1)
            fprintf(fp,'%.4f\t%.1f\t%s\r\n',K1(kno),sum( ms2intens(ms2pos,kno) ), Tag1{kno});
        end
        fclose(fp);
    else% DIA
        warning off all;
        set(gcf,'visible','off');
        % set(gcf,'position',[0 0 1000 1000]);
        out_file1 = fullfile(psm_outpath,[out_filename,'_',num2str(cno),'_',His.mod_short{cno}]);
        
        subplot(3,1,1);
        plot(isorts,mono_isointens(:,cno),'color','b','linewidth',1);
        set(gca,'xtick',[],'ytick',[]);
        hold on;
        xlim([rt1 rt2]);
        if localmax_inten(ino)>0
            ylim([0 1.05*localmax_inten(ino)]);
        end
        % localmax
        cur_txt = [His.mod_short{cno},',+',num2str(His.pep_ch(cno,1)),', ',num2str(localmax_rt(ino),'%.1f'),', ',num2str(localmax_inten(ino),'%.1e')];
        text(localmax_rt(ino),1.25*localmax_inten(ino),cur_txt,'color','r','fontsize',9);
        % boundary
        plot([rt1 rt2],[0 0],'color','m','linewidth',1);
        title(cur_title);
        hold off;
        
        subplot(3,1,2);
        hold on;
        no = 0;
        for kno=1:length(K1)
            c_tag = Tag1{kno};
            if 1==strcmp(c_tag(1),'b') || 1==strcmp(c_tag(1),'c')
                no = no + 1;
                plot(ms2rts(ms2pos),ms2intens(ms2pos,kno),'color',colors{mod(no,6)+1},'linewidth',widths(no));
                text(localmax_rt(ino),max( ms2intens(ms2pos,kno) ),c_tag,'color',colors{mod(no,6)+1},'fontsize',9);
            end
        end
        xlim([rt1 rt2]);
        set(gca,'xtick',[]);
        hold off;
        
        subplot(3,1,3);
        hold on;
        no = 0;
        for kno=1:length(K1)
            c_tag = Tag1{kno};
            if 0==strcmp(c_tag(1),'b') && 0==strcmp(c_tag(1),'c')
                no = no + 1;
                plot(ms2rts(ms2pos),ms2intens(ms2pos,kno),'color',colors{mod(no,6)+1},'linewidth',widths(no));
                text(localmax_rt(ino),max( ms2intens(ms2pos,kno) ),c_tag,'color',colors{mod(no,6)+1},'fontsize',9);
            end
        end
        xlim([rt1 rt2]);
        set(gca,'xtickMode', 'auto');
        xlabel('Time (min)','FontWeight','bold');
        ylabel('Abundance','FontWeight','bold');
        
        print(sformat,out_file1);
        close();
        
        out_file2 = fullfile(psm_outpath,[out_filename,'_',num2str(cno),'_',His.mod_short{cno},'.dta']);
        fp = fopen(out_file2,'w');
        if -1==fp
            fprintf('can not open: %s\n',out_file2);
            return;
        end
        fprintf(fp,'seq_mod=%s\r\npepmz=%.4f\r\npepch=%d\r\nrt=%.2f\r\n',[His.pep_seq,'_',His.mod_short{cno}],His.pep_mz(cno,1),His.pep_ch(cno,1),localmax_rt(ino));
        for kno=1:length(K1)
            fprintf(fp,'%.4f\t%.1f\t%s\r\n',K1(kno),sum( ms2intens(ms2pos,kno) ), Tag1{kno});
        end
        fclose(fp);
        
        % psm
        fno = fno + 1;
        ms2scan = 0;
        p1 = find(ms2rts(ms2pos)<=localmax_rt(ino));
        if 0==isempty(p1)
            ms2scan = MS2_index(ms2pos(p1(end)),3);
        end
        psm.fname{fno,1} = [His0.raw,'.',num2str(ms2scan),'.',num2str(ms2scan),'.',num2str(His.pep_ch(cno,1))];
        psm.emz(fno,1) = 0;
        psm.tmz(fno,1) = His.pep_mz(cno,1);
        psm.chg(fno,1) = His.pep_ch(cno,1);
        psm.ppm(fno,1) = 0;
        psm.seq{fno,1} = His0.seq{cno};
        psm.mod1{fno,1} = His0.short{cno};
        psm.mod2{fno,1} = His.mod_type{cno};
        psm.prot{fno,1} = His0.prot;
        psm.rt(fno,1) = localmax_rt(ino);
    end
end

% save psm
save(mat_file,'psm');
