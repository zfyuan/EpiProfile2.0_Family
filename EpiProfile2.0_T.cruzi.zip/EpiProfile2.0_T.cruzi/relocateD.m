function His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,n1st)
% debug

delta = 0.5;

if 1==n1st
    nrange = 1;
else
    nrange = 2:length(His.rt_ref);
end
for hno = nrange
    t1 = His.rt_ref(hno)-delta;
    t2 = His.rt_ref(hno)+delta;
    top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,1,t1,t2);
    
    if 1==isempty(top1_rt)
        His.rt_ref(hno) = 0;
    else
        His.rt_ref(hno) = top1_rt;
    end
end