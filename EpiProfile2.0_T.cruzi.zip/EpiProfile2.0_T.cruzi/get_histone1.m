function [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno)
%%

[npep,ncharge] = size(His.pep_mz);%#ok
cur_rts = zeros([1,ncharge]);
cur_intens = zeros([1,ncharge]);

ptol = special.ptols(special.c_rno);
unitdiff = special.unitdiff;
IPV = special.IPV;

delta = 0.5;
p = find( MS1_index(:,2)>=His.rt_ref(hno)-delta );
rt_i1 = p(1);
pp = find( MS1_index(:,2)<=His.rt_ref(hno)+delta );
rt_i2 = pp(end);

for jno=1:ncharge
    % get MS1 profile
    c_mz = His.pep_mz(hno,jno);
    c_ch = His.pep_ch(hno,jno);
    c_ref_isomzs = [c_mz-unitdiff/c_ch c_mz c_mz+unitdiff/c_ch c_mz+2*unitdiff/c_ch];
    if ptol>100 && c_ch>=3
        nC13 = 1;
    else
        nC13 = 0;
    end
    [c_isorts,c_ref_isointens] = GetProfiles(MS1_index,MS1_peaks,c_ref_isomzs,c_ch,ptol,IPV,nC13,rt_i1:rt_i2);
    c_mono_isointens = c_ref_isointens(:,2);
    if 1==jno
        cur_mono_isointens = c_mono_isointens;
    end
    
    % get rt and area
    [nt,nb,top1_idx,inten_sum] = GetTopBottom11(c_mono_isointens);%#ok
    if 0==isempty(nt)
        nb2 = [nb(top1_idx) nb(top1_idx+1)];
        cur_pos = nt(top1_idx);
        cur_rts(jno) = c_isorts(cur_pos);
        cur_intens(jno) = get_area(c_isorts,c_mono_isointens,nb2,c_mz,c_ch,IPV);
    else
        cur_rts(jno) = His.rt_ref(hno);
        cur_intens(jno) = 0;
    end
end