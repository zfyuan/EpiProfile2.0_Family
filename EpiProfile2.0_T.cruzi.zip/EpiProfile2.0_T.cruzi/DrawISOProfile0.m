function DrawISOProfile0(special)
%%

% check
if 0~=special.ndebug
    return;
end

raw_path = special.raw_path;
raw_names = special.raw_names;

layout_path = fullfile(raw_path,'histone_layouts');
if 0==exist(layout_path,'dir') && 0==mkdir(layout_path)
    fprintf(1,'can not create: %s\n',layout_path);
    return;
end
mat_file = fullfile(layout_path,'0_ref_info.mat');
if 0~=exist(mat_file,'file')
    return;
end

fprintf(1,'get a reference...\n');
AllUnHis = init_histone0(special);

% get top 3 raw files
ntop = 3;
range = 1:length(raw_names);
if length(raw_names)>ntop
    ipos = 3;% H3_02_54_66
    rts = zeros(length(ipos),length(raw_names));
    intens = zeros(length(ipos),length(raw_names));
    for jno=1:length(raw_names)
        special.c_rno = jno;
        cur_rawname = raw_names{jno};
        MS1_scanfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1scans.mat']);
        MS1_peakfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1peaks.mat']);
        MS2_scanfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2scans.mat']);
        MS2_peakfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2peaks.mat']);
        load(MS1_scanfile);%#ok MS1_index
        load(MS1_peakfile);%#ok MS1_peaks
        load(MS2_scanfile);%#ok MS2_index
        load(MS2_peakfile);%#ok MS2_peaks
        for ino=1:length(ipos)
            c_His.pep_seq = AllUnHis.pep_seq{ipos(ino),1};
            c_His.mod_type{1,1} = AllUnHis.mod_type{ipos(ino),1};
            c_His.pep_mz(1,1) = AllUnHis.pep_mz(ipos(ino),1);
            c_His.pep_ch(1,1) = AllUnHis.pep_ch(ipos(ino),1);
            [c_top1_rt,c_top1_inten_sum] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,c_His,1,1,0,MS1_index(size(MS1_index,1),2));
            if 0==isempty(c_top1_rt)
                rts(ino,jno) = c_top1_rt;
                intens(ino,jno) = c_top1_inten_sum;
            end
        end
    end
    [tmp,q] = max(intens);%#ok
    i = find( abs(rts-rts(q))<2 );
    if length(i)<ntop
        range = i;
    else
        [tmp,x] = min( abs(rts(i)-median(rts(i))) );%#ok
        [tmp,l] = find(rts(i)<rts(i(x)));%#ok
        [tmp,r] = find(rts(i)>rts(i(x)));%#ok
        [tmp,ll] = max(intens(i(l)));%#ok
        [tmp,rr] = max(intens(i(r)));%#ok
        range = [i(l(ll)) i(x) i(r(rr))];
    end
end

% get rt_ref
info_rts = zeros(length(AllUnHis.pep_mz),length(range));
for jno=1:length(range)
    special.c_rno = range(jno);
    cur_rawname = raw_names{range(jno)};
    MS1_scanfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1scans.mat']);
    MS1_peakfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1peaks.mat']);
    MS2_scanfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2scans.mat']);
    MS2_peakfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2peaks.mat']);
    load(MS1_scanfile);%#ok MS1_index
    load(MS1_peakfile);%#ok MS1_peaks
    load(MS2_scanfile);%#ok MS2_index
    load(MS2_peakfile);%#ok MS2_peaks
    for ino=1:length(AllUnHis.pep_mz)
        c_His.pep_seq = AllUnHis.pep_seq{ino,1};
        c_His.mod_type{1,1} = AllUnHis.mod_type{ino,1};
        c_His.pep_mz(1,1) = AllUnHis.pep_mz(ino,1);
        c_His.pep_ch(1,1) = AllUnHis.pep_ch(ino,1);
        c_top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,c_His,1,1,0,MS1_index(size(MS1_index,1),2));
        if 0==isempty(c_top1_rt)
            info_rts(ino,jno) = c_top1_rt;
        end
    end
    AllUnHis.selected_raws{jno,1} = cur_rawname;
end
for ino=1:length(AllUnHis.pep_mz)
    AllUnHis.rt_ref(ino,1) = median(info_rts(ino,:));
end

save(mat_file,'AllUnHis');