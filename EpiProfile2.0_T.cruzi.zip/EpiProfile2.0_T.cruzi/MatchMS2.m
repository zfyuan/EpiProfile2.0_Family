function [ms2pos,ms2rts,ms2intens,K1,Tag1] = MatchMS2(MS2_index,MS2_peaks,special,His,hno,rt1,rt2,nall)
%%

ms2pos = [];
ms2rts = [];
ms2intens = [];
K1 = [];
Tag1 = [];

ptol = special.ptols(special.c_rno);
nDAmode = special.nDAmodes(special.c_rno);
wind = special.windows(special.c_rno,:);
wind = wind(find(wind>0));%#ok
unitdiff = special.unitdiff;
Mods = special.Mods;
nhmass = special.nhmass;

% init
num_MS2 = size(MS2_index,1);
c_mz = His.pep_mz(hno,1);
c_ch = His.pep_ch(hno,1);
p = find( MS2_index(:,2)>=rt1 );
pp = find( MS2_index(:,2)<=rt2 );
if 1==isempty(p) || 1==isempty(pp)
    return;
end
i1 = p(1);
i2 = pp(end);
flag = zeros([num_MS2,1]);

% ms2pos
if 1==nDAmode
    % DDA
    sets = [0 1 2];
    mzs = c_mz + sets*unitdiff/c_ch;
    for i=i1:i2
        cen_mz = MS2_index(i,4);
        ix = find(abs(mzs-cen_mz)<min([ptol*c_mz*1e-6,0.3]));%#ok
        if 0==isempty(ix)
            flag(i) = 1;
        end
    end
elseif 2==nDAmode
    % DIA
    x = find(wind<=c_mz);
    ii = x(end);
    premzs = unique(MS2_index(:,4));
    target = premzs(ii);
    for i=i1:i2
        cen_mz = MS2_index(i,4);
        if 0==cen_mz-target
            flag(i) = 1;
        end
    end
end
ms2pos = find(flag==1);
if 1==isempty(ms2pos)
    return;
end

% ms2rts
ms2rts = MS2_index(:,2);

instruments = MS2_index(ms2pos,6);% MS2dirs = {'CIDIT','CIDFT','ETDIT','ETDFT','HCDIT','HCDFT'};
% if 1==length(unique(instruments))
% ActiveType, tol
c_instrument = instruments(1);
if 3==c_instrument || 4==c_instrument
    ActiveType = 'ETD';
else
    ActiveType = 'CID';
end
if 1==mod(c_instrument,2)
    tol = 0.4;
else
    tol = 0.02;
end

% K1,K2
[K1,Tag1] = get_key_ions(His,hno,Mods,ActiveType,nhmass,nall);
% end

% ms2intens
index = [1;MS2_index(1:num_MS2,7)];
ms2intens = zeros([num_MS2,size(K1,2)]);
for i=1:length(ms2pos)
    pno = ms2pos(i);
    if pno<1 || pno>num_MS2
        continue;
    end
    if 1<length(unique(instruments))
        % ActiveType, tol
        c_instrument = MS2_index(pno,6);% MS2dirs = {'CIDIT','CIDFT','ETDIT','ETDFT','HCDIT','HCDFT'};
        if 3==c_instrument || 4==c_instrument
            ActiveType = 'ETD';
        else
            ActiveType = 'CID';
        end
        if 1==mod(c_instrument,2)
            tol = 0.4;
        else
            tol = 0.02;
        end
        
        % K1,K2
        [K1,Tag1] = get_key_ions(His,hno,Mods,ActiveType,nhmass,nall);
    end
    
    % mz, inten
    IX = index(pno):index(pno+1)-1;
    mz = MS2_peaks(IX,1);
    inten = MS2_peaks(IX,2);
    X = find(inten>=MS2_index(pno,8));
    mz = mz(X);
    inten = inten(X);
    
    % match key ions
    for j=1:size(K1,2)
        ix1 = find(abs(mz-K1(j))<=tol);
        %[tmp,x1] = min(abs(mz(ix1)-K1(j)));%#ok
        [tmp,x1] = max(inten(ix1));%#ok
        if 0==isempty(ix1)
            ms2intens(pno,j) = inten(ix1(x1));
        end
    end
end