function [top1_rt,top1_inten_sum] = get_rts0(MS1_index,MS1_peaks,ptol,His,hno)
%%

unitdiff = 1.0032;
num_MS1 = size(MS1_index,1);

if ptol>100 && His.pep_ch(hno)>=3
    nC13 = 1;
else
    nC13 = 0;
end
new_pos = num_MS1;

% get MS1 profile
c_mz = His.pep_mz(hno);
c_ch = His.pep_ch(hno);

c_ref_isomzs = [c_mz-unitdiff/c_ch c_mz c_mz+unitdiff/c_ch c_mz+2*unitdiff/c_ch];
[c_isorts,c_ref_isointens] = GetProfiles(MS1_index,MS1_peaks,c_ref_isomzs,c_ch,ptol,nC13,1:new_pos);
c_mono_isointens = c_ref_isointens(:,2);
[nt,nb,top1_idx,inten_sum] = GetTopBottom(c_mono_isointens);%#ok
top1_rt = c_isorts(nt(top1_idx));
top1_inten_sum = inten_sum(top1_idx);

if 1==isempty(top1_rt) || top1_rt<3
    top1_rt = 0;
    top1_inten_sum = 0;
end