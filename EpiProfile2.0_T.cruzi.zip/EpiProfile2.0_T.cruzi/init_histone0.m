function His = init_histone0(special)
%%

no = 0;
pre_nums = special.pre_nums;

% checklist
%% H3
no = no + 1;
His.out_filename{no,1} = 'H3_01_1_8';
His.pep_seq{no,1} = 'SRSKETAR';
His.mod_type{no,1} = '0,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_01_3_8';
His.pep_seq{no,1} = 'SKETAR';
His.mod_type{no,1} = '0,pr;2,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_02_54_66';
His.pep_seq{no,1} = 'STDLLLQKAPFQR';
His.mod_type{no,1} = '0,pr;8,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_03_70_80';
His.pep_seq{no,1} = 'EVSGAQKEGLR';
His.mod_type{no,1} = '0,pr;7,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_04_39_51';
His.pep_seq{no,1} = 'IVAKKESVSAGTR';
His.mod_type{no,1} = '0,pr;4,pr;5,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_05_88_98';
His.pep_seq{no,1} = 'EIVSNLKDSFR';
His.mod_type{no,1} = '0,pr;7,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_06u_37_113';
His.pep_seq{no,1} = 'RWRPGTVALR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_06u_37_113';
His.pep_seq{no,1} = 'WRPGTVALR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_06u_37_113';
His.pep_seq{no,1} = 'EIRQFQR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_06u_37_113';
His.pep_seq{no,1} = 'ACIHSGR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_06u_37_113';
His.pep_seq{no,1} = 'KNLASR';
His.mod_type{no,1} = '0,pr;1,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_06u_37_113';
His.pep_seq{no,1} = 'KIHTEGR';
His.mod_type{no,1} = '0,pr;1,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H3_06u_37_113';
His.pep_seq{no,1} = 'WRPGTVVLR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

%% H4
no = no + 1;
His.out_filename{no,1} = 'H4_01_1_15';
His.pep_seq{no,1} = 'AKGKKSGEAKGTQKR';
His.mod_type{no,1} = '0,pr;2,pr;4,pr;5,pr;10,pr;14,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_01a_1_15';
His.pep_seq{no,1} = 'AKGKKSGEAKGTQKR';
His.mod_type{no,1} = '0,ac;2,pr;4,pr;5,pr;10,pr;14,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_02_16_21';
His.pep_seq{no,1} = 'QKKILR';
His.mod_type{no,1} = '0,pr;2,pr;3,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_03_76_89';
His.pep_seq{no,1} = 'KKTVTAVDVVNALR';
His.mod_type{no,1} = '0,pr;1,pr;2,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'ENVRGITR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'GITRGSIR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'RLAR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'RGGVKR';
His.mod_type{no,1} = '0,pr;5,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'GGVKR';
His.mod_type{no,1} = '0,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'ISGVIYDEVR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'GVIKSFVEGVVR';
His.mod_type{no,1} = '0,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'DATAYTEYSR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'KRGKILYGYA';
His.mod_type{no,1} = '0,pr;1,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'GKILYGYA';
His.mod_type{no,1} = '0,pr;2,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'ISGVMYDEVR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'GVIKKFVEGVVR';
His.mod_type{no,1} = '0,pr;4,pr;5,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'H4_04u_22_99';
His.pep_seq{no,1} = 'GKILYGYE';
His.mod_type{no,1} = '0,pr;2,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

%% ------------------H2A------------------
no = no + 1;
His.out_filename{no,1} = 'HH2A_01_1_18';
His.pep_seq{no,1} = 'ATPKQAAKKASKKHGGGR';
His.mod_type{no,1} = '0,ac;2,ph;4,pr;8,pr;9,pr;12,pr;13,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_01_19_30';
His.pep_seq{no,1} = 'SAKAGLIFPVGR';
His.mod_type{no,1} = '0,pr;3,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_01o1_19_30';
His.pep_seq{no,1} = 'SAKAGLTFPVGR';
His.mod_type{no,1} = '0,pr;3,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_02_41_51';
His.pep_seq{no,1} = 'GKGKGKGKGKR';
His.mod_type{no,1} = '0,pr;2,pr;4,pr;6,pr;8,pr;10,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_03_52_62';
His.pep_seq{no,1} = 'GGKTGGKAGKR';
His.mod_type{no,1} = '0,pr;3,pr;7,pr;10,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'VGSLLR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'VGSLLRR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'RGQYAR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'TVTLAVR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'DKMSR';
His.mod_type{no,1} = '0,pr;2,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'ADLNFPVGR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'LKDGLNR';
His.mod_type{no,1} = '0,pr;2,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2A_04u_31_139';
His.pep_seq{no,1} = 'HLLLAIR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

%% ------------------H2B------------------
no = no + 1;
His.out_filename{no,1} = 'HH2B_01_27_38';
His.pep_seq{no,1} = 'KASGGKKKGGAR';
His.mod_type{no,1} = '0,pr;1,pr;6,pr;7,pr;8,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_02_61_69';
His.pep_seq{no,1} = 'GTLSKAAVR';
His.mod_type{no,1} = '0,pr;5,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_03_1_10';
His.pep_seq{no,1} = 'ATPKSSSANR';
His.mod_type{no,1} = '0,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_04_11_16';
His.pep_seq{no,1} = 'KKGGKR';
His.mod_type{no,1} = '0,pr;1,pr;2,pr;5,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_05_32_45';
His.pep_seq{no,1} = 'SLKSINNHMSMSGR';
His.mod_type{no,1} = '0,pr;3,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_06_61_70';
His.pep_seq{no,1} = 'IASEAATVVR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_07_71_75';
His.pep_seq{no,1} = 'VNKKR';
His.mod_type{no,1} = '0,pr;3,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'SHRKPKR';
His.mod_type{no,1} = '0,pr;4,pr;6,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'TWNVYISR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'TMKIVNSFVNDLFER';
His.mod_type{no,1} = '0,pr;3,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'TLGARELQTAVR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'ELQTAVR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'RGKKQR';
His.mod_type{no,1} = '0,pr;3,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'GKKQR';
His.mod_type{no,1} = '0,pr;2,pr;3,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'RWDLYIHR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'WDLYIHR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'TLRQVYKR';
His.mod_type{no,1} = '0,pr;7,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'QVYKR';
His.mod_type{no,1} = '0,pr;4,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'EEAYAKAV';
His.mod_type{no,1} = '0,pr;6,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

no = no + 1;
His.out_filename{no,1} = 'HH2B_08u_17_142';
His.pep_seq{no,1} = 'EIQTSAR';
His.mod_type{no,1} = '0,pr;';
His.pep_ch(no,1) = 2;
His.pep_mz(no,1) = calculate_pepmz0(His,no,special);
new_seq = [His.pep_seq{no,1},His.mod_type{no,1}];
His.seq_godel(no,1) = sum((new_seq-'0'+49).*log(pre_nums(1:length(new_seq))));

%------------------------------------
function pep_mz = calculate_pepmz0(His,hno,special)
%%

Mods = special.Mods;
aamass = Getaamass(special.nhmass);
element = [12 1.0078246 14.0030732 15.9949141 31.972070];% element mass
mH2O = element(2)*2 + element(4);
pmass = 1.007276;

c_seq = His.pep_seq{hno};
idx = c_seq-'A'+1;
residuemass = aamass(idx,1)';
c_mod = His.mod_type{hno};
deltam = get_mod_mass(c_seq,c_mod,Mods);
% peptide+modification
residuemass_new = residuemass + deltam;
Mr = sum(residuemass_new)+mH2O;
c_ch = His.pep_ch(hno);
pep_mz = (Mr+c_ch*pmass)/c_ch;