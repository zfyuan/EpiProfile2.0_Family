function [nDAmodes,windows] = get_nDAmode(raw_path,raw_names,startmz)
%%

nDAmodes = zeros([length(raw_names),1]);
windows = zeros([length(raw_names),1]);

ms1_path = fullfile(raw_path,'MS1');
ms2_path = fullfile(raw_path,'MS2');
mode_file = fullfile(ms2_path,'MS2mode.mat');
if 0~=exist(mode_file,'file')% MAT file exists
    load(mode_file);%#ok
    return;
end

for i=1:length(raw_names)
    % nDAmode
    MS2_scanfile = fullfile(ms2_path,[raw_names{i},'_MS2scans.mat']);
    load( MS2_scanfile );%#ok
    premzs = unique(MS2_index(:,4));
    num_MS2 = size(MS2_index,1);
    cycle_len = length(premzs);
    cycle_num = floor(num_MS2/cycle_len);
    c1 = abs( length(find(MS2_index(:,4)==premzs(1))) - cycle_num)<=3;
    c2 = abs( length(find(MS2_index(:,4)==premzs(2))) - cycle_num)<=3;
    c3 = abs( length(find(MS2_index(:,4)==premzs(3))) - cycle_num)<=3;
    c4 = abs( length(find(MS2_index(:,4)==premzs(4))) - cycle_num)<=3;
    c5 = abs( length(find(MS2_index(:,4)==premzs(5))) - cycle_num)<=3;
    if cycle_len<270 && (c1 && c2 && c3 && c4 && c5)% (1100-300)/3=267
        c_nDAmode = 2;% DIA
    else
        c_nDAmode = 1;% DDA
        
        %+ recaliburate mz with two digitals in DDA
        load( fullfile(ms1_path,[raw_names{i},'_MS1scans.mat']) );%#ok
        load( fullfile(ms1_path,[raw_names{i},'_MS1peaks.mat']) );%#ok
        num_MS1 = size(MS1_index,1);
        index = [1;MS1_index(1:num_MS1,3)];
        
        mz_digitalno = MS2_index(:,9);
        myix = find(mz_digitalno<=2);
        for j=1:length(myix)
            cur_ms2scan = MS2_index(myix(j),3);
            cur_mz = MS2_index(myix(j),4);
            p = find(MS1_index(1:num_MS1,1)<=cur_ms2scan);
            IX = index(p(end)):index(p(end)+1)-1;
            mz = MS1_peaks(IX,1);
            inten = MS1_peaks(IX,2);
            if 1==strcmp(MS1Type,'ITMS')
                tol = 0.4;
            else
                tol = 30*cur_mz*1e-6;
            end
            pp = find(abs(mz-cur_mz)<tol);
            if 0==isempty(pp)
                [tmp,ip] = max(inten(pp));%#ok
                cur_mz = mz(pp(ip));
            end
            MS2_index(myix(j),4) = cur_mz;%#ok
        end
        save(MS2_scanfile,'MS2_index');
        %+
    end
    nDAmodes(i) = c_nDAmode;
    if 1==c_nDAmode
        continue;
    end
    
    % wind for DIA
    if startmz==0
        start = floor(min(premzs)/100)*100;
    else
        start = startmz;
    end
    new_premzs = [start;premzs];
    nlen = length(new_premzs);
    wind = repmat(start,[1,nlen]);
    for ino = 2:nlen
        wind(ino) = new_premzs(ino)+new_premzs(ino)-wind(ino-1);
    end
    windows(i,1:nlen) = wind;
end
save(mode_file,'nDAmodes','windows');