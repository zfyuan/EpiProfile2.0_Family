function get_MS(raw_path,raw_names)
%%

% ms1_path
ms1_path = fullfile(raw_path,'MS1');
if 0==exist(ms1_path,'dir') && 0==mkdir(ms1_path)
    fprintf(1,'can not create: %s\n',ms1_path);
    return;
end

% ms2_path
ms2_path = fullfile(raw_path,'MS2');
if 0==exist(ms2_path,'dir') && 0==mkdir(ms2_path)
    fprintf(1,'can not create: %s\n',ms2_path);
    return;
end

% check mat file
flags = zeros(length(raw_names),1);
for i=1:length(raw_names)
    file1 = fullfile(ms1_path,[raw_names{i},'_MS1scans.mat']);
    file2 = fullfile(ms1_path,[raw_names{i},'_MS1peaks.mat']);
    file3 = fullfile(ms2_path,[raw_names{i},'_MS2scans.mat']);
    file4 = fullfile(ms2_path,[raw_names{i},'_MS2peaks.mat']);
    if 0~=exist(file1,'file') && 0~=exist(file2,'file') && 0~=exist(file3,'file') && 0~=exist(file4,'file')
        flags(i) = 1;
    end
end

if length(find(flags==1))==length(raw_names)% all raws have mat files
    return;
end

% raw2ms1_file
raw2ms1_file = fullfile(pwd,'RawToMS1.exe');
if 0==exist(raw2ms1_file,'file')
    fprintf(1,'please first put RawToMS1.exe under the source code folder!\n');
    return;
end

% xtract_file
xtract_file = fullfile(pwd,'xtract.exe');
if 0==exist(xtract_file,'file')
    fprintf(1,'please first put xtract.exe under the source code folder!\n');
    return;
end

% convert raws which do not have mat files
fprintf(1,'convert RAW to MS1 and MS2\n');
pos = find(flags==0);
for i=1:length(pos)
    fprintf(1,'%s\n',raw_names{pos(i)});
    raw_file = fullfile(raw_path,[raw_names{pos(i)},'.raw']);
    ms1_file = fullfile(ms1_path,[raw_names{pos(i)},'.MS1']);
    ms2_file = fullfile(ms2_path,[raw_names{pos(i)},'.ms2']);
    
    % raw2ms1_file
    if 0==exist(ms1_file,'file')
        command = [['"',raw2ms1_file,'"'],' ',['"',raw_file,'"']];
        if 0~=system(command)
            fprintf(1,'can not convert: %s\n',raw_file);
            return;
        end
        movefile(fullfile(raw_path,[raw_names{pos(i)},'.MS1']),ms1_path);
    end
    
    % xtract_file
    if 0==exist(ms2_file,'file')
        command = [['"',xtract_file,'"'],' -a -i 1 -m 5 -ms2 -o ',['"',ms2_path,'"'],' ',['"',raw_file,'"']];
        [status,message] = system(command);%#ok
        if 0~=status
            fprintf(1,'can not convert: %s\n',raw_file);
            return;
        end
    end
    
    % GetMS1ScanNo
    if 0==GetMS1ScanNo(ms1_file)
        return;
    end
    
    % GetMS2ScanNo
    if 0==GetMS2ScanNo(ms2_file)
        return;
    end
    
    % delete MS1 and ms2
    delete(ms1_file);
    delete(ms2_file);
end