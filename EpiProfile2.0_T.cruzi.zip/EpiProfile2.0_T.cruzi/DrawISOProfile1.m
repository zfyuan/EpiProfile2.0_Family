function DrawISOProfile1(special)
%%

raw_path = special.raw_path;
raw_names = special.raw_names;

layout_path = fullfile(raw_path,'histone_layouts');
if 0==exist(layout_path,'dir') && 0==mkdir(layout_path)
    fprintf(1,'can not create: %s\n',layout_path);
    return;
end

for i=1:length(raw_names)
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',raw_names{i}]);
    if 0==exist(cur_outpath,'dir') && 0==mkdir(cur_outpath)
        fprintf(1,'can not create: %s\n',cur_outpath);
        return;
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',raw_names{i}],'detail');
    if 0==exist(cur_outpath,'dir') && 0==mkdir(cur_outpath)
        fprintf(1,'can not create: %s\n',cur_outpath);
        return;
    end
end

for i=1:length(raw_names)
    fprintf(1,'\n%s\n',raw_names{i});
    special.c_rno = i;
    cur_rawname = raw_names{i};
    MS1_scanfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1scans.mat']);
    MS1_peakfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1peaks.mat']);
    MS2_scanfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2scans.mat']);
    MS2_peakfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2peaks.mat']);
    load(MS1_scanfile);%#ok MS1_index
    load(MS1_peakfile);%#ok MS1_peaks
    load(MS2_scanfile);%#ok MS2_index
    load(MS2_peakfile);%#ok MS2_peaks
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail');
    if 1==special.nsource || 2==special.nsource
        % histone_normal or histone_SILAC
        % 1, H3H4
        fprintf(1,'H3');
        H3_01_1_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_02_54_66(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_03_70_80(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_04_39_51(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_05_88_98(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_06u_37_113(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        
        fprintf(1,'..H4');
        H4_01_1_15(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H4_01a_1_15(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        recal_ratio_H4_0101(cur_outpath);
        H4_02_16_21(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H4_03_76_89(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H4_04u_22_99(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        
        if '1'==special.soutput(2)
            fprintf(1,'..H2A');
            HH2A_01_1_18(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2A_01_19_30(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2A_01o1_19_30(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2A_02_41_51(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2A_03_52_62(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2A_04u_31_139(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            
            fprintf(1,'..H2B');
            HH2B_01_27_38(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2B_02_61_69(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2B_03_1_10(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2B_04_11_16(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2B_05_32_45(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2B_06_61_70(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2B_07_71_75(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2B_08u_17_142(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        end
        fprintf(1,'\n');
        
        if '1'==special.sfigure(2)% Get PSM
            GetBenchmark(cur_outpath);
        end
    elseif 3==special.nsource
        % histone_C13
        H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H4_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        HH2A_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        HH2A_03oV_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        HH2A_03oZ_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        HH2A_04m1_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        fprintf(1,'\n');
    elseif 4==special.nsource
        % histone_N15
        % 0: N14 light Mods, 1: N15 light Mods, 2: N14 heavy Mods, 3: N15 heavy Mods, 4: 0+1, 5: 0+3
        if 0==special.nsubtype || 4==special.nsubtype || 5==special.nsubtype
            H3_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3_07_73_83(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H4_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H4_02_20_23(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2A_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2A_04m3_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        else
            H3N_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3N_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3N_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3N_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H3N_07_73_83(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H4N_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            H4N_02_20_23(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2AN_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
            HH2AN_04m3_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        end
        fprintf(1,'\n');
    elseif 5==special.nsource
        % histone_13CD3
        H3_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_06_54_63(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_07_73_83(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H3_08_117_128(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        
        H4_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H4_02_20_23(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        H4_05_79_92(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,cur_outpath);
        fprintf(1,'\n');
    end
end

OutputTogether(layout_path,raw_names);

if 1==special.nsource || 2==special.nsource
    %OutputSinglePTMs(layout_path,raw_names,special.nSTD);
    
    if '1'==special.sfigure(3) && length(raw_names)>2
        OutputStatistics(layout_path,raw_names,special.nformat);
    end
end