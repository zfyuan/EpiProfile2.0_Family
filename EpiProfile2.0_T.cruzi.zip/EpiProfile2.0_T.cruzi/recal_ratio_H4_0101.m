function recal_ratio_H4_0101(cur_outpath)
%%

% H3_02
out_filename = 'H4_01_1_15';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s1 = sum(auc(:,2));%#ok

out_filename = 'H4_01a_1_15';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s2 = sum(auc(:,2));

s = s1+s2;

out_filename = 'H4_01_1_15';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;
save(mat_file,'His','auc');

out_filename = 'H4_01a_1_15';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;%#ok
save(mat_file,'His','auc');