function [bOK,ptols] = get_ptols(raw_path,raw_names)
%%

def_ptol1 = 50;% FT1
def_ptol2 = 1000;% IT
def_ptol3 = 10;% FT2, if no 445.12, set as 10 ppm

bOK = 1;
ptols = repmat(def_ptol1,[1,length(raw_names)]);

% ptols
ms1_path = fullfile(raw_path,'MS1');
ptol_file = fullfile(ms1_path,'MS1tol.mat');
if 0~=exist(ptol_file,'file')% MAT file exists
    load(ptol_file);%#ok
    fprintf(1,'MS1 tolerance (ppm): ');
    for i=1:length(raw_names)
        fprintf(1,'#%d, %d; ',i,ptols(i));
    end
    fprintf(1,'\n');
    return;
end

for i=1:length(raw_names)
    load( fullfile(ms1_path,[raw_names{i},'_MS1scans.mat']) );%#ok
    if 1==strcmp(MS1Type,'ITMS')
        ptols(i) = def_ptol2;
    end
end

if length(find(ptols==def_ptol1))<length(raw_names) && length(find(ptols==def_ptol2))<length(raw_names)% mix of IT and FT
    bOK = 0;
    fprintf(1,'mixture of FT and IT, please separate them first!\n');
    return;
end
if def_ptol2==ptols(1)% IT
    return;
end

% ptols for FT
unitdiff = 1.0032;
t_mz = 445.12;
t_ch = 1;
for i=1:length(raw_names)
    load( fullfile(ms1_path,[raw_names{i},'_MS1scans.mat']) );%#ok
    load( fullfile(ms1_path,[raw_names{i},'_MS1peaks.mat']) );%#ok
    num_MS1 = size(MS1_index,1);
    index = [1;MS1_index(1:num_MS1,3)];
    
    % c_isomzs
    c_ref_isomzs = [t_mz-unitdiff/t_ch t_mz t_mz+unitdiff/t_ch];
    nmz = length(c_ref_isomzs);
    c_isomzs = zeros([num_MS1,nmz]);
    for ino = 1:num_MS1
        IX = index(ino):index(ino+1)-1;
        mz = MS1_peaks(IX,1);
        inten = MS1_peaks(IX,2);
        
        tmp_mzs = zeros([1,nmz]);
        for jno=1:nmz
            c_mz = c_ref_isomzs(jno);
            c_ptol = min([def_ptol1*c_mz*1e-6,0.3]);
            left = c_mz - c_ptol;
            right = c_mz + c_ptol;
            pos = find( mz>=left & mz<=right );
            if 0==isempty(pos)
                [tmp,x] = max(inten(pos));%#ok
                tmp_mzs(jno) = mz(pos(x));
            end
        end
        if 0==tmp_mzs(1) && length(find(tmp_mzs(2:end)>0))==nmz-1
            c_isomzs(ino,1:nmz) = tmp_mzs;
        end
    end
    
    % ptols
    c_monomzs = c_isomzs(1:num_MS1,2);
    ix = find(c_monomzs>0);
    if 1==isempty(ix)
        ptols(i) = def_ptol3;
        continue;
    end
    f_monomzs = c_monomzs(ix);
    c_ptols = repmat(def_ptol3,[1,length(f_monomzs)]);
    for ino=1:length(f_monomzs)
        c_ptols(ino) = (f_monomzs(ino)-t_mz)/t_mz*1e6;
    end
    x = find(c_ptols>mean(c_ptols)-10 & c_ptols<mean(c_ptols)+10);% filter outlier
    c_ptols = c_ptols(x);%#ok
    p_mean = mean(c_ptols);
    p_std = std(c_ptols);
    ptols(i) = ceil(p_mean+10*p_std);
end
save(ptol_file,'ptols');

fprintf(1,'MS1 tolerance (ppm): ');
for i=1:length(raw_names)
    fprintf(1,'#%d, %d; ',i,ptols(i));
end
fprintf(1,'\n');