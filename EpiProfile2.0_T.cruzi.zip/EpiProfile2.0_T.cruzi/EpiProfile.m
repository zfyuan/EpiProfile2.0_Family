function EpiProfile(para_txtfile)

clc;

t1 = clock;

%% paras
% read paras
if 0==nargin || 1==isempty(para_txtfile) || 0==exist(para_txtfile,'file')
    para_txtfile = 'paras.txt';
end
[bOK,raw_path,norganism,nsource,nsubtype] = ReadInput(para_txtfile);
if 0==bOK
    return;
end
[soutput,sfigure,nformat,ndebug,nSTD,startmz,raw_names] = check_otherparas(raw_path);

% check the data source
data_source = {'histone_normal','histone_SILAC','histone_C13','histone_N15','histone_13CD3'};
if ~(nsource>=1 && nsource<=length(data_source))
    fprintf(1,'please input the correct data source in [1..%d]\n',length(data_source));
    for i=1:length(data_source)
        fprintf(1,'%d: %s\n',i,data_source{i});
    end
    return;
end

%% raws
% raw names
if 1==isempty(raw_names)
    return;
end

% get MS
get_MS(raw_path,raw_names);

% get ptol
[bOK,ptols] = get_ptols(raw_path,raw_names);
if 0==bOK
    return;
end

% get nDAmode
[nDAmodes,windows] = get_nDAmode(raw_path,raw_names,startmz);

layout_path = fullfile(raw_path,'histone_layouts');
if 0==exist(layout_path,'dir') && 0==mkdir(layout_path)
    fprintf(1,'can not create: %s\n',layout_path);
    return;
end
diary(fullfile(layout_path,'histone_logs.txt'));

%% profiles
% get profiles
special.raw_path = raw_path;
special.norganism = norganism;
special.nsource = nsource;
special.nsubtype = nsubtype;
special.soutput = soutput;
special.sfigure = sfigure;
special.nformat = nformat;
special.ndebug = ndebug;
special.nSTD = nSTD;
special.raw_names = raw_names;
special.ptols = ptols;
special.nDAmodes = nDAmodes;
special.windows = windows;
special.unitdiff = 1.0032;
special.pre_nums = primes(100000);
special.Mods = GetMods();
special.IPV = GetIPV();
if 4==nsource && (0~=nsubtype && 2~=nsubtype)
    special.nhmass = 1;
else
    special.nhmass = 0;
end

% histone_ref
DrawISOProfile0(special);
% histone_normal
DrawISOProfile1(special);
if 2==nsource
    % histone_SILAC
    fprintf(1,'\nhistone with SILAC\n');
    DrawISOProfile2(special);
elseif 3==nsource
    % histone_C13
    fprintf(1,'\nhistone with C13\n');
    DrawISOProfile3(special);
elseif 4==nsource && (4==nsubtype || 5==nsubtype)
    % histone_N15
    fprintf(1,'\nhistone with N15\n');
    DrawISOProfile4(special);
elseif 5==nsource
    % histone_13CD3
    fprintf(1,'\nhistone with 13CD3\n');
    DrawISOProfile5(special);
end

t2 = clock;
fprintf(['\nelapsed time: ' num2str(etime(t2,t1)) 'sec(' num2str(etime(t2,t1)/60) 'min)\n']);

diary off;