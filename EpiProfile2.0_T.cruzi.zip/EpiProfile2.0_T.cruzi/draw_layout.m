function draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special)
%%

cur_outpath = special.outpath;
out_filename = special.outfile;

npep = size(His.pep_mz,1);
ix = find(pep_rts(1:npep,1)>3 & His.display==1);
if 1==isempty(ix)
    return;
end

% localmax_rt, localmax_inten, terminus
nplot = length(ix);
localmax_rt = zeros([nplot,1]);
localmax_inten = zeros([nplot,1]);
terminus = zeros([nplot,2]);
for ino=1:nplot
    cno = ix(ino);
    p = find(isorts<=pep_rts(cno,1));
    c_ms1pos = p(end);
    c_mono_isointens = mono_isointens(:,cno);
    localmax_rt(ino) = pep_rts(cno,1);
    if pep_intens(cno,1)>0 && sum(c_mono_isointens)>0
        [nt,nb,top1_idx] = GetTopBottom11(c_mono_isointens);
        terminus(ino,1:2) = [nb(1) nb(end)];
        localmax_inten(ino) = c_mono_isointens(nt(top1_idx));
    else
        terminus(ino,1:2) = [c_ms1pos c_ms1pos];
    end
end

maxinten = max(localmax_inten);%#ok
st = max([isorts(min(terminus(1:nplot,1)))-1 1]);
tm = isorts(max(terminus(1:nplot,2)))+8;

out_file1 = fullfile(fileparts(cur_outpath),out_filename);

if 1==special.nformat
    sformat = '-dpdf';
elseif 2==special.nformat
    sformat = '-dpng';
else
    sformat = '-dtiff';
end

warning off all;
set(gcf,'visible','off');
% set(gcf,'position',[0 0 1000 1000]);
if 1==strcmp(out_filename(1:2),'HH')
    out_filename = out_filename(2:end);
end
p = strfind(out_filename,'_');
cur_title = [out_filename(1:p(1)-1),' ',out_filename(p(2)+1:p(3)-1),'-',out_filename(p(3)+1:end),' ',His.pep_seq,repmat(' ',1,90)];

for ino=1:nplot
    cno = ix(ino);
    
    subplot(nplot,1,ino);
    plot(isorts,mono_isointens(:,cno),'color','b','linewidth',1);
    set(gca,'xtick',[],'ytick',[]);
    hold on;
    xlim([st tm]);
    if localmax_inten(ino)>0
        ylim([0 1.05*localmax_inten(ino)]);
    end
    
    % localmax
    cur_txt = [His.mod_short{cno},',+',num2str(His.pep_ch(cno,1)),', ',num2str(localmax_rt(ino),'%.1f'),', ',num2str(localmax_inten(ino),'%.1e')];
    text(localmax_rt(ino),1.25*localmax_inten(ino),cur_txt,'color','r','fontsize',9);
    
    % boundary
    plot([isorts(terminus(ino,1)) isorts(terminus(ino,2))],[0 0],'color','m','linewidth',1);
    if 1==ino
        title(cur_title);
    end
end
set(gca,'xtickMode', 'auto');
xlabel('Time (min)','FontWeight','bold');
ylabel('Abundance','FontWeight','bold');
print(sformat,out_file1);
close();