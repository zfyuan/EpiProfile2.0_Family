function [nDAmodes,windows] = get_nDAmode(raw_path,raw_names,startmz)
%%

nDAmodes = zeros([length(raw_names),1]);
windows = zeros([length(raw_names),1]);

ms1_path = fullfile(raw_path,'MS1');
ms2_path = fullfile(raw_path,'MS2');
mode_file = fullfile(ms2_path,'MS2mode.mat');
if 0~=exist(mode_file,'file')% MAT file exists
    load(mode_file);%#ok
    return;
end

for i=1:length(raw_names)
    % nDAmode
    MS2_scanfile = fullfile(ms2_path,[raw_names{i},'_MS2scans.mat']);
    load( MS2_scanfile );%#ok
    [premzs,pre_num,st_no] = get_mass_bin(MS2_index(:,4));%#ok
    cycle_len = length(premzs);
    cycle_num = floor(pre_num/cycle_len);
    c1 = abs( length(find(MS2_index(:,4)==premzs(1))) - cycle_num)<=3;
    c2 = abs( length(find(MS2_index(:,4)==premzs(2))) - cycle_num)<=3;
    c3 = abs( length(find(MS2_index(:,4)==premzs(3))) - cycle_num)<=3;
    c4 = abs( length(find(MS2_index(:,4)==premzs(4))) - cycle_num)<=3;
    c5 = abs( length(find(MS2_index(:,4)==premzs(5))) - cycle_num)<=3;
    if cycle_len<270 && (c1 && c2 && c3 && c4 && c5)% (1100-300)/3=267
        c_nDAmode = 2;% DIA
    else
        c_nDAmode = 1;% DDA
        
        %+ recaliburate mz with two digitals in DDA if target
        check_target(ms1_path,raw_names{i},MS2_index,MS2_scanfile);
        %+
    end
    nDAmodes(i) = c_nDAmode;
    if 1==c_nDAmode
        continue;
    end
    
    % wind for DIA
    if startmz==0
        start = floor(min(premzs)/100)*100;
    else
        start = startmz;
    end
    premzs1 = MS2_index(st_no:st_no+cycle_len-1,4);
    premzs0 = premzs1(2:end) - premzs1(1:end-1);
    cur_ix = find(premzs0<0);
    if 1==isempty(cur_ix)
        new_premzs = [start;premzs1];
        nlen = length(new_premzs);
        wind = repmat(start,[1,nlen]);
        for ino = 2:nlen
            wind(ino) = new_premzs(ino)+new_premzs(ino)-wind(ino-1);
        end
        windows(i,1:nlen) = wind;
    else
        cur_ix = [0 cur_ix cycle_len];%#ok
        cno = 0;
        for kno=1:length(cur_ix)-1
            premzs2 = premzs1( cur_ix(kno)+1:cur_ix(kno+1) );
            new_premzs = [start;premzs2];
            nlen = length(new_premzs);
            wind = repmat(start,[1,nlen]);
            for ino = 2:nlen
                wind(ino) = new_premzs(ino)+new_premzs(ino)-wind(ino-1);
            end
            windows(i,cno+1:cno+nlen) = wind;
            cno = cno+nlen;
        end
    end
end
save(mode_file,'nDAmodes','windows');

function check_target(ms1_path,cur_raw_name,MS2_index,MS2_scanfile)
%%

load( fullfile(ms1_path,[cur_raw_name,'_MS1scans.mat']) );%#ok
load( fullfile(ms1_path,[cur_raw_name,'_MS1peaks.mat']) );%#ok
num_MS1 = size(MS1_index,1);
index = [1;MS1_index(1:num_MS1,3)];

mz_digitalno = MS2_index(:,9);
myix = find(mz_digitalno<=2);

% check target
ntarget = 0;
target_mzs = MS2_index(myix,4);
nlim = 200;
if length(target_mzs)>nlim
    delta_mz = max(target_mzs)-min(target_mzs);
    if delta_mz<2
        ntarget = 1;
    else
        t = min(target_mzs):2:max(target_mzs);
        [n,xout] = hist(target_mzs,t);%#ok
        if max(n)>nlim% target
            ntarget = 1;
        end
    end
end
if 0==ntarget
    return;
end

% yes, target
for j=1:length(myix)
    cur_ms2scan = MS2_index(myix(j),3);
    cur_mz = MS2_index(myix(j),4);
    p = find(MS1_index(1:num_MS1,1)<=cur_ms2scan);
    IX = index(p(end)):index(p(end)+1)-1;
    mz = MS1_peaks(IX,1);
    inten = MS1_peaks(IX,2);
    if 1==strcmp(MS1Type,'ITMS')
        tol = 0.4;
    else
        tol = 30*cur_mz*1e-6;
    end
    pp = find(abs(mz-cur_mz)<tol);
    if 0==isempty(pp)
        [tmp,ip] = max(inten(pp));%#ok
        cur_mz = mz(pp(ip));
    end
    MS2_index(myix(j),4) = cur_mz;
end
save(MS2_scanfile,'MS2_index');