function H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special)
%%

% check
out_filename = 'H3_04_27_40';
special.outfile = out_filename;
special = check_rt(special,2);
out_file0 = fullfile(special.outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end

% init
His = init_histone(special);

% calculate
[pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);

% output
output_histone(His,pep_rts,pep_intens,special);

% draw layout
isorts = MS1_index(1:size(MS1_index,1),2);
if '1'==special.sfigure(1)
    draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special);
end

% Get PSM
if '1'==special.sfigure(2)
    draw_PSM(His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special);
end

function His = init_histone(special)
%%

His.pep_seq = 'KSAPSTGGVKKPHR';
His.mod_short = {'unmod';
    'K36me1';
    'K27me1';
    'K27me2';
    'K36me2';
    'K27me3';
    'K36me3';
    'K27me2K36me1';
    'K27me1K36me2';
    'K27me1K36me1';
    'K27me3K36me1';
    'K27me1K36me3';
    'K27me2K36me2';
    'K27me3K36me2';
    'K27me2K36me3';
    'K27me3K36me3';
    'K27ac'};
His.mod_type = get_mod_type(special);

His.pep_ch = repmat([2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.rt_ref = [26.08
    27.81
    27.94
    21.40
    22.68
    21.40
    22.66
    22.64
    24.44
    29.15
    22.64
    24.44
    18.29
    18.20
    18.34
    18.20
    24.99];
if 1==special.rt_reset
    His.rt_ref(1:14) = special.rt_ref(1:14);
    His.rt_ref(15:16) = special.rt_ref(14);
    His.rt_ref(17) = special.rt_ref(15);
end
His.display = ones(length(His.mod_type),1);
His.display([15 16]) = 0;

% main ch
main_ch = His.pep_ch(1,2);
if main_ch~=His.pep_ch(1,1)
    [npep,ncharge] = size(His.pep_mz);%#ok
    new_ch = [main_ch,setdiff(His.pep_ch(1,:),main_ch)];
    x = zeros([1,ncharge]);
    for ino=1:ncharge
        x(ino) = find(His.pep_ch(1,:)==new_ch(ino));
    end
    tune = [4 5 6 7 8 9 11 12 13 14 15 16];%1:npep;
    His.pep_mz(tune,:) = His.pep_mz(tune,x);
    His.pep_ch(tune,:) = His.pep_ch(tune,x);
end

function mod_type = get_mod_type(special)
%%

if 1==special.nlight
    mod_type = {'0,pr;1,pr;10,pr;11,pr;';
        '0,pr;1,pr;10,me1;11,pr;';
        '0,pr;1,me1;10,pr;11,pr;';
        '0,pr;1,me2;10,pr;11,pr;';
        '0,pr;1,pr;10,me2;11,pr;';
        '0,pr;1,me3;10,pr;11,pr;';
        '0,pr;1,pr;10,me3;11,pr;';
        '0,pr;1,me2;10,me1;11,pr;';
        '0,pr;1,me1;10,me2;11,pr;';
        '0,pr;1,me1;10,me1;11,pr;';
        '0,pr;1,me3;10,me1;11,pr;';
        '0,pr;1,me1;10,me3;11,pr;';
        '0,pr;1,me2;10,me2;11,pr;';
        '0,pr;1,me3;10,me2;11,pr;';
        '0,pr;1,me2;10,me3;11,pr;';
        '0,pr;1,me3;10,me3;11,pr;';
        '0,pr;1,ac;10,pr;11,pr;'};
else
    if (1==special.nsource && 1==special.nsubtype) || (2==special.nsource && 0==special.nsubtype)
        mod_type = {'0,pr;1,pr;10,pr;11,pr;14,lar;';
            '0,pr;1,pr;10,me1;11,pr;14,lar;';
            '0,pr;1,me1;10,pr;11,pr;14,lar;';
            '0,pr;1,me2;10,pr;11,pr;14,lar;';
            '0,pr;1,pr;10,me2;11,pr;14,lar;';
            '0,pr;1,me3;10,pr;11,pr;14,lar;';
            '0,pr;1,pr;10,me3;11,pr;14,lar;';
            '0,pr;1,me2;10,me1;11,pr;14,lar;';
            '0,pr;1,me1;10,me2;11,pr;14,lar;';
            '0,pr;1,me1;10,me1;11,pr;14,lar;';
            '0,pr;1,me3;10,me1;11,pr;14,lar;';
            '0,pr;1,me1;10,me3;11,pr;14,lar;';
            '0,pr;1,me2;10,me2;11,pr;14,lar;';
            '0,pr;1,me3;10,me2;11,pr;14,lar;';
            '0,pr;1,me2;10,me3;11,pr;14,lar;';
            '0,pr;1,me3;10,me3;11,pr;14,lar;';
            '0,pr;1,ac;10,pr;11,pr;14,lar;'};
    elseif (1==special.nsource && 2==special.nsubtype) || (2==special.nsource && 1==special.nsubtype)
        mod_type = {'0,pr;1,prlak;10,prlak;11,prlak;14,lar;';
            '0,pr;1,prlak;10,me1lak;11,prlak;14,lar;';
            '0,pr;1,me1lak;10,prlak;11,prlak;14,lar;';
            '0,pr;1,me2lak;10,prlak;11,prlak;14,lar;';
            '0,pr;1,prlak;10,me2lak;11,prlak;14,lar;';
            '0,pr;1,me3lak;10,prlak;11,prlak;14,lar;';
            '0,pr;1,prlak;10,me3lak;11,prlak;14,lar;';
            '0,pr;1,me2lak;10,me1lak;11,prlak;14,lar;';
            '0,pr;1,me1lak;10,me2lak;11,prlak;14,lar;';
            '0,pr;1,me1lak;10,me1lak;11,prlak;14,lar;';
            '0,pr;1,me3lak;10,me1lak;11,prlak;14,lar;';
            '0,pr;1,me1lak;10,me3lak;11,prlak;14,lar;';
            '0,pr;1,me2lak;10,me2lak;11,prlak;14,lar;';
            '0,pr;1,me3lak;10,me2lak;11,prlak;14,lar;';
            '0,pr;1,me2lak;10,me3lak;11,prlak;14,lar;';
            '0,pr;1,me3lak;10,me3lak;11,prlak;14,lar;';
            '0,pr;1,aclak;10,prlak;11,prlak;14,lar;'};
    elseif 3==special.nsource
        mod_type = {'0,pr;1,pr;10,pr;11,pr;';
        '0,pr;1,pr;10,me11;11,pr;';
        '0,pr;1,me11;10,pr;11,pr;';
        '0,pr;1,me21;10,pr;11,pr;';
        '0,pr;1,pr;10,me21;11,pr;';
        '0,pr;1,me31;10,pr;11,pr;';
        '0,pr;1,pr;10,me31;11,pr;';
        '0,pr;1,me21;10,me11;11,pr;';
        '0,pr;1,me11;10,me21;11,pr;';
        '0,pr;1,me11;10,me11;11,pr;';
        '0,pr;1,me31;10,me11;11,pr;';
        '0,pr;1,me11;10,me31;11,pr;';
        '0,pr;1,me21;10,me21;11,pr;';
        '0,pr;1,me31;10,me21;11,pr;';
        '0,pr;1,me21;10,me31;11,pr;';
        '0,pr;1,me31;10,me31;11,pr;';
        '0,pr;1,ac;10,pr;11,pr;'};
    elseif 4==special.nsource
        mod_type = {'0,pr;1,pr;10,pr;11,pr;';
            '0,pr;1,pr;10,hme1;11,pr;';
            '0,pr;1,hme1;10,pr;11,pr;';
            '0,pr;1,hme2;10,pr;11,pr;';
            '0,pr;1,pr;10,hme2;11,pr;';
            '0,pr;1,hme3;10,pr;11,pr;';
            '0,pr;1,pr;10,hme3;11,pr;';
            '0,pr;1,hme2;10,hme1;11,pr;';
            '0,pr;1,hme1;10,hme2;11,pr;';
            '0,pr;1,hme1;10,hme1;11,pr;';
            '0,pr;1,hme3;10,hme1;11,pr;';
            '0,pr;1,hme1;10,hme3;11,pr;';
            '0,pr;1,hme2;10,hme2;11,pr;';
            '0,pr;1,hme3;10,hme2;11,pr;';
            '0,pr;1,hme2;10,hme3;11,pr;';
            '0,pr;1,hme3;10,hme3;11,pr;';
            '0,pr;1,hac;10,pr;11,pr;'};
    end
end

function [pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

[npep,ncharge] = size(His.pep_mz);
num_MS1 = size(MS1_index,1);
pep_rts = zeros([npep,ncharge]);
pep_intens = zeros([npep,ncharge]);
mono_isointens = zeros([num_MS1,npep]);

raw_path = special.raw_path;
pre_nums = special.pre_nums;
ndebug = special.ndebug;

% unmod
hno = 1;
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,1);
else
    [t1,t2] = check_ref(raw_path,[His.pep_seq,His.mod_type{1}],pre_nums,ndebug,MS1_index(num_MS1,2));
    top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,1,t1,t2);
    if 0==isempty(top1_rt)
        His.rt_ref(1) = top1_rt;
    else
        return;
    end
end
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);

% calibrate the rt_ref
if cur_rts(1)>0
    His.rt_ref(1) = cur_rts(1);
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,2);
else
    His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);
end

% K36me1/K27me1
if His.rt_ref(3)-His.rt_ref(2)>0.4
    for hno=2:3
        [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
        if cur_rts(1)>0
            pep_rts(hno,1:ncharge) = cur_rts;
            pep_intens(hno,1:ncharge) = cur_intens;
            mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
        end
    end
else
    hno = 2;
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno);
    if cur_rts(1,1)>0
        pep_rts(hno:hno+1,1:ncharge) = cur_rts(1:2,:);
        pep_intens(hno:hno+1,1:ncharge) = cur_intens(1:2,:);
        mono_isointens(1:num_MS1,hno:hno+1) = cur_mono_isointens(:,1:2);
    end
end

% K27me2
% K36me2
% K27me3
for hno=4:6
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

% K36me3/K27me2K36me1
hno = 7;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno);
if cur_rts(1,1)>0
    pep_rts(hno:hno+1,1:ncharge) = cur_rts(1:2,:);
    pep_intens(hno:hno+1,1:ncharge) = cur_intens(1:2,:);
    mono_isointens(1:num_MS1,hno:hno+1) = cur_mono_isointens(:,1:2);
end

% K27me1K36me2
% K27me1K36me1
% K27me3K36me1
% K27me1K36me3
% K27me2K36me2
for hno=9:13
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

% K27me3K36me2/K27me2K36me3
%
hno = 14;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if cur_rts(1)>0
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end
%}
%{
hno = 14;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno);
if cur_rts(1,1)>0
    pep_rts(hno:hno+1,1:ncharge) = cur_rts(1:2,:);
    pep_intens(hno:hno+1,1:ncharge) = cur_intens(1:2,:);
    mono_isointens(1:num_MS1,hno:hno+1) = cur_mono_isointens(:,1:2);
end
%}

% K27me3K36me3
%{
hno = 16;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if cur_rts(1)>0
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end;
%}

% K27ac
hno = 17;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
if cur_rts(1)>0
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end

function His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.1;
nsplit = 1;

% K36me1
hno = 2;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(1)+special.dis_me1(special.rtlen);
[top1_rt2,top1_inten_sum2,rts2,inten_sum2] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,0,t1,t2);%#ok

old_t1 = His.rt_ref(hno);
if 1==isempty(rts2)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt2;
end

% K27me1
hno = 3;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(1)+special.dis_me1(special.rtlen);
[top1_rt3,top1_inten_sum3,rts3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,0,t1,t2);%#ok

old_t2 = His.rt_ref(hno);
if 1==isempty(rts3)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt3;
end

if 0==isempty(rts2) && 0==isempty(rts3)
    hno = 2;
    if top1_rt2==top1_rt3
        [tmp_sum,ix] = sort(inten_sum2,'descend');
        tmp_rts = rts2(ix);
        if length(tmp_sum)>=2 && tmp_sum(2)>=tmp_sum(1)/30 && abs(tmp_rts(2)-tmp_rts(1))<2
            His.rt_ref(hno) = min([tmp_rts(1),tmp_rts(2)]);
            His.rt_ref(hno+1) = max([tmp_rts(1),tmp_rts(2)]);
        else
            if 0==His.rt_ref(hno)
                His.rt_ref(hno+1) = 0;
            else
                His.rt_ref(hno+1) = old_t2 + His.rt_ref(hno) - old_t1;
            end
        end
    elseif top1_rt2>top1_rt3 && abs(top1_rt2-top1_rt3)<2
        His.rt_ref(hno) = top1_rt3;
        His.rt_ref(hno+1) = top1_rt2;
    end
end

% K27me2,K27me3,K27me3K36me1 (4,6,11)
hno = 4;
t1 = max([3,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-delta;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);%#ok

hno = 6;
t1 = max([3,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-delta;
[top1_rt6,top1_inten_sum6,rts6,inten_sum6] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);%#ok

hno = 11;
t1 = max([3,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-delta;
[top1_rt11,top1_inten_sum11,rts11,inten_sum11] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);%#ok

xt = find_triple(rts4,top1_rt4,rts6,rts11,inten_sum4,inten_sum6,inten_sum11);

% K27me2K36me2,K27me3K36me2,K27me3K36me3 (13,14,16)
hno = 13;
t1 = max([3,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
if 0==xt(1,1)
    t2 = His.rt_ref(1)-4;
else
    t2 = xt(1,1)-0.5;
end
[top1_rt13,top1_inten_sum13,rts13,inten_sum13] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

hno = 14;
t1 = max([3,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
if 0==xt(1,1)
    t2 = His.rt_ref(1)-4;
else
    t2 = xt(1,1)-0.5;
end
[top1_rt14,top1_inten_sum14,rts14,inten_sum14] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

hno = 16;
t1 = max([3,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
if 0==xt(1,1)
    t2 = His.rt_ref(1)-4;
else
    t2 = xt(1,1)-0.5;
end
[top1_rt16,top1_inten_sum16,rts16,inten_sum16] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);%#ok

if 0==isempty(inten_sum13) || 0==isempty(inten_sum14)
    rt_array = [0 0];
    in_array = [0 0];
    if 0==isempty(inten_sum13)
        rt_array(1) = top1_rt13;
        in_array(1) = top1_inten_sum13;
    end
    if 0==isempty(inten_sum14)
        rt_array(2) = top1_rt14;
        in_array(2) = top1_inten_sum14;
    end
    [tmp,ix] = max(in_array);%#ok
    xt4 = rt_array(ix);
else
    xt4 = 0;
end

% K27me2
hno = 4;
His.rt_ref(hno) = xt(1,1);

% K36me2
hno = 5;
His.rt_ref(hno) = xt(1,2);

% K27me3
hno = 6;
His.rt_ref(hno) = xt(2,1);

% K36me3
hno = 7;
His.rt_ref(hno) = xt(1,3);

% K27me2K36me1
hno = 8;
His.rt_ref(hno) = xt(2,2);

% K27me1K36me2
hno = 9;
His.rt_ref(hno) = xt(2,3);

% K27me1K36me1
hno = 10;
if 0==His.rt_ref(3)
    t1 = His.rt_ref(1)+delta;
else
    t1 = His.rt_ref(3)+delta;
end
if 0==His.rt_ref(3)
    t2 = His.rt_ref(1)+1.5*(special.dis_me1(special.rtlen)-special.delta);
else
    t2 = His.rt_ref(3)+(His.rt_ref(3)-His.rt_ref(1))+2;
end
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K27me3K36me1
hno = 11;
His.rt_ref(hno) = xt(3,2);

% K27me1K36me3
hno = 12;
His.rt_ref(hno) = xt(3,3);

% K27me2K36me2
hno = 13;
ix = find(abs(rts13-xt4)<=0.5);
if 0==isempty(ix)
    [tmp,id] = max(inten_sum13(ix));%#ok
    His.rt_ref(hno) = rts13(ix(id));
else
    His.rt_ref(hno) = 0;
end

% K27me3K36me2
hno = 14;
old_t = His.rt_ref(hno);
ix = find(abs(rts14-xt4)<=0.5);
if 0==isempty(ix)
    [tmp,id] = max(inten_sum14(ix));%#ok
    His.rt_ref(hno) = rts14(ix(id));
else
    His.rt_ref(hno) = 0;
end

% K27me2K36me3
hno = 15;
if 0==His.rt_ref(hno-1)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = His.rt_ref(hno) + His.rt_ref(hno-1) - old_t;
end

% K27me3K36me3
hno = 16;
ix = find(abs(rts16-xt4)<=0.5);
if 0==isempty(ix)
    [tmp,id] = max(inten_sum16(ix));%#ok
    His.rt_ref(hno) = rts16(ix(id));
else
    His.rt_ref(hno) = 0;
end

% K27ac
hno = 17;
if 0==xt(2,3)
    t1 = max([3,His.rt_ref(1)-special.dis_ac(special.rtlen)]);
else
    t1 = xt(2,3)+delta;
end
t2 = His.rt_ref(1)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end