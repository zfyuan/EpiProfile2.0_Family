function H3_04K27M_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,cur_outpath,special)
%%

% check
out_filename = 'H3_04K27M_27_40';
%fprintf(1,'%s..',out_filename);
out_file0 = fullfile(cur_outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end;

% init
His = init_histone(cur_outpath,out_filename);

% calculate
unitdiff = 1.0032;
Mods = GetMods();
[pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,Mods,His,special);

% output
output_histone(cur_outpath,out_filename,His,pep_intens,pep_rts);

% draw
num_MS1 = size(MS1_index,1);
isorts = MS1_index(1:num_MS1,2);
draw_layout(cur_outpath,out_filename,His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special);

% Get PSM
if 1==special.nDAmode
    GetPSM(cur_outpath,out_filename,His,pep_rts,pep_intens,isorts,mono_isointens,MS1_index,MS1_peaks,MS2_index,ptol,unitdiff);
end;

function His = init_histone(cur_outpath,out_filename)
%%

His.pep_seq = 'MSAPATGGVKKPHR';
His.mod_short = {'unmod';
    'K36me1';
    'K36me2';
    'K36me3';
    'M27ox';
    'M27oxK36me1';
    'M27oxK36me2';
    'M27oxK36me3';};
His.mod_type = {'0,pr;10,pr;11,pr;';
    '0,pr;10,me1;11,pr;';
    '0,pr;10,me2;11,pr;';
    '0,pr;10,me3;11,pr;';
    '0,pr;1,ox;10,pr;11,pr;';
    '0,pr;1,ox;10,me1;11,pr;';
    '0,pr;1,ox;10,me2;11,pr;';
    '0,pr;1,ox;10,me3;11,pr;';};

His.pep_ch = repmat([2 3 4],length(His.mod_type),1);
%{
His.pep_mz = [810.9299	540.9557	405.9686
    817.9378	545.6276	409.4725
    796.9325	531.6241	398.9699
    803.9403	536.2960	402.4738
    818.9274	546.2874	409.9673
    825.9352	550.9592	413.4713
    804.9299	536.9557	402.9686
    811.9378	541.6276	406.4725];
%}
His.pep_mz = calculate_pepmz(His);
His.rt_ref = [27.58
    29.05
    24.79
    24.79
    23.33
    24.89
    20.47
    20.47];
His.display = ones(length(His.mod_type),1);

His.outpath = cur_outpath;
His.outfile = out_filename;

% main ch
main_ch = His.pep_ch(1,2);
if main_ch~=His.pep_ch(1,1)
    [npep,ncharge] = size(His.pep_mz);
    new_ch = [main_ch,setdiff(His.pep_ch(1,:),main_ch)];
    x = zeros([1,ncharge]);
    for ino=1:ncharge
        x(ino) = find(His.pep_ch(1,:)==new_ch(ino));
    end;
    tune = 1:npep;
    His.pep_mz(tune,:) = His.pep_mz(tune,x);
    His.pep_ch(tune,:) = His.pep_ch(tune,x);
end;

function [pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,Mods,His,special)
%%

[npep,ncharge] = size(His.pep_mz);
num_MS1 = size(MS1_index,1);
pep_rts = zeros([npep,ncharge]);
pep_intens = zeros([npep,ncharge]);
mono_isointens = zeros([num_MS1,npep]);

% ++
if 0~=special.nsubtype
    ref_rts = get_04K27Mref_rt(His);
    if 1==isempty(ref_rts)
        return;
    end;
end;

% unmod
His.rt_unmod_orig = His.rt_ref(1);
if 0~=special.nsubtype
    His.rt_ref(1) = ref_rts(1);
else
    if 1~=special.ndebug
        if 2~=special.nDAmode
            [His.rt_ref(1),special.ndebug] = check_ref(special.raw_path,[His.pep_seq,His.mod_type{1}],His.rt_ref(1),special.ndebug);
        else
            nhmass = special.nhmass;
            His.rt_ref(1) = check_ref(special.raw_path,[His.pep_seq,His.mod_type{1}],His.rt_ref(1),special.ndebug);
            if His.rt_unmod_orig==His.rt_ref(1)
                t1 = 0;
                t2 = MS1_index(num_MS1,2);
            else
                delta = 5;
                t1 = His.rt_ref(1)-delta;
                t2 = His.rt_ref(1)+delta;
            end;
            hno = 1;% unmod
            [rts1,top1_rt1] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,1,t1,t2,nhmass);%#ok
            if 0==isempty(top1_rt1)
                His.rt_ref(1) = top1_rt1;
            end;
        end;
    end;
end;

hno = 1;
[cur_rts,cur_intens,cur_mono_isointens] = get_histone0(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,special);

% calibrate the rt_ref
if cur_rts(1)>0
    His.rt_ref(1) = cur_rts(1);
    delta = cur_rts(1)-His.rt_unmod_orig;
    His.rt_ref(2:end) = His.rt_ref(2:end) + delta;
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end;
if 1==special.ndebug
    His = relocateD(MS1_index,MS1_peaks,ptol,unitdiff,His);
else
    if 2~=special.nDAmode
        His = relocate(MS1_index,MS1_peaks,ptol,unitdiff,His);
    else
        nhmass = special.nhmass;
        His = relocate2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,nhmass);
    end;
    if 0~=special.nsubtype
        for i=2:4
            His.rt_ref(i) = ref_rts(i);
        end;
    end;
end;

% K36me1
% K36me2
% K36me3
% M27ox
% M27oxK36me1
% M27oxK36me2
% M27oxK36me3
for hno=2:8
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,ptol,unitdiff,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end;
end;

function His = relocate(MS1_index,MS1_peaks,ptol,unitdiff,His)
%%

delta = 0.1;
nsplit = 1;

% K36me1
hno = 2;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(1)+6;
[rts2,top1_rt2] = get_rts(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2);

if 1==isempty(rts2)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt2;
end;

% K36me2
hno = 3;
t1 = 6;
t2 = His.rt_ref(1)-1;
[rts3,top1_rt3,inten_sum3,top1_inten_sum3] = get_rts(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2);

% K36me3
hno = 4;
t1 = 6;
t2 = His.rt_ref(1)-1;
[rts4,top1_rt4,inten_sum4,top1_inten_sum4] = get_rts(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2);

[His.rt_ref(3),His.rt_ref(4)] = find_pair(rts3,top1_rt3,inten_sum3,top1_inten_sum3,rts4,top1_rt4,inten_sum4,top1_inten_sum4);

% M27ox
hno = 5;
t1 = His.rt_ref(1)-10;
t2 = His.rt_ref(1)-delta;
[rts5,top1_rt5] = get_rts(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2);

if 1==isempty(rts5)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt5;
end;

% M27oxK36me1
hno = 6;
if 0==His.rt_ref(5)
    t1 = His.rt_ref(1)-10;
    t2 = His.rt_ref(1)-delta;
else
    t1 = His.rt_ref(5)+delta;
    t2 = His.rt_ref(5)+6;
end;
[rts6,top1_rt6] = get_rts(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2);

if 1==isempty(rts6)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt6;
end;

% M27oxK36me2
hno = 7;
t1 = 6;
t2 = His.rt_ref(1)-2;
[rts7,top1_rt7,inten_sum7,top1_inten_sum7] = get_rts(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2);

% M27oxK36me3
hno = 8;
t1 = 6;
t2 = His.rt_ref(1)-2;
[rts8,top1_rt8,inten_sum8,top1_inten_sum8] = get_rts(MS1_index,MS1_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2);

[His.rt_ref(7),His.rt_ref(8)] = find_pair(rts7,top1_rt7,inten_sum7,top1_inten_sum7,rts8,top1_rt8,inten_sum8,top1_inten_sum8);

function His = relocate2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,nhmass)
%%

delta = 0.1;
nsplit = 1;

% K36me1
hno = 2;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(1)+6;
[rts2,top1_rt2] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2,nhmass);

if 1==isempty(rts2)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt2;
end;

% K36me2
hno = 3;
t1 = 6;
t2 = His.rt_ref(1)-1;
[rts3,top1_rt3,inten_sum3,top1_inten_sum3] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2,nhmass);

% K36me3
hno = 4;
t1 = 6;
t2 = His.rt_ref(1)-1;
[rts4,top1_rt4,inten_sum4,top1_inten_sum4] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2,nhmass);

[His.rt_ref(3),His.rt_ref(4)] = find_pair(rts3,top1_rt3,inten_sum3,top1_inten_sum3,rts4,top1_rt4,inten_sum4,top1_inten_sum4);

% M27ox
hno = 5;
t1 = His.rt_ref(1)-10;
t2 = His.rt_ref(1)-delta;
[rts5,top1_rt5] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2,nhmass);

if 1==isempty(rts5)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt5;
end;

% M27oxK36me1
hno = 6;
if 0==His.rt_ref(5)
    t1 = His.rt_ref(1)-10;
    t2 = His.rt_ref(1)-delta;
else
    t1 = His.rt_ref(5)+delta;
    t2 = His.rt_ref(5)+6;
end;
[rts6,top1_rt6] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2,nhmass);

if 1==isempty(rts6)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt6;
end;

% M27oxK36me2
hno = 7;
t1 = 6;
t2 = His.rt_ref(1)-2;
[rts7,top1_rt7,inten_sum7,top1_inten_sum7] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2,nhmass);

% M27oxK36me3
hno = 8;
t1 = 6;
t2 = His.rt_ref(1)-2;
[rts8,top1_rt8,inten_sum8,top1_inten_sum8] = get_rts2(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,unitdiff,His,hno,nsplit,t1,t2,nhmass);

[His.rt_ref(7),His.rt_ref(8)] = find_pair(rts7,top1_rt7,inten_sum7,top1_inten_sum7,rts8,top1_rt8,inten_sum8,top1_inten_sum8);

function ref_rts = get_04K27Mref_rt(His)
%%

out_file0 = fullfile(His.outpath,'H3_04K27Mref_27_40.xls');
if 0~=exist(out_file0,'file')
    fp = fopen(out_file0,'r');
    str = fgetl(fp);
    while 0==feof(fp) && 0==strcmp(str,'[rt]')
        str = fgetl(fp);
    end;
    str = fgetl(fp);%#ok peptide
    no = 0;
    ref_rts = [];
    while 0==feof(fp)
        str = fgetl(fp);
        p = strfind(str,'	');
        c_rt = str2num( str(p(1)+1:p(2)-1) );%#ok
        no = no + 1;
        ref_rts(no) = c_rt;%#ok
    end;
    fclose(fp);
else
    ref_rts = [];
end;