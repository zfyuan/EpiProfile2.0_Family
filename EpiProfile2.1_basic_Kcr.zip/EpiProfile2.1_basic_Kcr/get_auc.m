function area = get_auc(n_rt,n_inten,fCali)
%%

x = find(n_inten>0);
if 1==isempty(x)
    area = 0;
    return;
end
n1_rt = n_rt(x);
n1_inten = n_inten(x);
d = n1_rt(end)-n1_rt(1);
if d>0.005
    n1_inten = smooth(n1_inten,3);
    xx = n1_rt(1):0.005:n1_rt(end);
    yy = spline(n1_rt,n1_inten,xx);
    area = sum(abs(yy))*fCali;
else
    area = sum(n1_inten)*fCali;
end