function [bOK,raw_path,norganism,nsource,nsubtype] = ReadInput(para_txtfile)
%%

bOK = 0;
raw_path = '';% the datapath of raw files
norganism = 1;% 1: Human, 2: Mouse
nsource = 1;% 1: histone_LFQ, 2: histone_SILAC, 3: histone_13CD3, 4: histone_15N, 5: histone_13C2, 6: histone_D3
% if histone_LFQ,   0: light only, 1: heavy R_no light, 2: heavy K and heavy R_no light
% if histone_SILAC, 0: heavy R, 1: heavy K and heavy R
% if histone_15N,   0: 14N light Mods, 1: 15N light Mods, 2: 14N heavy Mods, 3: 15N heavy Mods, 4: 0+1, 5: 0+3
nsubtype = 0;

% check
if 0==exist( para_txtfile,'file' )
    disp(['the para file does not exist: ',para_txtfile]);
    return;
end

% open
fp = fopen( para_txtfile,'r' );
if -1==fp
    disp(['can not open: ',para_txtfile]);
    return;
end

% read
while 0==feof(fp)
    str = fgetl(fp);
    % raw_path
    pos = strfind(str,'raw_path');
    while 0==feof(fp) && (1==isempty(pos) || 1~=pos(1))
        str = fgetl(fp);
        pos = strfind(str,'raw_path');
    end
    if 1==feof(fp)
        break;
    end
    pos = strfind(str,'=');
    raw_path = str(pos+1:end);

    % norganism
    pos = strfind(str,'norganism');
    while 0==feof(fp) && 1==isempty(pos)
        str = fgetl(fp);
        pos = strfind(str,'norganism');
    end
    if 1==isempty(pos)
        break;
    end
    pos = strfind(str,'=');
    norganism = str2double( str(pos+1:end) );

    % nsource
    pos = strfind(str,'nsource');
    while 0==feof(fp) && 1==isempty(pos)
        str = fgetl(fp);
        pos = strfind(str,'nsource');
    end
    if 1==isempty(pos)
        break;
    end
    pos = strfind(str,'=');
    nsource = str2double( str(pos+1:end) );

    % nsubtype
    pos = strfind(str,'nsubtype');
    while 0==feof(fp) && 1==isempty(pos)
        str = fgetl(fp);
        pos = strfind(str,'nsubtype');
    end
    if 1==isempty(pos)
        break;
    end
    pos = strfind(str,'=');
    nsubtype = str2double( str(pos+1:end) );
end
fclose(fp);

bOK = 1;