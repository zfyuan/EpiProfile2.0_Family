function [premzs,pre_num,st_no] = get_mass_bin(MS2_mzs)
%%

premzs = unique(MS2_mzs);
pre_num = length(MS2_mzs);
st_no = 1;

cycle_len = length(premzs);
if cycle_len>=270
    return;
end

% only use first 270 to get unique
premzs = unique(MS2_mzs(1:270));
cycle_len = length(premzs);

% cycle_len<270
prenos = zeros(cycle_len,1);
for ino=1:cycle_len
    prenos(ino) = length(find(MS2_mzs==premzs(ino)));
end
cycle_num = median(prenos);

innos = zeros(cycle_len,1);
for ino=1:cycle_len
    if abs( prenos(ino) - cycle_num )<=3
        innos(ino) = 1;
    end
end

ix = find(innos==1);
if cycle_len - length(ix)<=3
    premzs = premzs(ix);
    pre_num = sum(prenos(ix));
    for ino=1:length(MS2_mzs)
        if 1==ismember(MS2_mzs(ino),premzs)
            st_no = ino;
            break;
        end
    end
end