function DrawISOProfile1(special)
%%

raw_path = special.raw_path;
raw_names = special.raw_names;

layout_path = fullfile(raw_path,'histone_layouts');
if 0==exist(layout_path,'dir') && 0==mkdir(layout_path)
    fprintf(1,'can not create: %s\n',layout_path);
    return;
end

for i=1:length(raw_names)
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',raw_names{i}]);
    if 0==exist(cur_outpath,'dir') && 0==mkdir(cur_outpath)
        fprintf(1,'can not create: %s\n',cur_outpath);
        return;
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',raw_names{i}],'detail');
    if 0==exist(cur_outpath,'dir') && 0==mkdir(cur_outpath)
        fprintf(1,'can not create: %s\n',cur_outpath);
        return;
    end
end

special = check_rt(special,1);
special.delta = 2;
special.dis_me1 = [7 7*2 7*3]+special.delta;
special.dis_me2 = [24 24*2 24*3]+special.delta;
special.dis_ac = [4 4*2 4*3]+special.delta;
special.dis_ph = [9 9*2 9*3]+special.delta;
special.dis_sor = [9 9*2 9*3]+special.delta;
special.dis_cr = [7 7*2 7*3]+special.delta;
special.nlight = 1;

for i=1:length(raw_names)
    fprintf(1,'\n%s\n',raw_names{i});
    cur_rawname = raw_names{i};
    MS1_scanfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1scans.mat']);
    MS1_peakfile = fullfile(raw_path,'MS1',[cur_rawname,'_MS1peaks.mat']);
    MS2_scanfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2scans.mat']);
    MS2_peakfile = fullfile(raw_path,'MS2',[cur_rawname,'_MS2peaks.mat']);
    load(MS1_scanfile);%#ok MS1_index
    load(MS1_peakfile);%#ok MS1_peaks
    load(MS2_scanfile);%#ok MS2_index
    load(MS2_peakfile);%#ok MS2_peaks
    if i<10
        prefix = ['0',num2str(i)];
    else
        prefix = num2str(i);
    end
    cur_outpath = fullfile(layout_path,[prefix,'_',cur_rawname],'detail');
    special.outpath = cur_outpath;
    special.c_rno = i;
    if MS1_index(size(MS1_index,1),2)<90
        special.rtlen = 1;
    elseif MS1_index(size(MS1_index,1),2)<180
        special.rtlen = 2;
    else
        special.rtlen = 3;
    end
    special.nlight = judge_light_heavy(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
    if 1==special.nsource || 2==special.nsource
        % histone_normal or histone_SILAC
        % 1, H3H4
        fprintf(1,'H3');
        H3_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_05_41_49(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);%norm
        H3_06_54_63(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_07_73_83(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_08_117_128(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_09u_64_135(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        if '1'~=special.soutput(1)
            % 2, H3H4+H3S10ph+H3S28ph
            H3_02a_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            recal_ratio_H3_0201(cur_outpath);
            H3_04a_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            H3_04v3a_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            recal_ratio_H3_0402(cur_outpath);
        end
        
        fprintf(1,'..H4');
        H4_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_02_20_23(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_03_24_35(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);%norm
        H4_04_40_45(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_05_79_92(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_06u_46_102(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        
        HH2A_06_82_88(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);%norm
        
        if '1'==special.soutput(2)
            fprintf(1,'..H1');
            if 1==special.norganism
                % Human
                HH1_01v_1_35(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
                HH1_02v_54_81(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            else
                % Mouse
                HH1Mo_01v_1_35(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
                HH1Mo_02v_54_81(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            end
            
            fprintf(1,'..H2A');
            HH2A_01m1_36_42(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_01m3_36_42(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_01oX_36_42(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_02oJ_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_02oX_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_03m1_1_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_03oV_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_03oZ_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_04m1_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_04m3_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            HH2A_05m1_72_77(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            if 1==special.norganism
                % Human
                HH2A_07v_1_88(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
                HH2A_08u_4_99(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            else
                HH2AMo_07v_1_88(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
                HH2AMo_08u_4_99(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            end
            
            fprintf(1,'..H2B');
            if 1==special.norganism
                % Human
                HH2B_01v_1_29(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
                HH2B_02u_1_100(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            else
                % Mouse
                HH2BMo_01v_1_29(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
                HH2BMo_02u_1_100(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
            end
        end
        fprintf(1,'\n');
        
        if '1'==special.sfigure(2)% Get PSM
            GetBenchmark(cur_outpath);
        end
    elseif 3==special.nsource
        % histone_13CD3
        H3_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_06_54_63(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_07_73_83(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_08_117_128(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_02_20_23(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_05_79_92(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        fprintf(1,'\n');
    elseif 4==special.nsource
        % histone_15N
        % 0: 14N light Mods, 1: 15N light Mods, 2: 14N heavy Mods, 3: 15N heavy Mods, 4: 0+1, 5: 0+3
        if 1==special.nsubtype || 3==special.nsubtype
            special.nhmass = 1;
        end
        H3_01_3_8(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_07_73_83(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_02_20_23(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_04m3_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        fprintf(1,'\n');
    elseif 5==special.nsource
        % histone_13C2
        H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_03oV_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_03oZ_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_04m1_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        fprintf(1,'\n');
    elseif 6==special.nsource
        % histone_D3
        H3_02_9_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_03_18_26(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H3_04v3_27_40(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        H4_01_4_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_02m1_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_03oV_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_03oZ_1_19(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        HH2A_04m1_12_17(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special);
        fprintf(1,'\n');
    end
end

data_source = {'','SILAC','13CD3','15N','13C2','D3'};
c_layout_path = fullfile(raw_path,'histone_layouts',data_source{special.nsource});
if 1==special.ndebug && special.nsource>1 && 0==isempty(special.pep_code)
    rt_delta = special.rt_ref1-special.rt_ref2;
    if 0==isempty( find(any(rt_delta~=0)==1) ) && 0~=exist(c_layout_path,'dir')%#ok
        rmdir(c_layout_path,'s');
    end
end

OutputTogether(layout_path,raw_names,'');
OutputTogetherRT(layout_path,raw_names,'',special.ndebug);

if 1==special.nsource || 2==special.nsource
    OutputSinglePTMs(layout_path,raw_names,'',special.nSTD);
    
    if '1'==special.sfigure(3) && length(raw_names)>2
        OutputStatistics(layout_path,raw_names,special.nformat);
    end
end