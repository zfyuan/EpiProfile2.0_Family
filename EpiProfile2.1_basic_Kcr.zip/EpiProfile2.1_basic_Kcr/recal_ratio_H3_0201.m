function recal_ratio_H3_0201(cur_outpath)
%%

% H3_02
out_filename = 'H3_02_9_17';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s1 = sum(auc(:,2));%#ok

out_filename = 'H3_02a_9_17';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
s2 = sum(auc(:,2));

s = s1+s2;

out_filename = 'H3_02_9_17';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;
save(mat_file,'His','auc');

out_filename = 'H3_02a_9_17';
mat_file = fullfile(cur_outpath,[out_filename,'.mat']);
load(mat_file);%#ok
auc(:,3) = auc(:,2)/s;%#ok
save(mat_file,'His','auc');