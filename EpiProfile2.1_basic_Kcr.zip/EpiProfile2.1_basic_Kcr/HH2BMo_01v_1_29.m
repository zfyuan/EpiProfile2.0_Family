function HH2BMo_01v_1_29(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special)
%%

% check
out_filename = 'HH2B_01v_1_29';
special.outfile = out_filename;
special = check_rt(special,2);
out_file0 = fullfile(special.outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end

% init
His = init_histone(special);

% calculate
[pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);

% output
output_histone(His,pep_rts,pep_intens,special);

% draw layout
isorts = MS1_index(1:size(MS1_index,1),2);
if '1'==special.sfigure(1)
    draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special);
end

% Get PSM
if '1'==special.sfigure(2)
    draw_PSM(His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special);
end

function His = init_histone(special)
%%

His.pep_seq = 'unmod';
His.mod_short = {'1C.PEPAKSAPAPKKGSKKAVTKAQKKDGKKR';
    '1H.PEPAKSAPAPKKGSKKALTKAQKKDGKKR';
    '2B.PDPAKSAPAPKKGSKKAVTKVQKKDGKKR';
    '1B.PEPSKSAPAPKKGSKKAISKAQKKDGKKR';
    '3B.PDPSKSAPAPKKGSKKAVTKAQKKDGKKR';
    '1M.PEPTKSAPAPKKGSKKAVTKAQKKDGKKR';
    '1P.PEPVKSVPAPKKGSKKAVTKAQKKDGKKR';
    '2E.PELAKSAPAPKKGSKKAVTKAQKKDGKKR'};
His.mod_type = get_mod_type(special);

His.pep_ch = repmat([4 3],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.rt_ref = [37.89
    38.98
    39.41
    37.35
    37.89
    37.76
    38.89
    38.28];
if 1==special.rt_reset
    His.rt_ref = special.rt_ref;
end
His.display = ones(length(His.mod_type),1);

function mod_type = get_mod_type(special)
%%

if 1==special.nlight
    mod_type = {'0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;';
        '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;';
        '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;';
        '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;';
        '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;';
        '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;';
        '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;';
        '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;'};
else
    if (1==special.nsource && 1==special.nsubtype) || (2==special.nsource && 0==special.nsubtype)
        mod_type = {'0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;';
            '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;';
            '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;';
            '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;';
            '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;';
            '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;';
            '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;';
            '0,pr;5,pr;11,pr;12,pr;15,pr;16,pr;20,pr;23,pr;24,pr;27,pr;28,pr;29,lar;'};
    elseif (1==special.nsource && 2==special.nsubtype) || (2==special.nsource && 1==special.nsubtype)
        mod_type = {'0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;';
            '0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;';
            '0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;';
            '0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;';
            '0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;';
            '0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;';
            '0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;';
            '0,pr;5,prlak;11,prlak;12,prlak;15,prlak;16,prlak;20,prlak;23,prlak;24,prlak;27,prlak;28,prlak;29,lar;'};
    end
end

function [pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

[npep,ncharge] = size(His.pep_mz);
num_MS1 = size(MS1_index,1);
pep_rts = zeros([npep,ncharge]);
pep_intens = zeros([npep,ncharge]);
mono_isointens = zeros([num_MS1,npep]);

raw_path = special.raw_path;
pre_nums = special.pre_nums;
ndebug = special.ndebug;

% unmod
hno = 1;
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,1);
else
    p = strfind(His.mod_short{hno},'.');
    [t1,t2] = check_ref(raw_path,[His.mod_short{hno}(p+1:end),His.mod_type{hno}],pre_nums,ndebug,MS1_index(num_MS1,2));
    top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,1,t1,t2);
    if 0==isempty(top1_rt)
        His.rt_ref(hno) = top1_rt;
    else
        return;
    end
end
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);

% calibrate the rt_ref
if cur_rts(1)>0
    His.rt_ref(1) = cur_rts(1);
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,2);
else
    His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);
end

% '1H'
% '2B'
% '1B'
% '3B'
% '1M'
% '1P'
% '2E'
for hno=2:8
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

function His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.1;
nsplit = 1;

% '1H'
hno = 2;
t1 = His.rt_ref(1)-delta;
t2 = His.rt_ref(1)+5;
[top1_rt2,top1_inten_sum2,rts2,inten_sum2] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);%#ok

[tmp_sum,ix] = sort(inten_sum2,'descend');
tmp_rts = rts2(ix);
if length(tmp_sum)>=2 && tmp_sum(2)>=tmp_sum(1)/30 && abs(tmp_rts(2)-tmp_rts(1))<2
    His.rt_ref(hno) = min([tmp_rts(2),tmp_rts(1)]);
    His.rt_ref(hno+1) = max([tmp_rts(2),tmp_rts(1)]);
else
    old_t = His.rt_ref(hno);
    if 1==isempty(rts2)
        His.rt_ref(hno) = 0;
    else
        His.rt_ref(hno) = top1_rt2;
    end
    
    % '2B'
    hno = 3;
    if 0==His.rt_ref(hno-1)
        His.rt_ref(hno) = 0;
    else
        His.rt_ref(hno) = His.rt_ref(hno) + His.rt_ref(hno-1) - old_t;
    end
end

% '1B'
hno = 4;
t1 = His.rt_ref(1)-5;
t2 = His.rt_ref(1)+delta;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);%#ok
if 1==isempty(rts4)
    His.rt_ref(hno) = 0;
else
    id = find(rts4<His.rt_ref(1));
    if 0==isempty(id)
        [tmp,ix] = max(inten_sum4(id));%#ok
        His.rt_ref(hno) = rts4(id(ix));
    else
        His.rt_ref(hno) = 0;
    end
end

% '3B'
hno = 5;
t1 = His.rt_ref(1)-5;
t2 = His.rt_ref(1)+5;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% '1M'
hno = 6;
t1 = His.rt_ref(1)-5;
t2 = His.rt_ref(1)+5;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% '1P'
hno = 7;
t1 = His.rt_ref(1)-5;
t2 = His.rt_ref(1)+5;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% '2E'
hno = 8;
t1 = His.rt_ref(1)-delta;
t2 = His.rt_ref(1)+5;
[top1_rt8,top1_inten_sum8,rts8,inten_sum8] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);%#ok
if 1==isempty(rts8)
    His.rt_ref(hno) = 0;
else
    id = find(rts8>His.rt_ref(1));
    if 0==isempty(id)
        [tmp,ix] = max(inten_sum8(id));%#ok
        His.rt_ref(hno) = rts8(id(ix));
    else
        His.rt_ref(hno) = 0;
    end
end