function [ms2pos,ms2rts,ms2intens1,ms2intens2,K1,K2] = MatchMS2_6(MS2_index,MS2_peaks,special,His,hno,rt1,rt2)
%%

npart = 6;

ms2pos = [];
ms2rts = [];
ms2intens1 = [];
ms2intens2 = [];
K1 = [];
K2 = [];

ptol = special.ptols(special.c_rno);
nDAmode = special.nDAmodes(special.c_rno);
wind = special.windows(special.c_rno,:);
wind = wind(find(wind>0));%#ok
unitdiff = special.unitdiff;
Mods = special.Mods;
nhmass = special.nhmass;

% init
num_MS2 = size(MS2_index,1);
c_mz = His.pep_mz(hno,1);
c_ch = His.pep_ch(hno,1);
p = find( MS2_index(:,2)>=rt1 );
pp = find( MS2_index(:,2)<=rt2 );
if 1==isempty(p) || 1==isempty(pp)
    return;
end
i1 = p(1);
i2 = pp(end);
flag = zeros([num_MS2,1]);

% ms2pos
if 1==nDAmode
    % DDA
    if ptol<1
        c_ptol = ptol;
    else
        c_ptol = ptol*c_mz*1e-6;
    end
    sets = [0 1 2];
    mzs = c_mz + sets*unitdiff/c_ch;
    for i=i1:i2
        cen_mz = MS2_index(i,4);
        ix = find(abs(mzs-cen_mz)<c_ptol);%#ok
        if 0==isempty(ix)
            flag(i) = 1;
        end
    end
elseif 2==nDAmode
    % DIA
    % target
    [premzs,pre_num,st_no] = get_mass_bin(MS2_index(:,4));%#ok
    cycle_len = length(premzs);
    premzs1 = MS2_index(st_no:st_no+cycle_len-1,4);
    premzs0 = premzs1(2:end) - premzs1(1:end-1);
    cur_ix = find(premzs0<0);
    if 1==isempty(cur_ix)
        xx = find(wind<=c_mz);
        if 1==isempty(xx)
            ii = 1;
        else
            ii = xx(end);
            if ii==cycle_len+1
                ii = cycle_len;
            end
        end
        target = premzs1(ii);
    else
        cur_ix = [0 cur_ix cycle_len];
        cno = 0;
        target = zeros([1,length(cur_ix)-1]);
        for kno=1:length(cur_ix)-1
            premzs2 = premzs1( cur_ix(kno)+1:cur_ix(kno+1) );
            nlen = 1+length(premzs2);
            c_wind = wind(cno+1:cno+nlen);
            cno = cno+nlen;
            
            xx = find(c_wind<=c_mz);
            if 1==isempty(xx)
                ii = 1;
            else
                ii = xx(end);
                if ii==nlen
                    ii = nlen-1;
                end
            end
            target(kno) = premzs2(ii);
        end
    end
    % flag
    for i=i1:i2
        cen_mz = MS2_index(i,4);
        if 1==ismember(cen_mz,target)
            flag(i) = 1;
        end
    end
end
ms2pos = find(flag==1);
if 1==isempty(ms2pos)
    return;
end

% ms2rts
ms2rts = MS2_index(:,2);

instruments = MS2_index(ms2pos,6);% MS2dirs = {'CIDIT','CIDFT','ETDIT','ETDFT','HCDIT','HCDFT'};
% if 1==length(unique(instruments))
% ActiveType, tol
c_instrument = instruments(1);
if 3==c_instrument || 4==c_instrument
    ActiveType = 'ETD';
else
    ActiveType = 'CID';
end
if 1==mod(c_instrument,2)
    tol = 0.4;
else
    tol = 0.02;
end

% K1,K2
[K11,K12] = get_key_ions1(His,hno,hno+1,Mods,ActiveType,nhmass,1);
[K21,K22] = get_key_ions1(His,hno+1,hno+2,Mods,ActiveType,nhmass,1);
[K31,K32] = get_key_ions1(His,hno+2,hno+4,Mods,ActiveType,nhmass,1);
[K41,K42] = get_key_ions1(His,hno+4,hno+5,Mods,ActiveType,nhmass,1);
[K51,K52] = get_key_ions1(His,hno+5,hno+2,Mods,ActiveType,nhmass,0);
flen = max([size(K11,2),size(K12,2),size(K21,2),size(K22,2),size(K31,2),size(K32,2),size(K41,2),size(K42,2),size(K51,2),size(K52,2)]);
K1 = zeros(npart-1,flen);
K2 = zeros(npart-1,flen);
K1(1,1:length(K11)) = K11;
K1(2,1:length(K21)) = K21;
K1(3,1:length(K31)) = K31;
K1(4,1:length(K41)) = K41;
K1(5,1:length(K51)) = K51;
K2(1,1:length(K12)) = K12;
K2(2,1:length(K22)) = K22;
K2(3,1:length(K32)) = K32;
K2(4,1:length(K42)) = K42;
K2(5,1:length(K52)) = K52;
% end

% ms2intens
index = [1;MS2_index(1:num_MS2,7)];
ms2intens1 = zeros([num_MS2,size(K1,2),npart-1]);
ms2intens2 = zeros([num_MS2,size(K2,2),npart-1]);
for i=1:length(ms2pos)
    pno = ms2pos(i);
    if pno<1 || pno>num_MS2
        continue;
    end
    if 1<length(unique(instruments))
        % ActiveType, tol
        c_instrument = MS2_index(pno,6);% MS2dirs = {'CIDIT','CIDFT','ETDIT','ETDFT','HCDIT','HCDFT'};
        if 3==c_instrument || 4==c_instrument
            ActiveType = 'ETD';
        else
            ActiveType = 'CID';
        end
        if 1==mod(c_instrument,2)
            tol = 0.4;
        else
            tol = 0.02;
        end
        
        % K1,K2
        [K11,K12] = get_key_ions1(His,hno,hno+1,Mods,ActiveType,nhmass,1);
        [K21,K22] = get_key_ions1(His,hno+1,hno+2,Mods,ActiveType,nhmass,1);
        [K31,K32] = get_key_ions1(His,hno+2,hno+4,Mods,ActiveType,nhmass,1);
        [K41,K42] = get_key_ions1(His,hno+4,hno+5,Mods,ActiveType,nhmass,1);
        [K51,K52] = get_key_ions1(His,hno+5,hno+2,Mods,ActiveType,nhmass,0);
        flen = max([size(K11,2),size(K12,2),size(K21,2),size(K22,2),size(K31,2),size(K32,2),size(K41,2),size(K42,2),size(K51,2),size(K52,2)]);
        K1 = zeros(npart-1,flen);
        K2 = zeros(npart-1,flen);
        K1(1,1:length(K11)) = K11;
        K1(2,1:length(K21)) = K21;
        K1(3,1:length(K31)) = K31;
        K1(4,1:length(K41)) = K41;
        K1(5,1:length(K51)) = K51;
        K2(1,1:length(K12)) = K12;
        K2(2,1:length(K22)) = K22;
        K2(3,1:length(K32)) = K32;
        K2(4,1:length(K42)) = K42;
        K2(5,1:length(K52)) = K52;
    end
    
    % mz, inten
    IX = index(pno):index(pno+1)-1;
    mz = MS2_peaks(IX,1);
    inten = MS2_peaks(IX,2);
    %X = find(inten>=MS2_index(pno,8));
    %mz = mz(X);
    %inten = inten(X);
    
    % match key ions
    for k=1:npart-1
        K11 = K1(k,:);
        K11 = K11(find(K11>0));%#ok
        for j=1:length(K11)
            ix1 = find(abs(mz-K11(j))<=tol);
            %[tmp,x1] = min(abs(mz(ix1)-K1(j)));%#ok
            [tmp,x1] = max(inten(ix1));%#ok
            if 0==isempty(ix1)
                ms2intens1(pno,j,k) = inten(ix1(x1));
            end
        end
        K12 = K2(k,:);
        K12 = K12(find(K12>0));%#ok
        for j=1:length(K12)
            ix1 = find(abs(mz-K12(j))<=tol);
            %[tmp,x1] = min(abs(mz(ix1)-K1(j)));%#ok
            [tmp,x1] = max(inten(ix1));%#ok
            if 0==isempty(ix1)
                ms2intens2(pno,j,k) = inten(ix1(x1));
            end
        end
    end
end