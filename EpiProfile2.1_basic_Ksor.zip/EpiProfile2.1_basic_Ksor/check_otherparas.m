function [def_ptol,soutput,sfigure,nformat,ndebug,nSTD,nconverter,startmz,nround,raw_names] = check_otherparas(raw_path)
%%

% **default can be changed**
def_ptol = 10;% FT: 10 ppm
soutput = '11'; % 1st bit: 1, H3H4; 2, H3H4+H3S10ph+H3S28ph    2nd bit: 1, H1H2AB; 0, no H1H2AB
sfigure = '101';% 1st bit: 1, output MS1; 0, no MS1    2nd bit: 1, output MS2; 0, no MS2    3rd bit: 1, output statistics; 0, no statistics
nformat = 1;% 1: pdf, 2: png

ndebug = 0;% 0: normal and ref, 1: debug, 2: normal but no ref
nSTD = 0;% 0: no STD, 1: STD
nconverter = 1;% 1: xtract, 2: ReAdW
startmz = 0;% start mz of MS1 in DIA. If it is 0, the program can detect by itself. Or else the program will use the specific as the start mz.
nround = 2;% times of running DrawISOProfile1

% raw_path\raw_names
raws = dir(fullfile(raw_path,'*.raw'));
extend_len = length('.raw');
if 1==isempty(raws)
    raws = dir(fullfile(raw_path,'*.mzXML'));
    extend_len = length('.mzXML');
    if 1==isempty(raws)
        raw_names = {};
        fprintf(1,'no raws\n');
        return;
    end
end

raw_names = repmat({''},[length(raws),1]);
date_nums = zeros([length(raws),1]);
raw_nos = ones([length(raws),1]);
for i=1:length(raws)
    raw_names{i,1} = raws(i).name(1:end-extend_len);%
    date_nums(i,1) = floor(raws(i).datenum);% datenum('0-January-0000') = 0; return the days from 0-January-0000.
    p = strfind(raw_names{i,1},'_');
    if 0==isempty(p)
        c_num = str2num(raw_names{i,1}(p(end)+1:end));%#ok assume the numbers after the last '_' is the raw order
        if 0==isempty(c_num)
            raw_nos(i,1) = c_num;%
        end
    end
end

if 4==extend_len && max(date_nums)-min(date_nums)>7 && 0==ndebug% raw files, more than 7 days, change ndebug from 0 to 2.
    ndebug = 2;
end
[tmp,ix] = sort(raw_nos);%#ok sort by the raw order
raw_names = raw_names(ix);