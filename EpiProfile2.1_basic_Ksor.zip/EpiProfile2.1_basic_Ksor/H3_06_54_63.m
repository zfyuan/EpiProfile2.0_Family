function H3_06_54_63(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special)
%%

% check
out_filename = 'H3_06_54_63';
special.outfile = out_filename;
special = check_rt(special,2);
out_file0 = fullfile(special.outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end

% init
His = init_histone(special);

% calculate
[pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);

% output
output_histone(His,pep_rts,pep_intens,special);

% draw layout
isorts = MS1_index(1:size(MS1_index,1),2);
if '1'==special.sfigure(1)
    draw_layout(His,pep_rts,pep_intens,isorts,mono_isointens,special);
end

% Get PSM
if '1'==special.sfigure(2)
    draw_PSM(His,pep_rts,pep_intens,isorts,mono_isointens,MS2_index,MS2_peaks,special);
end

function His = init_histone(special)
%%

His.pep_seq = 'YQKSTELLIR';
His.mod_short = {'unmod';
    'K56me1';
    'K56me2';
    'K56me3';
    'K56ac';
    'K56sor'};
His.mod_type = get_mod_type(special);

His.pep_ch = repmat([1 2 3 4],length(His.mod_type),1);
His.pep_mz = calculate_pepmz(His,special.Mods,special.nhmass);
His.rt_ref = [40.37
    41.20
    33.92
    33.72
    39.17
    41.20];
if 1==special.rt_reset
    His.rt_ref = special.rt_ref;
end
His.display = ones(length(His.mod_type),1);

% main ch
main_ch = His.pep_ch(1,2);
if main_ch~=His.pep_ch(1,1)
    [npep,ncharge] = size(His.pep_mz);
    new_ch = [main_ch,setdiff(His.pep_ch(1,:),main_ch)];
    x = zeros([1,ncharge]);
    for ino=1:ncharge
        x(ino) = find(His.pep_ch(1,:)==new_ch(ino));
    end
    tune = 1:npep;
    His.pep_mz(tune,:) = His.pep_mz(tune,x);
    His.pep_ch(tune,:) = His.pep_ch(tune,x);
end

function mod_type = get_mod_type(special)
%%

if 1==special.nlight
    mod_type = {'0,pr;3,pr;';
        '0,pr;3,me1;';
        '0,pr;3,me2;';
        '0,pr;3,me3;';
        '0,pr;3,ac;';
        '0,pr;3,sor;'};
else
    if (1==special.nsource && 1==special.nsubtype) || (2==special.nsource && 0==special.nsubtype)
        mod_type = {'0,pr;3,pr;10,lar;';
            '0,pr;3,me1;10,lar;';
            '0,pr;3,me2;10,lar;';
            '0,pr;3,me3;10,lar;';
            '0,pr;3,ac;10,lar;';
            '0,pr;3,sor;10,lar;'};
    elseif (1==special.nsource && 2==special.nsubtype) || (2==special.nsource && 1==special.nsubtype)
        mod_type = {'0,pr;3,prlak;10,lar;';
            '0,pr;3,me1lak;10,lar;';
            '0,pr;3,me2lak;10,lar;';
            '0,pr;3,me3lak;10,lar;';
            '0,pr;3,aclak;10,lar;';
            '0,pr;3,sor;10,lar;'};
    elseif 3==special.nsource
        mod_type = {'0,pr;3,pr;';
            '0,pr;3,me11;';
            '0,pr;3,me21;';
            '0,pr;3,me31;';
            '0,pr;3,ac;';
            '0,pr;3,sor;'};
    end
end

function [pep_rts,pep_intens,mono_isointens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

[npep,ncharge] = size(His.pep_mz);
num_MS1 = size(MS1_index,1);
pep_rts = zeros([npep,ncharge]);
pep_intens = zeros([npep,ncharge]);
mono_isointens = zeros([num_MS1,npep]);

raw_path = special.raw_path;
pre_nums = special.pre_nums;
ndebug = special.ndebug;

% unmod
hno = 1;
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,1);
else
    [t1,t2] = check_ref(raw_path,[His.pep_seq,His.mod_type{1}],pre_nums,ndebug,MS1_index(num_MS1,2));
    top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,1,t1,t2);
    if 0==isempty(top1_rt)
        His.rt_ref(1) = top1_rt;
    else
        return;
    end
end
[cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);

% calibrate the rt_ref
if cur_rts(1)>0
    His.rt_ref(1) = cur_rts(1);
    pep_rts(hno,1:ncharge) = cur_rts;
    pep_intens(hno,1:ncharge) = cur_intens;
    mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
end
if 1==ndebug
    His = relocateD(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,2);
else
    His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His);
end

% K56me1
% K56me2
% K56me3
% K56ac
% K56sor
for hno=2:6
    [cur_rts,cur_intens,cur_mono_isointens] = get_histone1(MS1_index,MS1_peaks,special,His,hno);
    if cur_rts(1)>0
        pep_rts(hno,1:ncharge) = cur_rts;
        pep_intens(hno,1:ncharge) = cur_intens;
        mono_isointens(1:num_MS1,hno) = cur_mono_isointens;
    end
end

function His = relocate(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His)
%%

delta = 0.1;
nsplit = 1;

% K56me1
hno = 2;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(1)+special.dis_me1(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K56me2
hno = 3;
t1 = max([6,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-3;
[top1_rt3,top1_inten_sum3,rts3,inten_sum3] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

% K56me3
hno = 4;
t1 = max([6,His.rt_ref(1)-special.dis_me2(special.rtlen)]);
t2 = His.rt_ref(1)-3;
[top1_rt4,top1_inten_sum4,rts4,inten_sum4] = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

[His.rt_ref(3),His.rt_ref(4)] = find_pair(top1_rt3,top1_inten_sum3,rts3,inten_sum3,top1_rt4,top1_inten_sum4,rts4,inten_sum4);

% K56ac
hno = 5;
t1 = max([(His.rt_ref(1)+His.rt_ref(3))/2,His.rt_ref(1)-special.dis_ac(special.rtlen)]);%max([3,His.rt_ref(1)-special.dis_ac(special.rtlen)]);
t2 = His.rt_ref(1)-delta;
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end

% K56sor
hno = 6;
t1 = His.rt_ref(1)+delta;
t2 = His.rt_ref(1)+special.dis_sor(special.rtlen);
top1_rt = get_rts(MS1_index,MS1_peaks,MS2_index,MS2_peaks,special,His,hno,nsplit,t1,t2);

if 1==isempty(top1_rt)
    His.rt_ref(hno) = 0;
else
    His.rt_ref(hno) = top1_rt;
end